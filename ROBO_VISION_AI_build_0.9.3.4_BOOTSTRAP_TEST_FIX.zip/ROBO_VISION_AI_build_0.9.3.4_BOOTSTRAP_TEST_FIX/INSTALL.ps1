$ErrorActionPreference = "Stop"
$Root = $PSScriptRoot
$LogDir = Join-Path $Root "logs"
New-Item -ItemType Directory -Force -Path $LogDir | Out-Null
$Log = Join-Path $LogDir "installer.log"
Start-Transcript -Path $Log -Append | Out-Null

Write-Host "==========================================" -ForegroundColor Cyan
Write-Host "       ROBO VISION AI INSTALLER 0.9.3.4 BOOTSTRAP-TEST-FIX" -ForegroundColor Cyan
Write-Host "==========================================" -ForegroundColor Cyan
Write-Host "Install folder: $Root"

function Run-Step($Name, [scriptblock]$Block) {
    Write-Host "`n[$Name]" -ForegroundColor Yellow
    try {
        $global:LASTEXITCODE = 0
        & $Block
        if ($LASTEXITCODE -and $LASTEXITCODE -ne 0) { throw "Command exited with code $LASTEXITCODE" }
        Write-Host "PASS: $Name" -ForegroundColor Green
    }
    catch {
        Write-Host "FAILED: $Name" -ForegroundColor Red
        Write-Host $_.Exception.Message -ForegroundColor Red
        throw
    }
}

Run-Step "System check" {
    Write-Host ("Windows: " + [System.Environment]::OSVersion.VersionString)
    Write-Host ("64-bit OS: " + [Environment]::Is64BitOperatingSystem)
    $drive = Get-PSDrive -Name ([IO.Path]::GetPathRoot($Root).Substring(0,1))
    Write-Host ("Free disk GB: " + [math]::Round($drive.Free / 1GB, 1))
    $script:HasNvidia = [bool](Get-Command nvidia-smi -ErrorAction SilentlyContinue)
    if ($script:HasNvidia) {
        Write-Host "NVIDIA driver detected. CUDA-enabled PyTorch will be preferred."
        & nvidia-smi --query-gpu=name,driver_version,memory.total --format=csv,noheader
    } else {
        Write-Host "NVIDIA driver not detected. CPU fallback will be used if no supported accelerator is available."
    }
}

Run-Step "Find or install Python 3.11" {
    $script:PyExe = $null
    $script:PyPrefix = @()
    $candidates = @(
        @{Exe="py"; Args=@("-3.11")},
        @{Exe="python"; Args=@()},
        @{Exe="python3"; Args=@()}
    )
    foreach ($c in $candidates) {
        try {
            $out = & $c.Exe @($c.Args) --version 2>&1
            if ($LASTEXITCODE -eq 0 -and "$out" -match "Python 3\.(11|12)") {
                $script:PyExe = $c.Exe
                $script:PyPrefix = @($c.Args)
                Write-Host "Using $out"
                break
            }
        } catch {}
    }
    if (-not $script:PyExe) {
        if (Get-Command winget -ErrorAction SilentlyContinue) {
            Write-Host "Python 3.11 not found. Installing with winget..."
            & winget install -e --id Python.Python.3.11 --accept-source-agreements --accept-package-agreements
            if ($LASTEXITCODE -ne 0) { throw "winget could not install Python 3.11." }
            $script:PyExe = "py"
            $script:PyPrefix = @("-3.11")
        } else {
            throw "Python 3.11 is missing and winget is unavailable."
        }
    }
}

$Venv = Join-Path $Root ".venv"
$Py = Join-Path $Venv "Scripts\python.exe"

Run-Step "Create isolated Python environment" {
    if (-not (Test-Path $Py)) {
        & $script:PyExe @($script:PyPrefix) -m venv $Venv
        if ($LASTEXITCODE -ne 0) { throw "Could not create virtual environment." }
    } else {
        Write-Host "Existing virtual environment found."
    }
}

Run-Step "Upgrade installer tools" {
    & $Py -m pip install --upgrade pip setuptools wheel
}

if ($script:HasNvidia) {
    Run-Step "Install NVIDIA CUDA PyTorch" {
        # Install GPU-enabled PyTorch before Ultralytics so pip does not select the CPU wheel from PyPI.
        # Missing torch is normal on a fresh install, so the cleanup command must never abort setup.
        Write-Host "Cleaning any existing PyTorch packages (safe to skip if none are installed)..."
        $uninstallCmd = '"' + $Py + '" -m pip uninstall -y torch torchvision torchaudio >nul 2>&1'
        & cmd.exe /d /c $uninstallCmd
        $global:LASTEXITCODE = 0

        Write-Host "Installing CUDA 12.6 PyTorch build..."
        & $Py -m pip install --upgrade torch torchvision --index-url https://download.pytorch.org/whl/cu126
        if ($LASTEXITCODE -ne 0) { throw "CUDA PyTorch installation failed." }
    }
}

Run-Step "Install application dependencies" {
    & $Py -m pip install -r (Join-Path $Root "requirements.txt")
}

Run-Step "Verify core imports" {
    & $Py -c "import PySide6, cv2, mss, psutil, numpy, PIL; print('CORE IMPORTS OK')"
}

Run-Step "Verify computer vision engine" {
    & $Py -c "import ultralytics, torch; print('ULTRALYTICS', ultralytics.__version__); print('TORCH', torch.__version__); print('CUDA', torch.cuda.is_available()); print('GPU', torch.cuda.get_device_name(0) if torch.cuda.is_available() else 'CPU MODE')"
    if ($script:HasNvidia) {
        $cudaOk = & $Py -c "import torch; print('1' if torch.cuda.is_available() else '0')"
        if (($cudaOk | Select-Object -Last 1).Trim() -ne "1") {
            throw "NVIDIA GPU is present but PyTorch CUDA is still unavailable."
        }
    }
}

Run-Step "Run project tests" {
    $TestTemp = Join-Path $Root ".pytest_tmp"
    if (Test-Path $TestTemp) { Remove-Item -Recurse -Force $TestTemp -ErrorAction SilentlyContinue }
    New-Item -ItemType Directory -Force -Path $TestTemp | Out-Null
    Push-Location $Root
    try {
        $env:TEMP = $TestTemp
        $env:TMP = $TestTemp
        & $Py -m pytest -q --basetemp (Join-Path $TestTemp "run") -o "cache_dir=$Root\.pytest_cache"
    }
    finally { Pop-Location }
}

Write-Host "`n==========================================" -ForegroundColor Green
Write-Host " INSTALLATION FOUNDATION COMPLETE" -ForegroundColor Green
Write-Host "==========================================" -ForegroundColor Green
Write-Host "Next: double-click START_ROBO_VISION.bat"
Write-Host "Installer log: $Log"
Stop-Transcript | Out-Null
