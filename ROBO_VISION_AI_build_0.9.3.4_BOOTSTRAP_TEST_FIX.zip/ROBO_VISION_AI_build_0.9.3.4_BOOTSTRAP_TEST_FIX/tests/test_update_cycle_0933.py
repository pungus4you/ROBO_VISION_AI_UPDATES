import json
from pathlib import Path
from app.update.manager import UpdateManager, CURRENT_VERSION


def test_version_is_windows_temp_fix():
    assert CURRENT_VERSION == "0.9.3.4"


def test_bom_manifest_is_accepted(tmp_path):
    build = tmp_path / "build"; build.mkdir()
    mgr = UpdateManager(tmp_path / "root", build)
    package = tmp_path / "pkg.zip"; package.write_bytes(b"fake")
    import hashlib
    manifest = {
        "version":"0.9.3.4",
        "package_url":package.resolve().as_uri(),
        "sha256":hashlib.sha256(b"fake").hexdigest(),
        "min_current_version":"0.9.3"
    }
    mp = tmp_path / "manifest.json"
    mp.write_bytes(b"\xef\xbb\xbf" + json.dumps(manifest).encode("utf-8"))
    s = mgr.settings(); s["software_manifest_url"] = mp.resolve().as_uri(); mgr.save_settings(s)
    r = mgr.check_software_manifest()
    assert r.status in {"available","up_to_date"}, r.details


def test_test_candidate_without_stage_is_clean_failure(tmp_path):
    build=tmp_path/"build"; build.mkdir()
    mgr=UpdateManager(tmp_path/"root",build)
    r=mgr.test_staged_update()
    assert r.status == "failed"
    assert "Stage + Verify" in r.details.get("reason","") or "staged verified" in r.details.get("reason","")
    assert "PermissionError" not in str(r.details)
