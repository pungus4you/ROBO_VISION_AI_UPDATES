from pathlib import Path


def test_update_center_is_visible_from_ai_studio():
    text=(Path(__file__).resolve().parents[1]/'app'/'ui'/'main_window.py').read_text(encoding='utf-8')
    assert 'ROBO 0.9.3.4 — Identity, Knowledge & Trusted Feed' in text
    assert 'OPEN UPDATE CENTER' in text
    assert 'VERIFY IDENTITY' in text
    assert 'Identity + Knowledge + Trusted Software Updates' in text
    assert 'Automatic' in text and 'Notify Me' in text and 'Offline Only' in text


def test_trusted_channel_controls_are_in_source():
    from pathlib import Path
    src=(Path(__file__).parents[1]/"app"/"ui"/"main_window.py").read_text(encoding="utf-8")
    for text in ["Trusted ROBO Software Channel","Stage + Verify","Test Candidate","Prepare Activation","Run Full Safe Update Cycle"]:
        assert text in src
