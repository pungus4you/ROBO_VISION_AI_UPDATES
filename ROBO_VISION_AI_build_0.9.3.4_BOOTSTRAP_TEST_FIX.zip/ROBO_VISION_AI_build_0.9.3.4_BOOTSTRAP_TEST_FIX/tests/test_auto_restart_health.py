from pathlib import Path
from app.update.manager import CURRENT_VERSION

def test_auto_update_has_health_checked_restart():
    root=Path(__file__).parents[1]
    manager=(root/'app'/'update'/'manager.py').read_text(encoding='utf-8')
    main=(root/'app'/'main.py').read_text(encoding='utf-8')
    ui=(root/'app'/'ui'/'main_window.py').read_text(encoding='utf-8')
    assert CURRENT_VERSION == '0.9.3.4'
    assert 'launch_pending_activation' in manager
    assert 'APPLY_PENDING_UPDATE.ps1' in manager
    assert 'updates"/"health' in main
    assert 'automatic_restart' in ui
