from __future__ import annotations
from pathlib import Path
import shutil, json, time

from PySide6.QtCore import QThread, Signal, QTimer
from PySide6.QtWidgets import (
    QApplication,QMainWindow,QWidget,QVBoxLayout,QHBoxLayout,QLabel,QPushButton,QTextEdit,QListWidget,
    QStackedWidget,QComboBox,QFileDialog,QLineEdit,QMessageBox,QGroupBox,QProgressBar
)

from app.system.hardware import detect_hardware, training_preset
from app.ai.ollama import OllamaClient
from app.projects.manager import ProjectManager
from app.dataset.manager import DatasetManager
from app.core.paths import ensure_layout
from app.capture.windows import list_visible_windows, grab_window
from app.output.generator import generate_output_bundle
from app.video.extract import extract_frames
from app.automation.action_engine import ActionEngine
from app.recovery.state import RecoveryManager
from app.system.monitor import live_snapshot
from app.repair.self_heal import safe_repair
from app.identity.manager import IdentityManager
from app.update.manager import UpdateManager
from app.knowledge.store import KnowledgeStore

class AIWorker(QThread):
    done=Signal(str)
    def __init__(self, model, messages):
        super().__init__(); self.model=model; self.messages=messages
    def run(self):
        try:
            c=OllamaClient()
            if not c.health(): raise RuntimeError("Ollama is not running")
            ans=c.chat(self.model,self.messages)
        except Exception as e:
            ans=f"Local AI error: {e}"
        self.done.emit(ans)

class ActionWorker(QThread):
    status=Signal(str); progress=Signal(int,str); done=Signal(object); failed=Signal(str)
    def __init__(self, engine, action, quick=False):
        super().__init__(); self.engine=engine; self.action=action; self.quick=quick
    def _say(self, text):
        print(f"[ROBO] {text}", flush=True)
        self.status.emit(text)
    def run(self):
        try:
            if self.action=="auto_build":
                def stage_cb(base, span):
                    def cb(done,total,msg):
                        pct=base + int(span*(done/max(1,total)))
                        self.progress.emit(min(99,pct),msg)
                    return cb
                self.progress.emit(1,"Starting autonomous pipeline")
                self._say("Stage 1/9 — Auto-annotating full-size targets")
                a=self.engine.auto_annotate(progress_cb=stage_cb(0,11)); self._say(f"Auto annotation complete: {a}")
                self._say("Stage 2/9 — Smart YOLO review of empty/uncertain labels")
                r=self.engine.review_annotations(progress_cb=stage_cb(11,8)); self._say(f"Smart YOLO review complete: {r}")
                self._say("Stage 3/9 — Small-target tile + red-marker review")
                sm=self.engine.small_target_review(progress_cb=stage_cb(19,13)); self._say(f"Small-target review complete: {sm}")
                self._say("Stage 4/9 — Local vision-model review of remaining uncertain targets")
                v=self.engine.vlm_review_annotations(progress_cb=stage_cb(32,10)); self._say(f"Local vision review complete: {v}")
                self._say("Stage 5/9 — Preparing train/validation/test dataset")
                b=self.engine.prepare_dataset(progress_cb=stage_cb(42,8)); self._say(f"Dataset prepared: {b}")
                self._say("Stage 6/9 — High-resolution baseline training")
                c=self.engine.train(quick=self.quick,progress_cb=stage_cb(50,27)); self._say(f"Baseline training complete: {c}")
                self._say("Stage 7/9 — Mining hard examples")
                h=self.engine.mine_hard_examples(progress_cb=stage_cb(77,6)); self._say(f"Hard-example analysis complete: {h}")
                self._say("Stage 8/9 — Controlled improvement experiment")
                imp=self.engine.improve_model(quick=self.quick,progress_cb=stage_cb(83,13)); self._say(f"Improvement result: {imp['status']} | accepted={imp['accepted']}")
                self._say("Stage 9/9 — Creating refined small-target output bundle")
                self.progress.emit(97,"Exporting best.pt + 960px detector + red-marker fallback")
                d=self.engine.export(); self.progress.emit(100,"Complete")
                print("\n" + "="*62, flush=True)
                print("ROBO VISION AI: CONTROLLED IMPROVEMENT COMPLETE", flush=True)
                print("ROBO VISION AI: OUTPUT EXPORTED", flush=True)
                print("ROBO VISION AI: AUTO BUILD COMPLETE", flush=True)
                print("You can now close this training terminal after checking the GUI.", flush=True)
                print("="*62 + "\n", flush=True)
                self.done.emit([a,r,sm,v,b,c,h,imp,d]); return
            fn=getattr(self.engine,self.action); self.done.emit(fn())
        except Exception as e:
            msg=f"{type(e).__name__}: {e}"
            print(f"[ROBO ERROR] {msg}", flush=True)
            self.failed.emit(msg)


class UpdateWorker(QThread):
    done=Signal(object)
    failed=Signal(str)
    def __init__(self, manager, action="startup"):
        super().__init__(); self.manager=manager; self.action=action
    def run(self):
        try:
            if self.action=="refresh": result=self.manager.refresh_knowledge(force=True)
            elif self.action=="manifest": result=self.manager.check_software_manifest()
            elif self.action=="stage": result=self.manager.stage_software_update()
            elif self.action=="test": result=self.manager.test_staged_update()
            elif self.action=="activate": result=self.manager.prepare_activation()
            elif self.action=="auto_software": result=self.manager.automatic_software_cycle()
            else: result=self.manager.startup_action()
            self.done.emit(result)
        except Exception as e:
            self.failed.emit(f"{type(e).__name__}: {e}")

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("ROBO Vision AI 0.9.3.4 — Bootstrap Candidate Test Fix")
        self.resize(1320,840)
        self.paths=ensure_layout()
        self.pm=ProjectManager(self.paths["projects"])
        self.recovery=RecoveryManager(self.paths["root"])
        build_dir=Path(__file__).resolve().parents[2]
        self.identity=IdentityManager(self.paths["root"], build_dir/"ROBO_IDENTITY_MASTER.json")
        self.identity_status=self.identity.ensure()
        self.update_manager=UpdateManager(self.paths["root"], build_dir)
        self.knowledge_store=KnowledgeStore(self.paths["root"])
        self.update_worker=None
        self.current_project=None; self.current_dataset=None
        self.worker=None; self.action_worker=None
        self.chat_history=[]
        self.project_brief={"target_class":None,"autonomous_mode":False,"goal":"computer vision detector"}
        self.run_started_at=None; self.last_progress_pct=0
        self.monitor_timer=QTimer(self); self.monitor_timer.setInterval(1000); self.monitor_timer.timeout.connect(self.update_live_monitor)

        root=QWidget(); self.setCentralWidget(root); layout=QHBoxLayout(root)
        self.nav=QListWidget(); self.nav.setObjectName("mainNavigation"); self.nav.setStyleSheet("QListWidget#mainNavigation { font-size: 14px; font-weight: 600; padding: 6px; } QListWidget#mainNavigation::item { padding: 10px 8px; } QListWidget#mainNavigation::item:selected { background: #dbeafe; color: #111827; border-radius: 4px; }"); self.nav.addItems([
            "AI Studio","Projects","Dataset","Capture","Annotate","Training","Models",
            "Live Vision","Improvement Lab","Update Center","Repair / Reset","Diagnostics"
        ]); self.nav.setMinimumWidth(185); self.nav.setMaximumWidth(220)
        self.stack=QStackedWidget(); layout.addWidget(self.nav); layout.addWidget(self.stack,1)
        self.nav.currentRowChanged.connect(self.stack.setCurrentIndex)
        self.stack.addWidget(self.ai_studio())
        for title in ["Projects","Dataset","Capture","Annotate","Training","Models","Live Vision"]:
            self.stack.addWidget(self.placeholder(title))
        self.stack.addWidget(self.improvement_page())
        self.stack.addWidget(self.update_page())
        self.stack.addWidget(self.repair_page())
        self.stack.addWidget(self.placeholder("Diagnostics"))
        self.nav.setCurrentRow(0)
        QTimer.singleShot(1200,self.startup_update_check)

    def placeholder(self,title):
        w=QWidget(); l=QVBoxLayout(w); l.addWidget(QLabel(f"<h2>{title}</h2>"))
        l.addWidget(QLabel("Advanced/manual page. The normal workflow is controlled from AI Studio.")); l.addStretch(); return w

    def ai_studio(self):
        w=QWidget(); outer=QVBoxLayout(w)
        head=QHBoxLayout(); title=QLabel("<h1>ROBO Vision AI</h1><b>Tell the AI what you want. Give it images/video. The action engine can now prepare, train and export a real project.</b>")
        h=detect_hardware(); self.hw_label=QLabel(f"{h.gpu} | {h.ram_gb} GB RAM | {h.profile}")
        head.addWidget(title,1); head.addWidget(self.hw_label); outer.addLayout(head)

        # 0.9.1: keep the new identity/update features visible even while working in AI Studio.
        feature_box=QGroupBox("ROBO 0.9.4.1 — Portable, Self-Repair & Trusted Feed")
        feature_layout=QHBoxLayout(feature_box)
        ident_reason=self.identity_status.get("reason", "verified")
        mode=self.update_manager.settings().get("mode", "automatic")
        self.home_update_summary=QLabel(f"Identity: {ident_reason}   |   Update mode: {mode}   |   Local knowledge: {len(self.knowledge_store._entries())} document(s)")
        self.home_update_summary.setWordWrap(True)
        feature_layout.addWidget(self.home_update_summary,1)
        open_updates=QPushButton("OPEN UPDATE CENTER")
        open_updates.clicked.connect(lambda:self.nav.setCurrentRow(9))
        feature_layout.addWidget(open_updates)
        verify_identity=QPushButton("VERIFY IDENTITY")
        verify_identity.clicked.connect(self.verify_identity_now)
        feature_layout.addWidget(verify_identity)
        outer.addWidget(feature_box)

        body=QHBoxLayout(); outer.addLayout(body,1)
        left=QGroupBox("AI Copilot"); ll=QVBoxLayout(left)
        top=QHBoxLayout(); self.model=QComboBox(); refresh=QPushButton("Refresh Models"); refresh.clicked.connect(self.refresh_models)
        top.addWidget(QLabel("Local AI:")); top.addWidget(self.model,1); top.addWidget(refresh); ll.addLayout(top)
        self.chat=QTextEdit(); self.chat.setReadOnly(True); ll.addWidget(self.chat,1)
        self.input=QTextEdit(); self.input.setMaximumHeight(95); self.input.setPlaceholderText("Example: Detect people in these images. Do everything automatically and give me best.pt + .py.")
        ll.addWidget(self.input)
        send=QPushButton("Send / Execute"); send.clicked.connect(self.send_ai); ll.addWidget(send)
        body.addWidget(left,3)

        right=QGroupBox("Project, Data & Actions"); rl=QVBoxLayout(right)
        self.project_name=QLineEdit(); self.project_name.setPlaceholderText("Project name")
        create=QPushButton("Create Project"); create.clicked.connect(self.create_project); rl.addWidget(self.project_name); rl.addWidget(create)
        self.status=QLabel("No project selected"); self.status.setWordWrap(True); rl.addWidget(self.status)
        for text,fn in [("Upload Images",self.upload_images),("Upload Folder",self.upload_folder),("Upload Video + Extract Frames",self.upload_video),("Select Game / App Window",self.select_window),("Capture Selected Window Frame",self.capture_selected_window)]:
            b=QPushButton(text); b.clicked.connect(fn); rl.addWidget(b)
        self.window_box=QComboBox(); self.window_box.setVisible(False); rl.addWidget(self.window_box)

        rl.addWidget(QLabel("<b>YOLO26 model:</b>")); self.cv_model=QComboBox(); self.cv_model.addItems(["Auto (hardware)","yolo26n.pt","yolo26s.pt","yolo26m.pt"]); rl.addWidget(self.cv_model)
        quick=QPushButton("QUICK AUTO BUILD (5 epochs)"); quick.clicked.connect(lambda:self.start_auto_build(True)); rl.addWidget(quick)
        full=QPushButton("AUTO BUILD PROJECT"); full.clicked.connect(lambda:self.start_auto_build(False)); rl.addWidget(full)
        self.progress=QProgressBar(); self.progress.setRange(0,100); self.progress.setValue(0); self.progress.setVisible(False); rl.addWidget(self.progress)
        self.progress_detail=QLabel("Idle"); self.progress_detail.setWordWrap(True); rl.addWidget(self.progress_detail)
        self.action_status=QLabel("Action engine ready"); self.action_status.setWordWrap(True); rl.addWidget(self.action_status)
        self.live_monitor=QLabel("Live monitor: idle"); self.live_monitor.setWordWrap(True); rl.addWidget(self.live_monitor)
        self.review_status=QLabel("Smart review: not run yet"); self.review_status.setWordWrap(True); rl.addWidget(self.review_status)
        self.output_label=QLabel("Final output: best.pt + .py + RUN.bat + feedback (M/X) + separate Visual Assist Controls"); self.output_label.setWordWrap(True); rl.addWidget(self.output_label)
        export=QPushButton("Export Current best.pt + .py Bundle"); export.clicked.connect(self.export_bundle); rl.addWidget(export)
        rl.addStretch(); body.addWidget(right,2)

        self.refresh_models()
        self.chat.append("AI: Tell me the target once. I will remember it. With a project and images loaded, say 'do everything' or use AUTO BUILD to auto-label, prepare, train and export.")
        return w

    def improvement_page(self):
        w=QWidget(); l=QVBoxLayout(w); l.addWidget(QLabel("<h2>Improvement Lab</h2>"))
        l.addWidget(QLabel("Controlled experiments only: baseline is backed up, candidates are measured on validation data, and a candidate replaces best.pt only when it scores better."))
        run=QPushButton("Run Controlled Improvement on Current Project")
        run.clicked.connect(self.run_improvement_only); l.addWidget(run)
        refresh=QPushButton("Refresh Hard Examples / Last Improvement")
        refresh.clicked.connect(self.refresh_improvement_panel); l.addWidget(refresh)
        self.improvement_text=QTextEdit(); self.improvement_text.setReadOnly(True); l.addWidget(self.improvement_text,1)
        return w

    def run_improvement_only(self):
        eng=self._engine()
        if not eng:return
        self.progress.setVisible(True); self.progress.setValue(0); self.run_started_at=time.time(); self.last_progress_pct=0; self.monitor_timer.start()
        self.action_worker=ActionWorker(eng,"improve_model",quick=False)
        self.action_worker.done.connect(lambda r:(self.monitor_timer.stop(),self.chat.append("SYSTEM: Controlled improvement complete: "+str(r)),self.refresh_improvement_panel()))
        self.action_worker.failed.connect(lambda e:(self.monitor_timer.stop(),self.chat.append("SYSTEM ERROR: "+e)))
        self.action_worker.start()

    def refresh_improvement_panel(self):
        if not self.current_project:
            self.improvement_text.setPlainText("Create/open a project first."); return
        parts=[]
        for fp in [self.current_dataset/"vlm_review.json" if self.current_dataset else Path("missing"), self.current_project/"analysis"/"hard_examples.json", self.current_project/"improvement"/"last_improvement.json"]:
            if fp.exists():
                try: parts.append(fp.name+"\n"+json.dumps(json.loads(fp.read_text(encoding="utf-8")),indent=2))
                except Exception as e: parts.append(fp.name+": "+str(e))
        self.improvement_text.setPlainText("\n\n".join(parts) if parts else "No improvement analysis yet.")

    def update_page(self):
        w=QWidget(); l=QVBoxLayout(w)
        l.addWidget(QLabel("<h2>Identity + Knowledge + Trusted Software Updates</h2>"))
        ident=self.identity_status
        self.identity_label=QLabel(f"Protected identity: {ident.get('reason')}\nFingerprint: {ident.get('fingerprint','')[:16]}…\n{ident.get('path','')}")
        self.identity_label.setWordWrap(True); l.addWidget(self.identity_label)

        mode_row=QHBoxLayout(); mode_row.addWidget(QLabel("Update mode:"))
        self.update_mode=QComboBox(); self.update_mode.addItem("Automatic","automatic"); self.update_mode.addItem("Notify Me","notify"); self.update_mode.addItem("Offline Only","offline")
        current=self.update_manager.settings().get("mode","automatic"); self.update_mode.setCurrentIndex(max(0,self.update_mode.findData(current)))
        mode_row.addWidget(self.update_mode,1); save=QPushButton("Save Mode"); save.clicked.connect(self.save_update_mode); mode_row.addWidget(save); l.addLayout(mode_row)

        channel=QGroupBox("Trusted ROBO Software Channel"); cl=QVBoxLayout(channel)
        row=QHBoxLayout(); row.addWidget(QLabel("Manifest URL:")); self.manifest_url=QLineEdit(); self.manifest_url.setPlaceholderText("https://your-trusted-host/robo/manifest.json")
        self.manifest_url.setText(self.update_manager.settings().get("software_manifest_url", "")); row.addWidget(self.manifest_url,1)
        saveurl=QPushButton("Save Channel"); saveurl.clicked.connect(self.save_manifest_url); row.addWidget(saveurl); cl.addLayout(row)
        cl.addWidget(QLabel("Only HTTPS (or local file:// for testing) is accepted. Packages must match the manifest SHA256, pass structural checks and project tests, and are installed beside—not over—the current working build."))
        sr=QHBoxLayout()
        for text,action in [("Check Channel","manifest"),("Stage + Verify","stage"),("Test Candidate","test"),("Prepare Activation","activate"),("Run Full Safe Update Cycle","auto_software")]:
            b=QPushButton(text); b.clicked.connect(lambda checked=False,a=action:self.run_update_action(a)); sr.addWidget(b)
        cl.addLayout(sr); l.addWidget(channel)

        publisher=QGroupBox("Trusted Feed Publisher / Bootstrap"); pl=QVBoxLayout(publisher)
        pl.addWidget(QLabel("Create a complete manifest.json + ZIP feed locally. The same two files can later be uploaded together to any static HTTPS host without editing the manifest."))
        prow=QHBoxLayout(); self.feed_package=QLineEdit(); self.feed_package.setPlaceholderText("Select a future ROBO build ZIP, e.g. ROBO_VISION_AI_build_0.9.4.zip")
        browse=QPushButton("Choose ZIP"); browse.clicked.connect(self.choose_feed_package); prow.addWidget(self.feed_package,1); prow.addWidget(browse); pl.addLayout(prow)
        pbuttons=QHBoxLayout(); create_feed=QPushButton("CREATE TRUSTED FEED"); create_feed.clicked.connect(self.create_trusted_feed_ui); pbuttons.addWidget(create_feed)
        use_local=QPushButton("USE LOCAL FEED"); use_local.clicked.connect(self.use_local_feed_ui); pbuttons.addWidget(use_local)
        open_feed=QPushButton("OPEN FEED FOLDER"); open_feed.clicked.connect(self.open_feed_folder); pbuttons.addWidget(open_feed); pl.addLayout(pbuttons)
        l.addWidget(publisher)

        buttons=QHBoxLayout()
        b1=QPushButton("Refresh Knowledge Now"); b1.clicked.connect(lambda:self.run_update_action("refresh")); buttons.addWidget(b1)
        b3=QPushButton("Verify Identity Now"); b3.clicked.connect(self.verify_identity_now); buttons.addWidget(b3)
        l.addLayout(buttons)
        l.addWidget(QLabel("Automatic mode can refresh approved knowledge and, once a trusted manifest URL is configured, check/stage/test a newer ROBO build. Automatic mode can complete the safe cycle, restart into the tested version, verify a startup health marker, and reopen the previous working build automatically if the candidate fails to become healthy."))
        self.update_status=QTextEdit(); self.update_status.setReadOnly(True); self.update_status.setPlainText(self._update_summary_text()); l.addWidget(self.update_status,1)
        return w

    def _update_summary_text(self):
        s=self.update_manager.settings(); entries=self.knowledge_store._entries(); state=self.update_manager.state(); pending=state.get('pending_activation') or {}
        return (f"Current ROBO version: 0.9.3.4\nMode: {s.get('mode')}\nKnowledge refresh interval: {s.get('knowledge_interval_hours')} hours\n"
                f"Software check interval: {s.get('software_interval_hours')} hours\nLocal knowledge documents: {len(entries)}\n"
                f"Software manifest URL: {s.get('software_manifest_url') or '[not configured]'}\n"
                f"Pending tested update: {pending.get('version') or '[none]'}\n"
                f"Identity repaired this launch: {self.identity_status.get('repaired')}\nIdentity status: {self.identity_status.get('reason')}")

    def choose_feed_package(self):
        path,_=QFileDialog.getOpenFileName(self,"Choose ROBO update ZIP",str(Path.home()),"ZIP packages (*.zip)")
        if path: self.feed_package.setText(path)

    def create_trusted_feed_ui(self):
        path=self.feed_package.text().strip()
        if not path:
            QMessageBox.information(self,"Trusted Feed","Choose a ROBO build ZIP first."); return
        result=self.update_manager.create_trusted_feed(path)
        self.on_update_result("create_feed",result)
        if getattr(result,"status","")=="feed_ready":
            self.manifest_url.setText(result.details.get("manifest_url_local", ""))
            QMessageBox.information(self,"Trusted Feed Ready","Feed created. For local testing click USE LOCAL FEED. For internet updates, upload manifest.json and the ZIP from the feed folder to the same HTTPS folder.")

    def use_local_feed_ui(self):
        result=self.update_manager.use_local_feed()
        self.on_update_result("use_local_feed",result)
        if getattr(result,"status","")=="configured": self.manifest_url.setText(result.details.get("manifest_url", ""))

    def open_feed_folder(self):
        import os
        folder=self.paths["root"]/"trusted_feed"; folder.mkdir(parents=True,exist_ok=True)
        try: os.startfile(str(folder))
        except Exception as e: QMessageBox.information(self,"Trusted Feed",str(folder))

    def save_manifest_url(self):
        s=self.update_manager.settings(); s['software_manifest_url']=self.manifest_url.text().strip(); self.update_manager.save_settings(s)
        self.update_status.append("Saved trusted software channel: "+(s['software_manifest_url'] or '[not configured]'))
    def save_update_mode(self):
        s=self.update_manager.settings(); s['mode']=self.update_mode.currentData(); self.update_manager.save_settings(s)
        self.update_status.append(f"Saved update mode: {s['mode']}")
        if hasattr(self, "home_update_summary"):
            self.home_update_summary.setText(f"Identity: {self.identity_status.get('reason','verified')}   |   Update mode: {s['mode']}   |   Local knowledge: {len(self.knowledge_store._entries())} document(s)")

    def verify_identity_now(self):
        self.identity_status=self.identity.ensure(); self.identity_label.setText(f"Protected identity: {self.identity_status.get('reason')}\nFingerprint: {self.identity_status.get('fingerprint','')[:16]}…\n{self.identity_status.get('path','')}")
        self.update_status.append("Identity verification: "+json.dumps({k:self.identity_status.get(k) for k in ('repaired','reason','fingerprint')},indent=2))
        if hasattr(self, "home_update_summary"):
            self.home_update_summary.setText(f"Identity: {self.identity_status.get('reason','verified')}   |   Update mode: {self.update_manager.settings().get('mode','automatic')}   |   Local knowledge: {len(self.knowledge_store._entries())} document(s)")

    def run_update_action(self, action):
        if self.update_worker and self.update_worker.isRunning(): return
        self.update_status.append(f"Starting update action: {action}...")
        self.update_worker=UpdateWorker(self.update_manager,action)
        self.update_worker.done.connect(lambda r:self.on_update_result(action,r))
        self.update_worker.failed.connect(lambda e:self.update_status.append("Update error: "+e))
        self.update_worker.start()

    def startup_update_check(self):
        if self.update_worker and self.update_worker.isRunning(): return
        self.update_worker=UpdateWorker(self.update_manager,"startup")
        self.update_worker.done.connect(lambda r:self.on_update_result("startup",r))
        self.update_worker.failed.connect(lambda e:self.chat.append("SYSTEM UPDATE: "+e))
        self.update_worker.start()

    def on_update_result(self, action, result):
        payload={"status":getattr(result,"status",str(result)),"details":getattr(result,"details",{})}
        if hasattr(self,'update_status'): self.update_status.append(f"{action}: "+json.dumps(payload,indent=2,ensure_ascii=False))
        if hasattr(self, "home_update_summary"):
            self.home_update_summary.setText(f"Identity: {self.identity_status.get('reason','verified')}   |   Update mode: {self.update_manager.settings().get('mode','automatic')}   |   Local knowledge: {len(self.knowledge_store._entries())} document(s)")
        if action=="startup":
            status=payload['status']; details=payload['details']
            if status in {"complete","notify","offline_mode","offline"}:
                self.chat.append("SYSTEM UPDATE: "+str(details.get('message') or f"{status}: knowledge refresh checked."))
            sw=(details.get("software") or {}) if isinstance(details,dict) else {}
            if sw.get("status")=="ready_to_activate" and self.update_manager.settings().get("mode")=="automatic":
                launched=self.update_manager.launch_pending_activation()
                self.update_status.append("automatic_restart: "+json.dumps({"status":launched.status,"details":launched.details},indent=2))
                if launched.status=="restart_launched": QTimer.singleShot(750, QApplication.quit)
        if action=="auto_software" and payload['status']=="ready_to_activate":
            launched=self.update_manager.launch_pending_activation()
            self.update_status.append("automatic_restart: "+json.dumps({"status":launched.status,"details":launched.details},indent=2))
            if launched.status=="restart_launched": QTimer.singleShot(750, QApplication.quit)

    def repair_page(self):
        w=QWidget(); l=QVBoxLayout(w); l.addWidget(QLabel("<h2>Repair / Reset</h2>"))
        l.addWidget(QLabel("These actions preserve your projects and trained models."))
        b1=QPushButton("Create Last Known Good Snapshot"); b1.clicked.connect(self.make_snapshot); l.addWidget(b1)
        b2=QPushButton("Reset Settings to Safe Defaults"); b2.clicked.connect(self.reset_settings); l.addWidget(b2)
        b3=QPushButton("Restore Last Known Good Settings"); b3.clicked.connect(self.restore_snapshot); l.addWidget(b3)
        self.repair_status=QLabel("Recovery foundation ready."); self.repair_status.setWordWrap(True); l.addWidget(self.repair_status); l.addStretch(); return w

    def refresh_models(self):
        c=OllamaClient(); self.model.clear()
        if c.health():
            try: self.model.addItems(c.models() or ["No Ollama models found"])
            except Exception as e: self.model.addItem(f"Ollama error: {e}")
        else: self.model.addItem("Ollama not running")

    def _update_project_brief_from_text(self,text):
        t=text.lower()
        if any(x in t for x in ["dont ask","don't ask","do everything","you decide","without asking","unless you need permission"]): self.project_brief["autonomous_mode"]=True
        target=None
        if any(x in t for x in ["enemy","enemies","red dot","red marker"]): target="enemy"
        if target is None and any(x in t for x in ["headshot","head shot","head"]): target="head"
        if target is None and any(x in t for x in ["soldier","solders","soldiers"]): target="soldier"
        if target is None and any(x in t for x in ["person","human","humen"]): target="person"
        if target:self.project_brief["target_class"]=target
        if self.current_project:
            try:(self.current_project/"project_brief.json").write_text(json.dumps(self.project_brief,indent=2),encoding="utf-8")
            except Exception:pass

    def context_text(self):
        proj=self.current_project.name if self.current_project else "none"; ds=self.current_dataset.name if self.current_dataset else "none"; stats=""
        if self.current_project and self.current_dataset:
            try:stats=str(DatasetManager(self.current_project).stats(self.current_dataset))
            except Exception:pass
        return f"Current project: {proj}. Current dataset: {ds}. Dataset stats: {stats}. Locked project brief: {json.dumps(self.project_brief)}."

    def _ai_system_prompt(self, user_text=""):
        identity_context=self.identity.summary_for_prompt()
        knowledge_context=self.knowledge_store.prompt_context(user_text) if user_text else ""
        return (identity_context+" " + "You are ROBO Vision AI, the local AI-first computer-vision copilot. Remember known facts and do not repeat questions. "
                "If autonomous_mode is true, choose sensible defaults. Ask only for permissions, irreversible destructive actions, or genuinely blocking missing facts. "
                "Never claim an action happened without a SYSTEM/tool result. The app now has a deterministic action engine for auto-annotation, smart review, dataset preparation, training, hard-example mining, local vision-model review of uncertain images, small-target tile/red-marker review, high-resolution training, controlled candidate improvement with rollback, and export. "
                "If the user says do everything and project/images exist, tell them the action engine is starting rather than asking more questions. Keep replies short. "+self.context_text()+("\n"+knowledge_context if knowledge_context else ""))

    def _looks_like_auto_build(self,text):
        t=text.lower()
        return any(x in t for x in ["do everything","build everything","train and give","build project","make complete","finish everything","auto build"])

    def send_ai(self):
        text=self.input.toPlainText().strip()
        if not text:return
        self._update_project_brief_from_text(text); self.chat.append("You: "+text); self.input.clear(); self.chat_history.append({"role":"user","content":text})
        if self._looks_like_auto_build(text) and self.current_project and self.current_dataset:
            self.chat.append("SYSTEM: Autonomous build command recognized. Starting real action pipeline.")
            self.start_auto_build(False)
        model=self.model.currentText(); messages=[{"role":"system","content":self._ai_system_prompt(text)}]+self.chat_history[-24:]
        self.worker=AIWorker(model,messages)
        def on_done(ans): self.chat.append("AI: "+ans); self.chat_history.append({"role":"assistant","content":ans})
        self.worker.done.connect(on_done); self.worker.start()

    def create_project(self):
        name=self.project_name.text().strip()
        if not name:return
        try:
            self.current_project=self.pm.create(name,"Created from AI Studio"); self.current_dataset=DatasetManager(self.current_project).create("dataset1")
            self.status.setText(f"Project: {name}\nDataset: dataset1\nReady for images"); self.chat.append(f"SYSTEM: Created project '{name}' and dataset 'dataset1'.")
        except FileExistsError: QMessageBox.warning(self,"Project exists","That project already exists.")
        except Exception as e: QMessageBox.critical(self,"Create project failed",str(e))

    def need_project(self):
        if not self.current_project or not self.current_dataset:
            QMessageBox.information(self,"Create project first","Create a project first."); return False
        return True

    def update_stats(self):
        if not self.current_project:return
        s=DatasetManager(self.current_project).stats(self.current_dataset); self.status.setText(f"Project: {self.current_project.name}\nDataset: {self.current_dataset.name}\nImages: {s['images']} | Labels: {s['labels']} | Unannotated: {s['unannotated']}")

    def upload_images(self):
        if not self.need_project():return
        files,_=QFileDialog.getOpenFileNames(self,"Choose images","","Images (*.jpg *.jpeg *.png *.bmp *.webp)")
        if files:
            n=DatasetManager(self.current_project).import_images(self.current_dataset,[Path(x) for x in files]); self.update_stats(); self.chat.append(f"SYSTEM: Imported {n} image(s).")

    def upload_folder(self):
        if not self.need_project():return
        folder=QFileDialog.getExistingDirectory(self,"Choose image folder")
        if folder:
            n=DatasetManager(self.current_project).import_images(self.current_dataset,[Path(folder)]); self.update_stats(); self.chat.append(f"SYSTEM: Imported {n} image(s) from folder.")

    def upload_video(self):
        if not self.need_project():return
        f,_=QFileDialog.getOpenFileName(self,"Choose video","","Video (*.mp4 *.mkv *.avi *.mov *.webm)")
        if not f:return
        dst=self.current_dataset/"source_videos"; dst.mkdir(exist_ok=True); target=dst/Path(f).name; shutil.copy2(f,target)
        try:
            result=extract_frames(target,self.current_dataset/"images"/"raw",every_n_frames=30)
            self.update_stats(); self.chat.append(f"SYSTEM: Video imported and frames extracted: {result}")
        except Exception as e: self.chat.append(f"SYSTEM ERROR: Video added but extraction failed: {e}")

    def select_window(self):
        wins=list_visible_windows(); self.window_box.clear()
        for x in wins:self.window_box.addItem(f"{x['title']} [PID {x['pid']}]",x)
        self.window_box.setVisible(True); self.chat.append(f"SYSTEM: Found {len(wins)} visible windows. Select one, then click Capture Selected Window Frame.")

    def capture_selected_window(self):
        if not self.need_project(): return
        data=self.window_box.currentData()
        if not data:
            self.select_window(); data=self.window_box.currentData()
        if not data:
            QMessageBox.information(self,"No window","No capturable window is selected."); return
        try:
            import cv2, time
            frame=grab_window(int(data["hwnd"]))
            raw=self.current_dataset/"images"/"raw"; raw.mkdir(parents=True,exist_ok=True)
            target=raw/f"window_{int(time.time()*1000)}.jpg"
            cv2.imwrite(str(target),frame)
            self.update_stats(); self.chat.append(f"SYSTEM: Captured '{data['title']}' to dataset: {target}")
        except Exception as e:
            self.chat.append(f"SYSTEM ERROR: Window capture failed: {type(e).__name__}: {e}")

    def _engine(self):
        if not self.need_project():return None
        return ActionEngine(self.current_project,self.current_dataset)

    def start_auto_build(self,quick=False):
        eng=self._engine()
        if not eng:return
        # Optional manual model choice overrides the hardware default for this run.
        chosen=self.cv_model.currentText()
        if chosen!="Auto (hardware)":
            def annotate_override(progress_cb=None):
                h=detect_hardware(str(self.current_project)); p=training_preset(h)
                return eng.pipeline.auto_annotate_person(model_name=chosen,conf=.25,device=p["device"],progress_cb=progress_cb,target_name=self.project_brief.get("target_class") or "person")
            eng.auto_annotate=annotate_override
            def review_override(progress_cb=None):
                h=detect_hardware(str(self.current_project)); p=training_preset(h)
                from app.vision.review import build_annotation_review
                return build_annotation_review(self.current_dataset,model_name=chosen,device=p["device"],progress_cb=progress_cb)
            eng.review_annotations=review_override
            def small_review_override(progress_cb=None):
                h=detect_hardware(str(self.current_project)); p=training_preset(h)
                from app.vision.small_target import small_target_review
                return small_target_review(self.current_dataset,model_name=chosen,device=p["device"],progress_cb=progress_cb)
            eng.small_target_review=small_review_override
            def vlm_review_override(progress_cb=None):
                h=detect_hardware(str(self.current_project)); p=training_preset(h)
                from app.vision.vlm_review import vlm_review_queue
                target=self.project_brief.get("target_class") or "person"
                return vlm_review_queue(self.current_dataset,model_name=chosen,device=p["device"],target=target,progress_cb=progress_cb)
            eng.vlm_review_annotations=vlm_review_override
            def train_override(quick=False,progress_cb=None):
                h=detect_hardware(str(self.current_project)); p=training_preset(h)
                from app.training.pipeline import TrainingConfig
                high=(self.project_brief.get("target_class") or "person") in {"enemy","person","soldier","human"}
                cfg=TrainingConfig(model=chosen,epochs=5 if quick else p["epochs"],imgsz=p.get("small_target_imgsz",p["imgsz"]) if high else p["imgsz"],batch=p.get("small_target_batch",p["batch"]) if high else p["batch"],workers=p["workers"],device=p["device"],amp=p["amp"])
                return eng.pipeline.train(cfg,progress_cb=progress_cb)
            eng.train=train_override
        self.progress.setVisible(True); self.progress.setValue(0); self.progress_detail.setText("Starting..."); self.action_status.setText("Starting autonomous pipeline...")
        self.run_started_at=time.time(); self.last_progress_pct=0; self.monitor_timer.start()
        self.action_worker=ActionWorker(eng,"auto_build",quick=quick)
        self.action_worker.status.connect(lambda s:(self.action_status.setText(s),self.chat.append("SYSTEM: "+s)))
        self.action_worker.progress.connect(self.on_action_progress)
        def done(result):
            self.monitor_timer.stop(); self.progress.setValue(100); self.last_progress_pct=100
            self.progress_detail.setText("100% — AUTO BUILD COMPLETE"); self.action_status.setText("AUTO BUILD COMPLETE"); self.update_stats(); self.chat.append("SYSTEM: AUTO BUILD COMPLETE. Final output bundle created.")
            try:
                review=result[1]; small=result[2]; vision=result[3]; hard=result[6]; improvement=result[7]; bundle=result[-1]
                self.review_status.setText(f"Smart YOLO: +{review.get('rescued_images',0)} image(s). Small-target: +{small.get('rescued_images',0)} image(s), marker proposals {small.get('marker_only_proposals',0)}. Vision: {vision.get('status')} +{vision.get('rescued_images',0)} image(s), {vision.get('still_needing_review',small.get('still_needing_review',0))} still queued. Hard examples: {hard.get('hard_examples',0)} | Improvement: {improvement.get('status')}")
                self.output_label.setText(f"READY:\n{bundle['best_pt']}\n{bundle['script']}\n{bundle['run_bat']}")
            except Exception: pass
            self.update_live_monitor()
        def failed(err):
            self.monitor_timer.stop(); self.progress_detail.setText("FAILED — "+err); self.action_status.setText("FAILED: "+err)
            log_dir=self.paths["root"]/"logs"
            try:
                (log_dir).mkdir(parents=True,exist_ok=True); (log_dir/"last_action_error.txt").write_text(err,encoding="utf-8")
                rep=safe_repair(err,log_dir)
                msg=f"Self-heal diagnosis: {rep.cause} Action: {rep.action}"
            except Exception as re:
                msg=f"Self-heal diagnosis failed: {re}"
            self.chat.append("SYSTEM ERROR: "+err+"\n"+msg)
            self.update_live_monitor()
        self.action_worker.done.connect(done); self.action_worker.failed.connect(failed); self.action_worker.start()

    def on_action_progress(self,pct,msg):
        self.last_progress_pct=pct; self.progress.setValue(pct); self.progress_detail.setText(f"{pct}% — {msg}")
        self.update_live_monitor()

    def update_live_monitor(self):
        try:
            snap=live_snapshot()
            elapsed=max(0,int(time.time()-(self.run_started_at or time.time())))
            eta="calculating"
            if 0 < self.last_progress_pct < 100 and elapsed>0:
                remaining=int(elapsed*(100-self.last_progress_pct)/self.last_progress_pct)
                eta=f"~{remaining//60}m {remaining%60}s"
            elif self.last_progress_pct>=100: eta="done"
            gpu=(f"GPU {snap['gpu_util_percent']:.0f}% | VRAM {snap['vram_used_mb']}/{snap['vram_total_mb']} MB | {snap['gpu_temp_c']:.0f}°C"
                 if snap.get('gpu_util_percent') is not None else "GPU telemetry unavailable")
            self.live_monitor.setText(f"Elapsed {elapsed//60}m {elapsed%60}s | ETA {eta} | {gpu} | CPU {snap['cpu_percent']}% | RAM {snap['ram_percent']}%")
        except Exception as e:
            self.live_monitor.setText(f"Live monitor unavailable: {e}")

    def export_bundle(self):
        eng=self._engine()
        if not eng:return
        try:
            b=eng.export(); self.output_label.setText(f"READY:\n{b['best_pt']}\n{b['script']}\n{b['run_bat']}"); self.chat.append("SYSTEM: Exported final best.pt + Python bundle.")
        except Exception as e: QMessageBox.warning(self,"Export not ready",str(e))

    def make_snapshot(self):
        try:p=self.recovery.snapshot(); self.repair_status.setText(f"Snapshot created: {p}")
        except Exception as e:self.repair_status.setText(f"Snapshot failed: {e}")
    def reset_settings(self):
        try:r=self.recovery.reset_settings(); self.repair_status.setText("Settings reset safely. Projects/models preserved.\n"+json.dumps(r,indent=2))
        except Exception as e:self.repair_status.setText(f"Reset failed: {e}")
    def restore_snapshot(self):
        try:p=self.recovery.restore_last_known_good(); self.repair_status.setText(f"Restored Last Known Good settings from: {p}")
        except Exception as e:self.repair_status.setText(f"Restore failed: {e}")
