from __future__ import annotations

import hashlib
import json
import re
import shutil
import subprocess
import sys
import time
import urllib.parse
import urllib.request
import zipfile
from dataclasses import dataclass
from html.parser import HTMLParser
from pathlib import Path

from app.knowledge.store import KnowledgeStore

CURRENT_VERSION = "0.9.4.1"
DEFAULT_SETTINGS = {
    "mode": "automatic",
    "knowledge_interval_hours": 24,
    "software_interval_hours": 24,
    "software_manifest_url": "https://raw.githubusercontent.com/pungus4you/ROBO_VISION_AI_UPDATES/main/manifest.json",
    "auto_stage_verified_updates": True,
    "last_check_epoch": 0,
    "last_knowledge_refresh_epoch": 0,
    "last_software_check_epoch": 0,
}

DEFAULT_SOURCES = [
    {"id":"ultralytics_docs_home","title":"Ultralytics Documentation","url":"https://docs.ultralytics.com/","enabled":True,"max_bytes":2000000},
    {"id":"ollama_releases","title":"Ollama Releases","url":"https://github.com/ollama/ollama/releases","enabled":True,"max_bytes":2000000},
]

class _TextExtractor(HTMLParser):
    def __init__(self):
        super().__init__(); self.parts=[]; self._skip=0
    def handle_starttag(self, tag, attrs):
        if tag in {"script","style","svg","noscript"}: self._skip += 1
        elif tag in {"p","div","li","br","h1","h2","h3","h4","tr"} and not self._skip: self.parts.append("\n")
    def handle_endtag(self, tag):
        if tag in {"script","style","svg","noscript"} and self._skip: self._skip -= 1
        elif tag in {"p","div","li","h1","h2","h3","h4","tr"} and not self._skip: self.parts.append("\n")
    def handle_data(self, data):
        if not self._skip: self.parts.append(data)
    def text(self):
        s=" ".join(self.parts); s=re.sub(r"[ \t\r\f\v]+"," ",s); s=re.sub(r"\n\s*\n+","\n\n",s); return s.strip()

@dataclass
class UpdateResult:
    status: str
    details: dict


def _version_tuple(v: str):
    nums=[int(x) for x in re.findall(r"\d+", str(v))[:4]]
    return tuple(nums + [0]*(4-len(nums)))

class UpdateManager:
    def __init__(self, root: Path, build_dir: Path):
        self.root=Path(root); self.build_dir=Path(build_dir)
        self.config_dir=self.root/"config"; self.update_dir=self.root/"updates"; self.staging_dir=self.update_dir/"staging"
        self.download_dir=self.update_dir/"downloads"; self.logs_dir=self.root/"logs"; self.backup_dir=self.update_dir/"rollback"
        for p in (self.config_dir,self.update_dir,self.staging_dir,self.download_dir,self.logs_dir,self.backup_dir): p.mkdir(parents=True,exist_ok=True)
        self.settings_path=self.config_dir/"update_settings.json"; self.sources_path=self.config_dir/"knowledge_sources.json"; self.state_path=self.update_dir/"update_state.json"
        self.knowledge=KnowledgeStore(self.root); self._ensure_defaults()

    def _ensure_defaults(self):
        if not self.settings_path.exists(): self.settings_path.write_text(json.dumps(DEFAULT_SETTINGS,indent=2),encoding="utf-8")
        if not self.sources_path.exists(): self.sources_path.write_text(json.dumps(DEFAULT_SOURCES,indent=2),encoding="utf-8")

    def settings(self):
        try:
            d=json.loads(self.settings_path.read_text(encoding="utf-8")); m=dict(DEFAULT_SETTINGS); m.update(d if isinstance(d,dict) else {}); return m
        except Exception: return dict(DEFAULT_SETTINGS)

    def save_settings(self,data):
        m=dict(DEFAULT_SETTINGS); m.update(data)
        if m.get("mode") not in {"automatic","notify","offline"}: m["mode"]="notify"
        m["software_manifest_url"]=str(m.get("software_manifest_url") or "").strip()
        self.settings_path.write_text(json.dumps(m,indent=2),encoding="utf-8"); return m

    def sources(self):
        try:
            d=json.loads(self.sources_path.read_text(encoding="utf-8")); return d if isinstance(d,list) else list(DEFAULT_SOURCES)
        except Exception: return list(DEFAULT_SOURCES)

    def internet_available(self,timeout=2.5):
        for url in ("https://docs.ultralytics.com/","https://github.com/"):
            try:
                req=urllib.request.Request(url,method="HEAD",headers={"User-Agent":f"ROBO-Vision-AI/{CURRENT_VERSION}"})
                with urllib.request.urlopen(req,timeout=timeout) as r:
                    if 200 <= getattr(r,"status",200) < 500: return True
            except Exception: pass
        return False

    def due_for_knowledge_refresh(self):
        s=self.settings(); h=max(1,int(s.get("knowledge_interval_hours",24))); last=float(s.get("last_knowledge_refresh_epoch",0) or 0); return time.time()-last >= h*3600
    def due_for_software_check(self):
        s=self.settings(); h=max(1,int(s.get("software_interval_hours",24))); last=float(s.get("last_software_check_epoch",0) or 0); return time.time()-last >= h*3600

    def _fetch(self,url,max_bytes,timeout=20):
        parsed=urllib.parse.urlparse(url)
        if parsed.scheme not in {"https","file"}: raise ValueError("Only HTTPS or local file:// update sources are allowed")
        req=urllib.request.Request(url,headers={"User-Agent":f"ROBO-Vision-AI/{CURRENT_VERSION}"})
        with urllib.request.urlopen(req,timeout=timeout) as r:
            ctype=r.headers.get("Content-Type",""); data=r.read(max_bytes+1)
        if len(data)>max_bytes: raise ValueError("download exceeded configured maximum size")
        return data,ctype

    def _to_text(self,data,ctype):
        text=data.decode("utf-8",errors="ignore")
        if "html" in ctype.lower() or "<html" in text[:500].lower():
            p=_TextExtractor(); p.feed(text); return p.text()
        return text.strip()

    def _write_state(self,patch):
        state={}
        if self.state_path.exists():
            try: state=json.loads(self.state_path.read_text(encoding="utf-8"))
            except Exception: state={}
        state.update(patch); self.state_path.write_text(json.dumps(state,indent=2,ensure_ascii=False),encoding="utf-8")

    def state(self):
        try: return json.loads(self.state_path.read_text(encoding="utf-8")) if self.state_path.exists() else {}
        except Exception: return {}

    def refresh_knowledge(self,force=False):
        s=self.settings()
        if s.get("mode")=="offline": return UpdateResult("skipped",{"reason":"Offline Only mode is enabled."})
        if not force and not self.due_for_knowledge_refresh(): return UpdateResult("skipped",{"reason":"Knowledge refresh is not due yet."})
        if not self.internet_available(): return UpdateResult("offline",{"reason":"No internet connection detected. Existing local knowledge remains available."})
        refreshed=[]; failures=[]; now=time.strftime("%Y-%m-%dT%H:%M:%S%z")
        for src in self.sources():
            if not src.get("enabled",True): continue
            try:
                data,ctype=self._fetch(src["url"],int(src.get("max_bytes",2000000))); text=self._to_text(data,ctype)
                if len(text)<40: raise RuntimeError("downloaded content was unexpectedly small")
                digest=hashlib.sha256(data).hexdigest(); refreshed.append(self.knowledge.add_document(source_id=str(src.get("id") or digest[:12]),title=str(src.get("title") or src["url"]),url=str(src["url"]),text=text,fetched_at=now,sha256=digest))
            except Exception as e: failures.append({"source":src.get("id",src.get("url")),"error":f"{type(e).__name__}: {e}"})
        s["last_check_epoch"]=int(time.time())
        if refreshed: s["last_knowledge_refresh_epoch"]=int(time.time())
        self.save_settings(s); result={"refreshed":refreshed,"failures":failures,"knowledge_index":str(self.knowledge.index_path)}; self._write_state({"last_knowledge_result":result,"updated_at":now}); return UpdateResult("complete" if refreshed else "failed",result)

    def _validate_manifest(self,m):
        req={"version","package_url","sha256"}
        if not isinstance(m,dict) or not req.issubset(m): raise ValueError("manifest must contain version, package_url and sha256")
        if len(str(m.get("sha256")))!=64 or not re.fullmatch(r"[0-9a-fA-F]{64}",str(m.get("sha256"))): raise ValueError("manifest sha256 must be 64 hex characters")
        # package_url may be HTTPS/file:// or a relative path. Relative package URLs
        # are resolved against the manifest URL before validation.
        package_url=str(m.get("package_url") or "").strip()
        parsed_pkg=urllib.parse.urlparse(package_url)
        if parsed_pkg.scheme and parsed_pkg.scheme not in {"https","file"}:
            raise ValueError("package_url must use HTTPS, file://, or be relative to the manifest")
        min_v=str(m.get("min_current_version") or "0")
        if _version_tuple(CURRENT_VERSION) < _version_tuple(min_v): raise ValueError(f"This updater is too old; manifest requires at least {min_v}")
        return m

    def check_software_manifest(self):
        s=self.settings()
        if s.get("mode")=="offline": return UpdateResult("skipped",{"reason":"Offline Only mode is enabled."})
        url=str(s.get("software_manifest_url") or "").strip()
        if not url: return UpdateResult("not_configured",{"reason":"No trusted ROBO software manifest URL is configured. Knowledge updates still work."})
        parsed=urllib.parse.urlparse(url)
        if parsed.scheme not in {"https","file"}: return UpdateResult("rejected",{"reason":"Manifest URL must use HTTPS or file://"})
        if parsed.scheme=="https" and not self.internet_available(): return UpdateResult("offline",{"reason":"No internet connection detected."})
        try:
            data,_=self._fetch(url,1_000_000)
            raw_manifest=json.loads(data.decode("utf-8-sig"))
            # Static HTTPS feeds are easier to publish when package_url is relative.
            # Resolve it against the manifest URL before the normal trust checks.
            if isinstance(raw_manifest,dict):
                pkg=str(raw_manifest.get("package_url") or "").strip()
                if pkg and not urllib.parse.urlparse(pkg).scheme:
                    raw_manifest=dict(raw_manifest)
                    raw_manifest["package_url"]=urllib.parse.urljoin(url,pkg)
            manifest=self._validate_manifest(raw_manifest)
            s["last_software_check_epoch"]=int(time.time()); self.save_settings(s)
            status="up_to_date" if _version_tuple(manifest["version"]) <= _version_tuple(CURRENT_VERSION) else "available"
            payload=dict(manifest); payload["current_version"]=CURRENT_VERSION; payload["manifest_url"]=url
            self._write_state({"available_manifest":payload,"checked_at":time.strftime("%Y-%m-%dT%H:%M:%S%z")})
            return UpdateResult(status,payload)
        except Exception as e: return UpdateResult("failed",{"error":f"{type(e).__name__}: {e}"})

    def stage_software_update(self,manifest=None):
        from_state = manifest is None
        if manifest is None: manifest=self.state().get("available_manifest") or {}
        try: manifest=self._validate_manifest(manifest)
        except Exception as e: return UpdateResult("failed",{"reason":str(e)})
        if from_state and _version_tuple(manifest["version"]) <= _version_tuple(CURRENT_VERSION): return UpdateResult("not_newer",{"current_version":CURRENT_VERSION,"version":manifest["version"]})
        try:
            data,_=self._fetch(str(manifest["package_url"]),int(manifest.get("max_bytes",500_000_000)),timeout=120); actual=hashlib.sha256(data).hexdigest(); expected=str(manifest["sha256"]).lower()
            if actual!=expected: return UpdateResult("rejected",{"reason":"SHA256 mismatch","expected":expected,"actual":actual})
            version=str(manifest["version"]); target=self.staging_dir/f"ROBO_UPDATE_{version}.zip"; target.write_bytes(data)
            meta={"version":version,"path":str(target),"sha256":actual,"status":"staged_verified","release_notes":manifest.get("release_notes","")}; (self.staging_dir/f"ROBO_UPDATE_{version}.json").write_text(json.dumps(meta,indent=2),encoding="utf-8"); self._write_state({"staged_update":meta}); return UpdateResult("staged",meta)
        except Exception as e: return UpdateResult("failed",{"error":f"{type(e).__name__}: {e}"})

    def _safe_extract(self,zip_path,dest):
        dest=Path(dest).resolve(); dest.mkdir(parents=True,exist_ok=True)
        with zipfile.ZipFile(zip_path) as z:
            for member in z.infolist():
                p=(dest/member.filename).resolve()
                if dest not in p.parents and p!=dest: raise ValueError("unsafe path found in update package")
            z.extractall(dest)

    def test_staged_update(self):
        st=self.state().get("staged_update") or {}
        staged_version=str(st.get("version") or "").strip()
        if staged_version and _version_tuple(staged_version) <= _version_tuple(CURRENT_VERSION):
            return UpdateResult("not_newer",{"current_version":CURRENT_VERSION,"version":staged_version,"message":"Skipping tests because this package is not newer than the running ROBO version."})
        raw_path=str(st.get("path") or "").strip()
        if not raw_path:
            return UpdateResult("failed",{"reason":"No staged verified update package exists. Run Check Channel and Stage + Verify first."})
        zp=Path(raw_path)
        if not zp.is_file():
            return UpdateResult("failed",{"reason":"No staged verified update package exists. Run Stage + Verify first.","path":raw_path})
        version=str(st.get("version") or "unknown"); test_dir=self.staging_dir/f"extracted_{version}"
        if test_dir.exists(): shutil.rmtree(test_dir)
        try:
            self._safe_extract(zp,test_dir)
            # Resolve package root whether zip contains one top-level folder or direct files.
            roots=[p for p in test_dir.iterdir()]
            pkg=test_dir
            if len(roots)==1 and roots[0].is_dir(): pkg=roots[0]
            required=["START_ROBO_VISION.bat","INSTALL.bat","app","ROBO_IDENTITY_MASTER.json"]
            missing=[x for x in required if not (pkg/x).exists()]
            if missing: return UpdateResult("rejected",{"reason":"Update package is incomplete","missing":missing,"extracted":str(pkg)})
            tests=pkg/"tests"
            test_result={"ran":False,"returncode":None,"output":"No tests folder; structural verification only."}
            if tests.exists():
                # Windows can deny access while pytest cleans its default %TEMP%\pytest-of-user\pytest-current link.
                # Keep candidate-test temp files inside ROBO's own staging area instead.
                pytest_tmp=self.staging_dir/f"pytest_tmp_{version}"
                if pytest_tmp.exists():
                    shutil.rmtree(pytest_tmp, ignore_errors=True)
                pytest_tmp.mkdir(parents=True, exist_ok=True)
                env=dict(__import__("os").environ)
                env["TMP"]=str(pytest_tmp)
                env["TEMP"]=str(pytest_tmp)
                cp=subprocess.run(
                    [sys.executable,"-m","pytest",str(tests),"-q",f"--basetemp={pytest_tmp / 'run'}"],
                    cwd=str(pkg),capture_output=True,text=True,timeout=180,env=env
                )
                out=(cp.stdout+"\n"+cp.stderr)[-12000:]; test_result={"ran":True,"returncode":cp.returncode,"output":out,"basetemp":str(pytest_tmp / "run")}
                if cp.returncode!=0: self._write_state({"last_candidate_test":test_result}); return UpdateResult("rejected",{"reason":"Candidate tests failed","test":test_result})
            meta={"version":version,"package_root":str(pkg),"status":"tested_ok","test":test_result,"tested_at":time.strftime("%Y-%m-%dT%H:%M:%S%z")}; self._write_state({"tested_update":meta,"last_candidate_test":test_result}); return UpdateResult("tested_ok",meta)
        except Exception as e: return UpdateResult("failed",{"error":f"{type(e).__name__}: {e}"})

    def prepare_activation(self):
        tested=self.state().get("tested_update") or {}
        raw_src=str(tested.get("package_root") or "").strip(); version=str(tested.get("version") or "")
        if version and _version_tuple(version) <= _version_tuple(CURRENT_VERSION):
            return UpdateResult("not_newer",{"current_version":CURRENT_VERSION,"version":version,"message":"Activation skipped because the candidate is not newer than the running version."})
        if not raw_src or not version:
            return UpdateResult("failed",{"reason":"No tested update is ready for activation."})
        src=Path(raw_src)
        if not src.is_dir():
            return UpdateResult("failed",{"reason":"Tested update folder is missing.","path":raw_src})
        target=self.root/f"ROBO_VISION_AI_build_{version}_AUTO_UPDATE"
        try:
            if target.exists(): shutil.rmtree(target)
            shutil.copytree(src,target,ignore=shutil.ignore_patterns('.venv','__pycache__','.pytest_cache','*.pyc'))
            pending={"version":version,"build_path":str(target),"previous_build":str(self.build_dir),"status":"ready_to_activate","prepared_at":time.strftime("%Y-%m-%dT%H:%M:%S%z")}
            self._write_state({"pending_activation":pending})
            launcher=self.root/"START_LATEST_ROBO.bat"
            launcher.write_text('@echo off\r\nset "ROBO_ACTIVE='+str(target)+'"\r\ncd /d "%ROBO_ACTIVE%"\r\ncall START_ROBO_VISION.bat\r\n',encoding="utf-8")
            return UpdateResult("ready_to_activate",{**pending,"launcher":str(launcher),"message":"Close the current ROBO window, then run START_LATEST_ROBO.bat. The current working build remains untouched for rollback."})
        except Exception as e: return UpdateResult("failed",{"error":f"{type(e).__name__}: {e}"})

    def launch_pending_activation(self):
        """Launch a tested update, health-check it, and preserve rollback."""
        pending=self.state().get("pending_activation") or {}
        version=str(pending.get("version") or "").strip()
        target=Path(str(pending.get("build_path") or ""))
        previous=Path(str(pending.get("previous_build") or ""))
        if not version or not target.is_dir():
            return UpdateResult("failed",{"reason":"No prepared update is ready to launch."})
        target_start=target/"START_ROBO_VISION.bat"
        previous_start=previous/"START_ROBO_VISION.bat"
        if not target_start.exists():
            return UpdateResult("failed",{"reason":"Prepared update is missing START_ROBO_VISION.bat.","path":str(target_start)})
        health_dir=self.update_dir/"health"; health_dir.mkdir(parents=True,exist_ok=True)
        marker=health_dir/f"{version}.ok"
        try: marker.unlink(missing_ok=True)
        except Exception: pass
        script=self.update_dir/"APPLY_PENDING_UPDATE.ps1"
        def esc(x): return str(x).replace("'","''")
        ps=("$ErrorActionPreference = 'SilentlyContinue'\n"
            + f"$target = '{esc(target_start)}'\n"
            + f"$previous = '{esc(previous_start)}'\n"
            + f"$targetDir = '{esc(target)}'\n"
            + f"$previousDir = '{esc(previous)}'\n"
            + f"$marker = '{esc(marker)}'\n"
            + "Start-Process -FilePath $target -WorkingDirectory $targetDir\n"
            + "$healthy = $false\n"
            + "for ($i=0; $i -lt 120; $i++) { Start-Sleep -Seconds 1; if (Test-Path $marker) { $healthy = $true; break } }\n"
            + "if (-not $healthy -and (Test-Path $previous)) { Start-Process -FilePath $previous -WorkingDirectory $previousDir }\n")
        script.write_text(ps,encoding="utf-8")
        try:
            subprocess.Popen(["powershell.exe","-NoProfile","-File",str(script)],cwd=str(self.root))
            self._write_state({"activation_launch":{"version":version,"status":"launched","health_marker":str(marker),"rollback_build":str(previous)}})
            return UpdateResult("restart_launched",{"version":version,"health_marker":str(marker),"message":"Candidate restart launched with automatic health-check and rollback."})
        except Exception as e:
            return UpdateResult("failed",{"error":f"{type(e).__name__}: {e}"})


    def create_trusted_feed(self, package_path, version=None, destination=None, release_notes=""):
        """Create a self-contained static feed folder with manifest.json + package ZIP.

        The manifest uses a relative package_url, so the same folder works via file://
        for local verification and via any static HTTPS host after upload.
        """
        package=Path(package_path)
        if not package.exists() or package.suffix.lower()!=".zip":
            return UpdateResult("failed",{"reason":"Choose an existing ROBO .zip package."})
        version=str(version or "").strip()
        if not version:
            m=re.search(r"build_([0-9]+(?:\.[0-9]+){1,3})",package.name,re.I)
            version=m.group(1) if m else ""
        if not version:
            return UpdateResult("failed",{"reason":"Could not determine package version from the filename."})
        feed=Path(destination) if destination else self.root/"trusted_feed"
        feed.mkdir(parents=True,exist_ok=True)
        out_pkg=feed/package.name
        if package.resolve()!=out_pkg.resolve(): shutil.copy2(package,out_pkg)
        digest=hashlib.sha256(out_pkg.read_bytes()).hexdigest()
        manifest={
            "version":version,
            "min_current_version":"0.9.2",
            "package_url":out_pkg.name,
            "sha256":digest,
            "release_notes":release_notes or f"ROBO Vision AI {version} trusted update package",
            "max_bytes":max(500_000_000,out_pkg.stat().st_size+10_000_000),
        }
        manifest_path=feed/"manifest.json"
        manifest_path.write_text(json.dumps(manifest,indent=2),encoding="utf-8")
        local_url=manifest_path.resolve().as_uri()
        publish_info={
            "manifest":str(manifest_path),
            "package":str(out_pkg),
            "manifest_url_local":local_url,
            "sha256":digest,
            "version":version,
            "hosting_note":"Upload manifest.json and the ZIP to the same static HTTPS folder; package_url is relative.",
        }
        (feed/"PUBLISH_README.txt").write_text(
            "ROBO trusted update feed\n\n"
            "1. Keep manifest.json and the ZIP in the same folder.\n"
            "2. For local testing, use this manifest URL:\n"+local_url+"\n\n"
            "3. For internet updates, upload both files to the same static HTTPS folder, then set ROBO's Manifest URL to the HTTPS address of manifest.json.\n",
            encoding="utf-8")
        self._write_state({"last_feed_publish":publish_info})
        return UpdateResult("feed_ready",publish_info)

    def use_local_feed(self, manifest_path=None):
        path=Path(manifest_path) if manifest_path else self.root/"trusted_feed"/"manifest.json"
        if not path.exists(): return UpdateResult("failed",{"reason":"Local trusted feed manifest does not exist yet."})
        s=self.settings(); s["software_manifest_url"]=path.resolve().as_uri(); self.save_settings(s)
        return UpdateResult("configured",{"manifest_url":s["software_manifest_url"],"message":"Local trusted feed configured. Use Check Channel or Run Full Safe Update Cycle."})

    def automatic_software_cycle(self):
        chk=self.check_software_manifest()
        if chk.status!="available": return chk
        if not self.settings().get("auto_stage_verified_updates",True): return UpdateResult("available",chk.details)
        st=self.stage_software_update(chk.details)
        if st.status!="staged": return st
        tst=self.test_staged_update()
        if tst.status!="tested_ok": return tst
        return self.prepare_activation()

    def startup_action(self):
        s=self.settings()
        if s.get("mode")=="offline": return UpdateResult("offline_mode",{"message":"Offline Only: no network checks were made."})
        messages=[]; details={}
        if self.due_for_knowledge_refresh():
            if s.get("mode")=="notify": messages.append("Knowledge refresh is due.")
            else:
                kr=self.refresh_knowledge(force=True); details["knowledge"]={"status":kr.status,"details":kr.details}; messages.append(f"Knowledge: {kr.status}.")
        else: messages.append("Knowledge is within the configured refresh interval.")
        if str(s.get("software_manifest_url") or "").strip() and self.due_for_software_check():
            if s.get("mode")=="notify": messages.append("Software update check is due.")
            else:
                sw=self.automatic_software_cycle(); details["software"]={"status":sw.status,"details":sw.details}; messages.append(f"Software: {sw.status}.")
        elif not str(s.get("software_manifest_url") or "").strip(): messages.append("Software channel not configured.")
        return UpdateResult("complete",{"message":" ".join(messages),**details})
