import hashlib, json, zipfile
from pathlib import Path
from app.update.manager import UpdateManager, _version_tuple

def make_build_zip(path: Path):
    root=path.parent/'candidate'; (root/'app').mkdir(parents=True); (root/'app'/'__init__.py').write_text('',encoding='utf-8'); (root/'tests').mkdir(parents=True)
    for name in ['START_ROBO_VISION.bat','INSTALL.bat','ROBO_IDENTITY_MASTER.json']:
        (root/name).write_text('{}' if name.endswith('.json') else '@echo off',encoding='utf-8')
    (root/'tests'/'test_smoke.py').write_text('def test_smoke():\n    assert True\n',encoding='utf-8')
    with zipfile.ZipFile(path,'w') as z:
        for p in root.rglob('*'):
            if p.is_file(): z.write(p,p.relative_to(root.parent))

def test_version_compare(): assert _version_tuple('0.9.3') > _version_tuple('0.9.2')

def test_local_manifest_stage_test_prepare(tmp_path):
    build=tmp_path/'current'; build.mkdir(); pkg=tmp_path/'next.zip'; make_build_zip(pkg)
    sha=hashlib.sha256(pkg.read_bytes()).hexdigest(); manifest={'version':'0.9.4.2','package_url':pkg.as_uri(),'sha256':sha,'min_current_version':'0.9.2'}
    mf=tmp_path/'manifest.json'; mf.write_text(json.dumps(manifest),encoding='utf-8')
    m=UpdateManager(tmp_path/'root',build); s=m.settings(); s['software_manifest_url']=mf.as_uri(); m.save_settings(s)
    assert m.check_software_manifest().status=='available'
    assert m.stage_software_update().status=='staged'
    assert m.test_staged_update().status=='tested_ok'
    r=m.prepare_activation(); assert r.status=='ready_to_activate'; assert Path(r.details['build_path']).exists()

def test_bad_hash_rejected(tmp_path):
    build=tmp_path/'current'; build.mkdir(); pkg=tmp_path/'bad.zip'; pkg.write_bytes(b'bad')
    m=UpdateManager(tmp_path/'root',build)
    r=m.stage_software_update({'version':'9.9.9','package_url':pkg.as_uri(),'sha256':'0'*64})
    assert r.status=='rejected'
