@echo off
cd /d "%~dp0"
powershell.exe -NoProfile -File "%~dp0ROBO_PORTABLE_SETUP.ps1"
if errorlevel 1 pause
