@echo off
cd /d "%~dp0"
powershell.exe -NoProfile -File "%~dp0SELF_REPAIR.ps1"
pause
