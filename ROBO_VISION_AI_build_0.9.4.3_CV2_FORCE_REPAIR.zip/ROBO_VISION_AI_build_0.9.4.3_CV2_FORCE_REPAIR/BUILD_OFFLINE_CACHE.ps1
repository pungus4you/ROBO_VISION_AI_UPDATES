$ErrorActionPreference="Stop"
$Root=$PSScriptRoot; $Cache=Join-Path $Root "offline_cache"; New-Item -ItemType Directory -Force -Path $Cache|Out-Null
$py=$null
try { py -3.11 --version *> $null; if($LASTEXITCODE -eq 0){$py=@("py","-3.11")} } catch {}
if(-not $py){ try { python --version *> $null; if($LASTEXITCODE -eq 0){$py=@("python")} } catch {} }
if(-not $py){ throw "Python 3.11/3.12 is required on this ONLINE PC to build the offline cache." }
$exe=$py[0]; $prefix=@(); if($py.Count -gt 1){$prefix=$py[1..($py.Count-1)]}
Write-Host "Downloading normal dependencies to offline_cache..." -ForegroundColor Cyan
& $exe @prefix -m pip download -d $Cache -r (Join-Path $Root "requirements.txt")
Write-Host "Downloading CUDA 12.6 PyTorch wheels..." -ForegroundColor Cyan
& $exe @prefix -m pip download -d $Cache torch torchvision --index-url https://download.pytorch.org/whl/cu126
Write-Host "Offline package cache ready at $Cache" -ForegroundColor Green
Write-Host "Copy the entire ROBO folder, including offline_cache, to the offline PC."
