ROBO trusted update feed

1. Keep manifest.json and the ZIP in the same folder.
2. For local testing, use this manifest URL:
file:///mnt/data/ROBO_VISION_AI_build_0.9.4.3_CV2_FORCE_REPAIR/.robo_pytest_tmp/test_create_feed_and_relative_0/root/trusted_feed/manifest.json

3. For internet updates, upload both files to the same static HTTPS folder, then set ROBO's Manifest URL to the HTTPS address of manifest.json.
