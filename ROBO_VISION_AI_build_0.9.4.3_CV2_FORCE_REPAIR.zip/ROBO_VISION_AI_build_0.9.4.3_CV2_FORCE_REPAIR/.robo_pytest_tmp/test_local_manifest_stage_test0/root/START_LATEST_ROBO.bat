@echo off
set "ROBO_ACTIVE=/mnt/data/ROBO_VISION_AI_build_0.9.4.3_CV2_FORCE_REPAIR/.robo_pytest_tmp/test_local_manifest_stage_test0/root/ROBO_VISION_AI_build_0.9.4.4_AUTO_UPDATE"
cd /d "%ROBO_ACTIVE%"
call START_ROBO_VISION.bat
