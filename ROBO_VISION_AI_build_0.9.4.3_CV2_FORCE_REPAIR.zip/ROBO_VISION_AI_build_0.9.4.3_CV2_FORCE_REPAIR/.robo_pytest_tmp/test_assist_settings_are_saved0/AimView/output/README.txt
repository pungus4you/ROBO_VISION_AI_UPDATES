Double-click RUN.bat. Press Q to close.
Small-target mode uses 960px inference, model+marker fusion and a temporally confirmed marker fallback.
Feedback: press M then left-click a missed enemy; press X then left-click a wrong box.
Feedback is saved under the project\feedback folder for the next improvement cycle.
A separate ROBO Assist Controls window provides Auto/Manual visual assist strength, center-box size, confidence, marker boost and center bias.
Visual assist only highlights detections inside the guide box; it does not move the mouse, press keys or fire.
Edit config.json to tune confidence, marker_supported_confidence, marker_persistence_frames or imgsz.
