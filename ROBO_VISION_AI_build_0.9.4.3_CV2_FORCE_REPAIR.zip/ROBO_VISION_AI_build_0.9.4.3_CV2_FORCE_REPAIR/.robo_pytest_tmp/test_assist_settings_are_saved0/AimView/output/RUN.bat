@echo off
powershell -NoProfile -File "%~dp0RUN_DETECTOR.ps1"
echo.
echo ROBO detector session finished.
pause
