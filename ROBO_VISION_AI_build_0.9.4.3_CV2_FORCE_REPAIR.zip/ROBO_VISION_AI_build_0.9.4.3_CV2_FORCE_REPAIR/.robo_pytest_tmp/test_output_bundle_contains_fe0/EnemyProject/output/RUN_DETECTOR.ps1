$ErrorActionPreference = "Stop"
$Here = Split-Path -Parent $MyInvocation.MyCommand.Path
$Detector = Join-Path $Here "EnemyProject_detector.py"
function Test-Python($Exe) { try { & $Exe -c "import ultralytics, cv2, mss, numpy" *> $null; return ($LASTEXITCODE -eq 0) } catch { return $false } }
$candidates=@(); if ($env:ROBO_VISION_PYTHON) { $candidates += $env:ROBO_VISION_PYTHON }
$candidates += (Get-ChildItem "C:\ROBO_VISION_AI\ROBO_VISION_AI_build_*\.venv\Scripts\python.exe" -ErrorAction SilentlyContinue | Sort-Object FullName -Descending | ForEach-Object FullName)
$candidates += @("python.exe","py.exe")
foreach ($py in $candidates) { if (Test-Python $py) { Write-Host "Using Python: $py"; & $py $Detector; exit $LASTEXITCODE } }
Write-Host "Compatible Python not found. Attempting dependency repair with Python 3.11..."
$pycmd=Get-Command py.exe -ErrorAction SilentlyContinue
if ($pycmd) { & py -3.11 -m pip install -r (Join-Path $Here "requirements.txt"); if ($LASTEXITCODE -eq 0) { & py -3.11 $Detector; exit $LASTEXITCODE } }
Write-Host "Automatic repair could not finish. Run ROBO Vision AI Repair and retry."; exit 1
