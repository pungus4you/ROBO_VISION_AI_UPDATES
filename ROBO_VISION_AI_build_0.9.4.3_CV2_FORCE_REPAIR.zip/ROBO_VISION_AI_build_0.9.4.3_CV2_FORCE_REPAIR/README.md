# ROBO Vision AI 0.9.4.3 — Portable Bootstrap & Self-Repair

New in this milestone:
- Permanent GitHub update channel is the default for fresh installations.
- Portable setup can install/repair on another Windows PC.
- Safe fallback installation methods when a normal command is unavailable.
- Optional `offline_cache` support for machines without internet.
- `BUILD_OFFLINE_CACHE.bat` prepares wheels on an online PC for later offline use.
- `SELF_REPAIR.bat` verifies and repairs the local environment.
- Same-version updates are stopped before test/activation, preventing locked-file replacement attempts.
- User projects/models/config/knowledge remain outside replaceable software builds.

## On another PC
Copy/extract the whole build and run `ROBO_PORTABLE_SETUP.bat`. If online, it uses trusted online sources. If offline, include a populated `offline_cache` folder.

## Security behavior
ROBO does not bypass Windows security, antivirus, execution policy, or organization policy. It may try another supported installation route, and asks for normal Windows permission where required.

# ROBO Vision AI 0.9.3.4 — Bootstrap Candidate Test Fix

This build keeps the working 0.7.1 Windows hang fix and adds a dedicated far-distance target path.

### Autonomous 9-stage pipeline
1. Full-frame YOLO auto-label
2. Smart low-confidence YOLO review
3. **Small-target tile + red-marker review**
4. Local Ollama VLM verification of unresolved candidates
5. Train/validation/test preparation
6. **High-resolution baseline training** (RTX 3080 preset: 960px, batch 4)
7. Hard-example mining
8. Controlled candidate improvement with rollback
9. Export `best.pt` + detector + `RUN.bat`

### New in 0.8
- Overlapping 640px tile inference for tiny distant people/enemies.
- Red/orange head-marker detection as a second visual cue.
- Marker-only proposals are sent to VLM review instead of silently becoming training labels.
- Exported detector defaults to 960px inference and displays a red-marker fallback box for distant marked enemies.
- Dataset status no longer counts train/val/test copies as extra source images.
- ENEMY is recognized as a project target in chat.

### Safety/quality behavior
The red marker is a supporting cue, not proof by itself during training. The model still uses controlled review, VLM verification, hard-example analysis and rollback-safe improvement.

### Install
Extract to:
`C:\ROBO_VISION_AI\ROBO_VISION_AI_build_0.9.3.4_BOOTSTRAP_TEST_FIX`

Run `INSTALL.bat`, then `START_ROBO_VISION.bat`.

Recommended test command:
`Detect ENEMY. The enemy may be very small/far away and has a red marker above the head. Do everything automatically. Show live progress. Do not ask unless permission is required.`

## 0.8.1 Torch environment hotfix
- START_ROBO_VISION.bat now locks execution to this build's own `.venv\Scripts\python.exe`.
- Startup preflight verifies `torch`, CUDA, and Ultralytics before the GUI opens.
- If `torch` is missing, the launcher safely repairs CUDA PyTorch in the same ROBO environment and verifies the import before launching.
- In-app self-heal now has a dedicated CUDA-aware PyTorch repair path rather than treating `torch` as an unknown module.


## 0.8.2 Feedback refinement
- Training terminal now prints an explicit AUTO BUILD COMPLETE banner after export.
- Exported live detector reduces red-marker false positives using tighter marker geometry, model+marker fusion and temporal persistence.
- During live detection press **M**, then left-click a missed enemy to save feedback.
- Press **X**, then left-click a wrong detection to save false-positive feedback.
- Feedback is stored under the project `feedback` folder for later improvement cycles.
- Small-target review merges newly rescued boxes with existing labels instead of replacing prior labels.
- Exported detector opens a separate **ROBO Assist Controls** window.
- Controls include Auto/Manual mode, visual assist strength, center assist-box size, manual confidence, marker boost, and center bias.
- The assist box highlights/selects detected targets visually only; it does not move the mouse, press keys, fire, or bypass game security/anti-cheat.
- Assist settings are saved locally in `assist_settings.json` beside the detector and restored next time.


## 0.9 Identity + Update Manager
- Adds a protected `ROBO_IDENTITY.json` under the shared ROBO config folder and a build-shipped `ROBO_IDENTITY_MASTER.json`.
- On every launch ROBO verifies protected identity fields. If they drift or become unreadable, ROBO backs up the old file and repairs the protected core identity while preserving non-core extensions.
- Adds Update Center with **Automatic**, **Notify Me**, and **Offline Only** modes.
- Automatic mode checks whether a knowledge refresh is due and, when internet is available, refreshes approved sources into the local offline knowledge store.
- Local chat retrieves relevant snippets from the refreshed knowledge store so newly downloaded information remains usable after internet is disconnected.
- Default approved sources include official Ultralytics documentation and Ollama release information. Sources are stored in `config\knowledge_sources.json` so they can be audited/changed.
- Software self-update is deliberately staged: a trusted manifest URL must be configured, package SHA256 must match, and downloaded code is kept in `updates\staging` rather than mutating the running build. Promotion/testing/rollback automation can build on this foundation.
- ROBO never uses update mode to bypass UAC, Windows permissions, antivirus, corporate controls or security mechanisms.


## 0.9.1 Update Center UI Fix
- Makes the left navigation permanently visible with stronger styling.
- Adds a visible Identity, Memory & Updates status card directly on AI Studio.
- Adds one-click OPEN UPDATE CENTER and VERIFY IDENTITY buttons to the main screen.
- Keeps Automatic / Notify Me / Offline Only controls in Update Center.
- Uses a unique 0.9.1 build folder so it cannot be confused with an older installation.


## 0.9.3 Trusted software update channel
ROBO can now use a user-configured trusted HTTPS manifest. A candidate package is downloaded to staging, verified against SHA256, extracted with path-traversal protection, structurally checked, project tests are run when present, and only then can ROBO prepare a separate versioned build for activation. The current build is never overwritten, so rollback remains available.

There is intentionally no hard-coded public ROBO update server in this build. Configure a manifest URL you control or trust. `TRUSTED_SOFTWARE_MANIFEST.example.json` shows the format. Knowledge refresh continues to work independently.


## 0.9.3 Trusted Feed Bootstrap

The Update Center can now create a complete static update feed from any future ROBO build ZIP. `CREATE TRUSTED FEED` writes `C:\ROBO_VISION_AI\trusted_feed\manifest.json`, copies the ZIP beside it, calculates SHA256 automatically, and uses a relative package URL. `USE LOCAL FEED` configures a file:// URL so the full channel can be tested without hosting. Upload the same manifest + ZIP to one static HTTPS folder for internet updates.


## 0.9.3.4 update-cycle validation release
This is a deliberately newer, fully testable build for validating the trusted update path from 0.9.3.1. It keeps the 0.9.3.1 manifest robustness fixes and all prior ROBO Vision AI features.


## 0.9.3.4 Windows candidate-test fix
Candidate update tests now run with a dedicated ROBO-owned pytest temp directory under the update staging area, avoiding Windows Access Denied failures caused by pytest cleanup in the user Temp folder.


## 0.9.3.4 automatic update reliability
- Candidate pytest runs use a ROBO-owned `--basetemp` folder instead of the user Temp pytest link.
- `Run Full Safe Update Cycle` now continues through check, SHA256 verification, candidate tests, activation preparation, and automatic restart.
- The candidate writes a startup health marker after its GUI launches.
- A PowerShell supervisor waits for that marker and reopens the previous working build automatically if the candidate does not become healthy.
- The current working build is never overwritten.


## Bootstrap compatibility
This candidate declares a project-local pytest basetemp in pyproject.toml so it can be tested safely even by ROBO 0.9.3.1, before the candidate updater code is active.

### 0.9.4.3 bootstrap validation fix
This build isolates candidate validation from a broken/locked OpenCV package in the currently running older ROBO venv. Full OpenCV verification still runs after the new environment is installed.


### 0.9.4.3 installer tools fix
Fixes a PowerShell argument-binding bug that could call `pip install` with no requirements during portable installation.

### 0.9.4.3 OpenCV force-repair hardening
If Windows leaves a partial/corrupt `cv2` package (for example, `cv2/config.py` is missing), ROBO no longer treats the installed package as healthy merely because pip lists it. Self-repair now removes the damaged OpenCV package from the ROBO virtual environment, removes stale `cv2` files when they are not locked, performs a clean reinstall, and verifies `import cv2` before continuing. It never disables Windows security; if Windows has the file open, ROBO asks for the normal close/retry path.
