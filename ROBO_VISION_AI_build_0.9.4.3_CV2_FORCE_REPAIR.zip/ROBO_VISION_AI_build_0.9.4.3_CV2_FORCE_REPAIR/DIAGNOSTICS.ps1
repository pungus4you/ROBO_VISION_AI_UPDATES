$Root="C:\ROBO_VISION_AI"
$Py="$Root\.venv\Scripts\python.exe"
Write-Host "=== ROBO Vision AI Diagnostics ===" -ForegroundColor Cyan
if(!(Test-Path $Py)){ Write-Host "FAIL: virtual environment missing" -ForegroundColor Red; exit 1 }
& $Py -c "from app.system.diagnostics import run_diagnostics; import json; print(json.dumps(run_diagnostics(),indent=2))"
