from app.projects.manager import ProjectManager
from app.dataset.manager import DatasetManager
def test_create_dataset(tmp_path):
    p=ProjectManager(tmp_path).create("P"); d=DatasetManager(p); ds=d.create("D"); assert (ds/"images/raw").exists(); assert d.stats(ds)["images"]==0
