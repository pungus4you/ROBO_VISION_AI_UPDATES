from pathlib import Path
from app.update.manager import UpdateManager, CURRENT_VERSION

def test_prepare_activation_skips_same_version(tmp_path):
    root=tmp_path/"root"; build=tmp_path/"build"; root.mkdir(); build.mkdir()
    m=UpdateManager(root,build)
    pkg=tmp_path/"pkg"; pkg.mkdir()
    m._write_state({"tested_update":{"package_root":str(pkg),"version":CURRENT_VERSION}})
    r=m.prepare_activation()
    assert r.status=="not_newer"
