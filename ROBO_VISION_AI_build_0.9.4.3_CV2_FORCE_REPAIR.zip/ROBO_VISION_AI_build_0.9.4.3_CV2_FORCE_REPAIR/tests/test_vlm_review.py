from app.ai.ollama import VISION_HINTS
from app.vision.vlm_review import parse_yes_no_json


def test_parse_yes_json():
    r=parse_yes_no_json('{"answer":"yes","confidence":0.87}')
    assert r["answer"]=="yes"
    assert abs(r["confidence"]-.87)<1e-6


def test_parse_percent_confidence():
    r=parse_yes_no_json('{"answer":"no","confidence":92}')
    assert r["answer"]=="no"
    assert abs(r["confidence"]-.92)<1e-6


def test_parse_fallback_words():
    assert parse_yes_no_json('yes, target visible')["answer"]=="yes"
    assert parse_yes_no_json('no target visible')["answer"]=="no"


def test_vision_hints_include_common_ollama_models():
    hints=' '.join(VISION_HINTS)
    assert 'llava' in hints
    assert 'qwen' in hints
