import numpy as np
import cv2
from app.vision.small_target import detect_red_markers, marker_enemy_box

def test_red_marker_detection_and_body_proposal():
    img=np.zeros((200,300,3),dtype=np.uint8)
    cv2.circle(img,(150,70),4,(0,0,255),-1)
    markers=detect_red_markers(img)
    assert markers
    box=marker_enemy_box(markers[0],300,200)
    assert box[0] < 150 < box[2]
    assert box[1] <= 70 < box[3]
