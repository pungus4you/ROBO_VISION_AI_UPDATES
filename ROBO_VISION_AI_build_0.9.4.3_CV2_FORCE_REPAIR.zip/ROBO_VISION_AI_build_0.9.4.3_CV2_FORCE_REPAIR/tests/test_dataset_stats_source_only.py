from pathlib import Path
from app.dataset.manager import DatasetManager

def test_stats_does_not_double_count_split_copies(tmp_path:Path):
    project=tmp_path/'p'; ds=DatasetManager(project).create('d')
    for name in ['a.jpg','b.jpg']:
        (ds/'images'/'raw'/name).write_bytes(b'x')
    (ds/'labels'/'raw'/'a.txt').write_text('0 .5 .5 .2 .2')
    (ds/'labels'/'raw'/'b.txt').write_text('')
    (ds/'images'/'train'/'a.jpg').write_bytes(b'x')
    s=DatasetManager(project).stats(ds)
    assert s['images']==2
    assert s['split_copies']==1
    assert s['positive_labeled']==1
