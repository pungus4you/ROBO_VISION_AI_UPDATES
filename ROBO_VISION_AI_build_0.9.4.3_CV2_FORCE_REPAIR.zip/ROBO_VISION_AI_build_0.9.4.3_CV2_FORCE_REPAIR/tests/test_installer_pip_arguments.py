from pathlib import Path


def test_pip_helper_does_not_shadow_powershell_args():
    text = (Path(__file__).resolve().parents[1] / "INSTALL.ps1").read_text(encoding="utf-8")
    assert "function Pip-Install([string[]]$PipArgs)" in text
    assert "pip install @PipArgs" in text
    assert "[string[]]$Args" not in text


def test_installer_tools_pass_requirements():
    text = (Path(__file__).resolve().parents[1] / "INSTALL.ps1").read_text(encoding="utf-8")
    assert 'Pip-Install @("--upgrade","pip","setuptools","wheel")' in text
