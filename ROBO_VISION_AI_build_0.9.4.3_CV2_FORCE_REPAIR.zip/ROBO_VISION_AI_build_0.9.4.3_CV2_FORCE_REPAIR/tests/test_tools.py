from app.ai.tools import ToolRegistry
def test_tools():
    r=ToolRegistry(); r.register("add","add",lambda a,b:a+b); assert r.call("add",a=2,b=3)==5
