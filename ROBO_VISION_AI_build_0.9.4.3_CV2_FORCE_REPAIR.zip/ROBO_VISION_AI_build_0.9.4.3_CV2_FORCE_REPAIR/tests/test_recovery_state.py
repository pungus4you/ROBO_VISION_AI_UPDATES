from app.recovery.state import RecoveryManager

def test_reset_and_restore(tmp_path):
    r=RecoveryManager(tmp_path)
    defaults=r.reset_settings()
    assert defaults["default_detector_model"]=="yolo26s.pt"
    snap=r.snapshot()
    (tmp_path/"config"/"settings.json").write_text("{}")
    r.restore_last_known_good()
    assert "yolo26s.pt" in (tmp_path/"config"/"settings.json").read_text()
