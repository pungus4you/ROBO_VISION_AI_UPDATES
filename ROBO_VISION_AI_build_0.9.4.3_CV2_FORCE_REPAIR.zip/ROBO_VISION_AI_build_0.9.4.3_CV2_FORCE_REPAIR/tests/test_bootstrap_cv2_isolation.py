from pathlib import Path


def test_cv2_bootstrap_isolation_hook_present():
    text=(Path(__file__).parent/'conftest.py').read_text(encoding='utf-8')
    assert '_host_cv2_healthy' in text
    assert 'test_feedback_refinement.py' in text
    assert 'test_small_target.py' in text
    assert 'sys.modules.pop' in text


def test_vlm_review_uses_lazy_cv2_import():
    text=(Path(__file__).parents[1]/'app'/'vision'/'vlm_review.py').read_text(encoding='utf-8')
    head=text.split('def vlm_review_queue',1)[0]
    body=text.split('def vlm_review_queue',1)[1]
    assert 'import cv2' not in head
    assert 'import cv2' in body
