import json
from pathlib import Path

from app.identity.manager import IdentityManager, DEFAULT_IDENTITY


def test_identity_created_and_repaired(tmp_path):
    master = tmp_path / 'master.json'
    master.write_text(json.dumps(DEFAULT_IDENTITY), encoding='utf-8')
    mgr = IdentityManager(tmp_path / 'home', master)
    first = mgr.ensure()
    assert first['identity']['product'] == 'ROBO Vision AI'
    assert Path(first['path']).exists()
    data = json.loads(Path(first['path']).read_text(encoding='utf-8'))
    data['purpose'] = 'wrong purpose'
    data['custom_note'] = 'keep me'
    Path(first['path']).write_text(json.dumps(data), encoding='utf-8')
    second = mgr.ensure()
    assert second['repaired'] is True
    assert second['identity']['purpose'] == DEFAULT_IDENTITY['purpose']
    assert second['identity']['custom_note'] == 'keep me'
    assert list((tmp_path/'home'/'backups'/'identity').glob('ROBO_IDENTITY_*.json'))
