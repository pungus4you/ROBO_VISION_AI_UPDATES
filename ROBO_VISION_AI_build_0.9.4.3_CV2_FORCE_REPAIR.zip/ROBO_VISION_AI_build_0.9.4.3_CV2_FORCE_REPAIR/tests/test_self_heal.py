from app.repair.self_heal import classify_error

def test_self_heal_classifies_cuda_oom():
    sig,cause=classify_error("torch.cuda.OutOfMemoryError: CUDA out of memory")
    assert sig=="cuda_oom" and "VRAM" in cause

def test_self_heal_unknown_is_safe():
    sig,_=classify_error("something completely new")
    assert sig=="unknown"
