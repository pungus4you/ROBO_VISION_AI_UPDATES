import json
from pathlib import Path
import numpy as np
import cv2

from app.output.generator import generate_output_bundle
from app.vision.small_target import detect_red_markers, _merge_boxes


def test_output_bundle_contains_feedback_and_refined_marker_config(tmp_path:Path):
    project=tmp_path/'EnemyProject'; project.mkdir()
    model=tmp_path/'best.pt'; model.write_bytes(b'model')
    out=generate_output_bundle(project,model,far_target_mode=True,class_name='enemy')
    output=Path(out['output_dir'])
    cfg=json.loads((output/'config.json').read_text(encoding='utf-8'))
    script=(output/'EnemyProject_detector.py').read_text(encoding='utf-8')
    run=(output/'RUN.bat').read_text(encoding='utf-8')
    assert cfg['marker_persistence_frames'] >= 2
    assert cfg['marker_supported_confidence'] < cfg['confidence']
    assert "feedback_mode='missed'" in script
    assert "feedback_mode='wrong_box'" in script
    assert "project feedback folder" in script
    assert 'ROBO detector session finished.' in run
    assert Path(out['feedback_dir']).name == 'feedback'


def test_marker_filter_rejects_large_red_hud_region_but_keeps_small_marker():
    img=np.zeros((300,500,3),dtype=np.uint8)
    cv2.circle(img,(250,140),4,(0,0,255),-1)
    cv2.rectangle(img,(210,90),(290,115),(0,0,255),-1)  # large HUD-like red patch
    markers=detect_red_markers(img)
    assert any((x1 <= 250 <= x2 and y1 <= 140 <= y2) for x1,y1,x2,y2 in markers)
    assert not any((x2-x1)>40 or (y2-y1)>30 for x1,y1,x2,y2 in markers)


def test_small_target_merge_preserves_existing_box_and_adds_new_one():
    existing=[[0.25,0.25,0.10,0.20]]
    new=[[0.75,0.70,0.08,0.18]]
    merged=_merge_boxes(existing,new,1000,800)
    assert existing[0] in merged
    assert new[0] in merged
    assert len(merged)==2
