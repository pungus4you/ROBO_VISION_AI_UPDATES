from pathlib import Path
from app.improvement.controller import score, candidate_is_better, build_candidate_dataset

def test_candidate_accept_rule():
    b={'map50_95':.40,'precision':.70,'recall':.60}
    c={'map50_95':.42,'precision':.71,'recall':.64}
    assert candidate_is_better(b,c)
    assert not candidate_is_better(b,{'map50_95':.35,'precision':.9,'recall':.9})

def test_candidate_dataset_keeps_eval_and_oversamples_train(tmp_path:Path):
    ds=tmp_path/'ds'
    for split in ('train','val','test'):
        (ds/'images'/split).mkdir(parents=True); (ds/'labels'/split).mkdir(parents=True)
    (ds/'images'/'train'/'a.jpg').write_bytes(b'x'); (ds/'labels'/'train'/'a.txt').write_text('0 0.5 0.5 0.2 0.2')
    (ds/'images'/'val'/'v.jpg').write_bytes(b'x'); (ds/'labels'/'val'/'v.txt').write_text('')
    (ds/'data.yaml').write_text(f'path: {ds.as_posix()}\ntrain: images/train\nval: images/val\ntest: images/test\n')
    out=tmp_path/'candidate'; r=build_candidate_dataset(ds,out,[{'split':'train','image':'a.jpg'}],copies=2)
    assert r['oversampled_train_images']==2
    assert (out/'images'/'train'/'a__hard1.jpg').exists()
    assert (out/'images'/'val'/'v.jpg').exists()
    assert f'path: {out.as_posix()}' in (out/'data.yaml').read_text()
