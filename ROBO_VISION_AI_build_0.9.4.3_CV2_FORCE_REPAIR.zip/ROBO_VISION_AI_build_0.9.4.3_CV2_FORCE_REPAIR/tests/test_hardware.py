from app.system.hardware import detect_hardware,training_preset
def test_hardware():
    h=detect_hardware(); p=training_preset(h); assert p["batch"]>=1; assert h.ram_gb>0
