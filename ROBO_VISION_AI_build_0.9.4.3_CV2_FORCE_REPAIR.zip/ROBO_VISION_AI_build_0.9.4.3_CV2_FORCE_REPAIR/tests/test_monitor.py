from app.system.monitor import live_snapshot

def test_live_snapshot_shape():
    x=live_snapshot()
    assert "cpu_percent" in x and "ram_percent" in x and "gpu_util_percent" in x
