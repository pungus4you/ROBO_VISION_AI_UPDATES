from pathlib import Path
from app.system.environment import environment_report

def test_environment_report_shape():
    r = environment_report(Path('.'))
    assert 'python_executable' in r
    assert 'torch_ok' in r
    assert 'cuda' in r
