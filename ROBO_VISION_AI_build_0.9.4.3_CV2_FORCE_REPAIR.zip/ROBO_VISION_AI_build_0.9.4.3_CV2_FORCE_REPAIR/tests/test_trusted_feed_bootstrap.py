from pathlib import Path
import json, zipfile
from app.update.manager import UpdateManager


def test_create_feed_and_relative_manifest(tmp_path):
    build=tmp_path/'build'; build.mkdir()
    pkg=tmp_path/'ROBO_VISION_AI_build_0.9.4.zip'
    with zipfile.ZipFile(pkg,'w') as z: z.writestr('hello.txt','x')
    m=UpdateManager(tmp_path/'root',build)
    r=m.create_trusted_feed(pkg)
    assert r.status=='feed_ready'
    manifest=json.loads((tmp_path/'root'/'trusted_feed'/'manifest.json').read_text())
    assert manifest['version']=='0.9.4'
    assert manifest['package_url']==pkg.name
    assert len(manifest['sha256'])==64
    u=m.use_local_feed()
    assert u.status=='configured'
    assert m.settings()['software_manifest_url'].startswith('file:')
