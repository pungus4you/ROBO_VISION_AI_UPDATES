import hashlib
import json
from pathlib import Path

from app.update.manager import UpdateManager


def test_offline_mode_makes_no_refresh(tmp_path):
    mgr = UpdateManager(tmp_path/'home', tmp_path/'build')
    s = mgr.settings(); s['mode'] = 'offline'; mgr.save_settings(s)
    result = mgr.startup_action()
    assert result.status == 'offline_mode'


def test_refresh_stores_downloaded_knowledge(tmp_path, monkeypatch):
    mgr = UpdateManager(tmp_path/'home', tmp_path/'build')
    mgr.sources_path.write_text(json.dumps([{'id':'test','title':'Test Docs','url':'https://example.test','enabled':True,'max_bytes':10000}]), encoding='utf-8')
    monkeypatch.setattr(mgr, 'internet_available', lambda timeout=2.5: True)
    html = b'<html><body><h1>Fresh Vision Notes</h1><p>Small targets benefit from careful high resolution review.</p></body></html>'
    monkeypatch.setattr(mgr, '_fetch', lambda url, max_bytes, timeout=20: (html, 'text/html'))
    result = mgr.refresh_knowledge(force=True)
    assert result.status == 'complete'
    hits = mgr.knowledge.search('small targets')
    assert hits and hits[0]['source_id'] == 'test'


def test_software_stage_rejects_bad_hash(tmp_path, monkeypatch):
    mgr = UpdateManager(tmp_path/'home', tmp_path/'build')
    monkeypatch.setattr(mgr, '_fetch', lambda url, max_bytes, timeout=60: (b'abc', 'application/zip'))
    manifest = {'version':'9.9','package_url':'https://example.test/pkg.zip','sha256':'0'*64}
    result = mgr.stage_software_update(manifest)
    assert result.status == 'rejected'
    assert result.details['reason'] == 'SHA256 mismatch'


def test_software_stage_accepts_verified_hash(tmp_path, monkeypatch):
    mgr = UpdateManager(tmp_path/'home', tmp_path/'build')
    payload=b'zip-bytes'
    digest=hashlib.sha256(payload).hexdigest()
    monkeypatch.setattr(mgr, '_fetch', lambda url, max_bytes, timeout=60: (payload, 'application/zip'))
    result = mgr.stage_software_update({'version':'0.9.1','package_url':'https://example.test/pkg.zip','sha256':digest})
    assert result.status == 'staged'
    assert Path(result.details['path']).read_bytes() == payload
