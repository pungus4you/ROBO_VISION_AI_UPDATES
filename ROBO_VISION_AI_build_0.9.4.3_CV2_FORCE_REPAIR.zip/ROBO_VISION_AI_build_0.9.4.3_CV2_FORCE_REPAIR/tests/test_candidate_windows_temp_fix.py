from pathlib import Path
from app.update.manager import CURRENT_VERSION


def test_candidate_tests_use_robo_owned_basetemp():
    text=(Path(__file__).parents[1]/"app"/"update"/"manager.py").read_text(encoding="utf-8")
    assert CURRENT_VERSION == "0.9.4.3"
    assert "pytest_tmp_{version}" in text
    assert "--basetemp=" in text
    assert 'env["TMP"]' in text and 'env["TEMP"]' in text
