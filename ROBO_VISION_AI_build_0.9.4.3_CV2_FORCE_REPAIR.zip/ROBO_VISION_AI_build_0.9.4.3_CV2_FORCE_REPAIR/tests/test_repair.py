from app.repair.knowledge import RepairKnowledge
def test_repair_db(tmp_path):
    k=RepairKnowledge(tmp_path/"repairs.json"); k.record("x","c","f",True,"ok"); assert k.proven("x")
