def test_window_capture_importable():
    from app.capture.windows import list_visible_windows, grab_window
    assert callable(list_visible_windows)
    assert callable(grab_window)
