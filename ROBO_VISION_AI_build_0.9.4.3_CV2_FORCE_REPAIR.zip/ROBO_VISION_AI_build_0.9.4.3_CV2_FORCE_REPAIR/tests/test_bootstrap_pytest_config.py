from pathlib import Path

def test_candidate_declares_local_pytest_basetemp():
    root = Path(__file__).resolve().parents[1]
    text = (root / 'pyproject.toml').read_text(encoding='utf-8')
    assert '--basetemp=.robo_pytest_tmp' in text
