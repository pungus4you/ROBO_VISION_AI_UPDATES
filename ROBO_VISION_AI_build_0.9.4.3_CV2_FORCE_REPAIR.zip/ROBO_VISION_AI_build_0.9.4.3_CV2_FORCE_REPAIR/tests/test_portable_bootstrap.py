from pathlib import Path
from app.install.portable import install_strategy, TRUSTED_MANIFEST_URL, protected_data_names

def test_permanent_feed_is_https():
    assert TRUSTED_MANIFEST_URL.startswith("https://raw.githubusercontent.com/")

def test_online_fallback_strategy(tmp_path):
    steps=install_strategy(True,tmp_path,True,False)
    assert steps[0]=="install_python_winget"
    assert "install_dependencies_online_fallback" in steps

def test_offline_cache_strategy(tmp_path):
    (tmp_path/"x.whl").write_bytes(b"x")
    (tmp_path/"python-3.11-amd64.exe").write_bytes(b"x")
    steps=install_strategy(False,tmp_path,False,False)
    assert "install_python_cached_official" in steps
    assert "install_dependencies_offline_cache" in steps
    assert "install_dependencies_online_fallback" not in steps

def test_protected_data_names():
    assert {"projects","models","config","knowledge"}.issubset(set(protected_data_names()))
