from app.improvement.experiments import ExperimentDB
def test_experiments(tmp_path):
    d=ExperimentDB(tmp_path/"x.db"); d.add("e","r",{"a":1},{"a":2},True); assert len(d.list())==1
