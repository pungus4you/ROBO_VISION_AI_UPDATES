from app.vision.review import _iou

def test_iou_identical_box():
    assert _iou((0.1,0.1,0.5,0.5),(0.1,0.1,0.5,0.5)) == 1.0

def test_iou_disjoint_box():
    assert _iou((0.0,0.0,0.1,0.1),(0.9,0.9,1.0,1.0)) == 0.0
