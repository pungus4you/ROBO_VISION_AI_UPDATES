from app.knowledge.store import KnowledgeStore


def test_local_knowledge_search(tmp_path):
    store = KnowledgeStore(tmp_path)
    store.add_document(source_id='one', title='Fresh Guide', url='https://example.test', text='YOLO small target training can use higher resolution. Ollama runs local models.', fetched_at='2026-09-20T00:00:00+0000', sha256='x'*64)
    hits = store.search('small target resolution')
    assert hits
    assert hits[0]['title'] == 'Fresh Guide'
    assert 'higher resolution' in hits[0]['snippet']
