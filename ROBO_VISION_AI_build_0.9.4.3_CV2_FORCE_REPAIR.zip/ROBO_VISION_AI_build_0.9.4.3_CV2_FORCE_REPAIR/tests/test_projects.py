from app.projects.manager import ProjectManager
def test_create_project(tmp_path):
    m=ProjectManager(tmp_path); p=m.create("Demo Project"); assert (p/"project.json").exists(); assert p in m.list()
