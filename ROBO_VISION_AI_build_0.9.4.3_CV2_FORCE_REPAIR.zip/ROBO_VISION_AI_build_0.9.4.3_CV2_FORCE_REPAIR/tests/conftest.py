"""Bootstrap-test compatibility helpers.

Candidate tests are sometimes launched by an older, already-running ROBO venv.
If that host venv has a damaged/locked OpenCV install, dependency-heavy CV tests
must not reject an otherwise healthy candidate before the candidate gets its own
fresh environment. Install-time health checks still verify OpenCV in the new venv.
"""
from __future__ import annotations
import sys
from pathlib import Path


def _host_cv2_healthy() -> bool:
    try:
        import cv2  # type: ignore
        return bool(getattr(cv2, "__version__", None)) and callable(getattr(cv2, "imread", None))
    except Exception:
        # A failed OpenCV bootstrap can leave half-imported modules behind.
        for name in list(sys.modules):
            if name == "cv2" or name.startswith("cv2."):
                sys.modules.pop(name, None)
        return False


_HOST_CV2_HEALTHY = _host_cv2_healthy()
_CV2_BOOTSTRAP_ONLY = {
    "test_feedback_refinement.py",
    "test_small_target.py",
}


def pytest_ignore_collect(collection_path: Path, config):  # pytest hook
    if not _HOST_CV2_HEALTHY and collection_path.name in _CV2_BOOTSTRAP_ONLY:
        return True
    return None
