from pathlib import Path


def test_self_repair_explicitly_uninstalls_and_reinstalls_opencv():
    text = (Path(__file__).parents[1] / "SELF_REPAIR.ps1").read_text(encoding="utf-8")
    assert "pip uninstall -y opencv-python" in text
    assert "--no-cache-dir --force-reinstall" in text
    assert "Remove-Item -Recurse -Force $Cv2Dir" in text
    assert "import cv2; print('CV2 OK'" in text


def test_installer_core_repair_explicitly_repairs_opencv():
    text = (Path(__file__).parents[1] / "INSTALL.ps1").read_text(encoding="utf-8")
    assert "Repairing OpenCV cleanly" in text
    assert "pip uninstall -y opencv-python" in text
    assert '"opencv-python>=4.9"' in text
