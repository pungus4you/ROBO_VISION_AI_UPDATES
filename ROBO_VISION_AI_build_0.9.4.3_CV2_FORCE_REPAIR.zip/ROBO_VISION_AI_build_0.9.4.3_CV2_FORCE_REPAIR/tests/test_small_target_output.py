import json
from pathlib import Path
from app.output.generator import generate_output_bundle

def test_output_bundle_enables_far_target_mode(tmp_path:Path):
    project=tmp_path/'EnemyProject'; project.mkdir()
    model=tmp_path/'best.pt'; model.write_bytes(b'model')
    out=generate_output_bundle(project,model,far_target_mode=True,class_name='enemy')
    cfg=json.loads((Path(out['output_dir'])/'config.json').read_text())
    assert cfg['far_target_mode'] is True
    assert cfg['imgsz']==960
    assert cfg['class_name']=='enemy'
