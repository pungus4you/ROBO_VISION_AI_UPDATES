import json
from pathlib import Path
from app.output.generator import generate_output_bundle


def test_generated_detector_has_separate_visual_assist_controls(tmp_path:Path):
    project=tmp_path/"AimView"; project.mkdir()
    model=tmp_path/"best.pt"; model.write_bytes(b"model")
    out=generate_output_bundle(project,model,far_target_mode=True,class_name="enemy")
    output=Path(out["output_dir"])
    script=(output/"AimView_detector.py").read_text(encoding="utf-8")
    cfg=json.loads((output/"config.json").read_text(encoding="utf-8"))
    assert "ROBO Assist Controls" in script
    assert "Mode 0=MAN 1=AUTO" in script
    assert "Strength" in script
    assert "Assist Box %" in script
    assert "Manual Conf %" in script
    assert "Marker Boost" in script
    assert "Center Bias" in script
    assert "does not move the mouse or fire" in script
    assert cfg["visual_assist"]["separate_controls_window"] is True
    assert cfg["visual_assist"]["input_control"] is False


def test_assist_settings_are_saved_locally(tmp_path:Path):
    project=tmp_path/"AimView"; project.mkdir()
    model=tmp_path/"best.pt"; model.write_bytes(b"model")
    out=generate_output_bundle(project,model)
    script=(Path(out["output_dir"])/"AimView_detector.py").read_text(encoding="utf-8")
    assert "assist_settings.json" in script
    assert "_save_assist" in script
    assert "_load_assist" in script
