from pathlib import Path
from app.output.generator import generate_output_bundle

def test_bundle_screen_default(tmp_path):
    project=tmp_path/"PERSON"; project.mkdir()
    model=tmp_path/"best.pt"; model.write_bytes(b"fake")
    b=generate_output_bundle(project,model,.4)
    script=Path(b["script"]).read_text(encoding="utf-8")
    assert "mss" in script
    assert "VideoCapture(0)" not in script
    assert Path(b["run_bat"]).exists()
    assert Path(b["runner_ps1"]).exists()
