from pathlib import Path
from app.projects.manager import ProjectManager
from app.dataset.manager import DatasetManager
from app.training.pipeline import VisionPipeline

def test_pipeline_split(tmp_path):
    p=ProjectManager(tmp_path).create("P")
    ds=DatasetManager(p).create("D")
    raw=ds/"images"/"raw"; labels=ds/"labels"/"raw"
    for i in range(4):
        (raw/f"x{i}.jpg").write_bytes(b"not-a-real-jpg-but-split-does-not-decode")
        (labels/f"x{i}.txt").write_text("0 0.5 0.5 0.2 0.2")
    r=VisionPipeline(p,ds).split()
    assert r["train"]>=1
    assert (ds/"data.yaml").exists()
    assert len(list((ds/"labels"/"train").glob("*.txt")))==r["train"]
