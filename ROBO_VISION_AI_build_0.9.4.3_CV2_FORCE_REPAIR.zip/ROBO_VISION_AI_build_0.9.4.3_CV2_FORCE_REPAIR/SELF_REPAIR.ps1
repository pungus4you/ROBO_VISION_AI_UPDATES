$ErrorActionPreference="Continue"
$Root=$PSScriptRoot
$Py=Join-Path $Root ".venv\Scripts\python.exe"
$Cache=Join-Path $Root "offline_cache"
Write-Host "ROBO SELF-REPAIR 0.9.4.3" -ForegroundColor Cyan

if(-not (Test-Path $Py)){
    Write-Host "Environment missing. Running portable setup..."
    & (Join-Path $Root "ROBO_PORTABLE_SETUP.ps1")
    exit $LASTEXITCODE
}

function Test-PythonImport([string]$Code){
    & $Py -c $Code 2>$null
    return ($LASTEXITCODE -eq 0)
}

function Repair-OpenCV {
    Write-Host "ROBO detected a broken OpenCV/cv2 installation." -ForegroundColor Yellow
    Write-Host "Removing the damaged OpenCV package from this ROBO environment only..." -ForegroundColor Yellow
    & $Py -m pip uninstall -y opencv-python opencv-python-headless opencv-contrib-python opencv-contrib-python-headless 2>$null | Out-Host

    $Site = & $Py -c "import site; print(site.getsitepackages()[0])"
    if($LASTEXITCODE -eq 0 -and $Site){
        $Cv2Dir=Join-Path $Site.Trim() "cv2"
        if(Test-Path $Cv2Dir){
            try {
                Remove-Item -Recurse -Force $Cv2Dir -ErrorAction Stop
                Write-Host "Removed stale cv2 folder: $Cv2Dir"
            } catch {
                Write-Host "Windows is still using cv2 files. Close any ROBO/Python window and run SELF_REPAIR.bat again." -ForegroundColor Red
                return $false
            }
        }
    }

    $ok=$false
    if((Test-Path $Cache) -and (Get-ChildItem $Cache -Filter 'opencv_python*.whl' -ErrorAction SilentlyContinue)){
        Write-Host "Trying OpenCV repair from offline cache..."
        & $Py -m pip install --force-reinstall --no-index --find-links $Cache opencv-python
        if($LASTEXITCODE -eq 0){$ok=$true}
    }
    if(-not $ok){
        Write-Host "Trying clean online OpenCV reinstall..."
        & $Py -m pip install --no-cache-dir --force-reinstall "opencv-python>=4.9"
        if($LASTEXITCODE -eq 0){$ok=$true}
    }
    if(-not $ok){ return $false }
    return (Test-PythonImport "import cv2; print('CV2 OK', cv2.__version__)")
}

$cv2Healthy = Test-PythonImport "import cv2; print(cv2.__version__)"
if(-not $cv2Healthy){
    if(-not (Repair-OpenCV)){
        Write-Host "ROBO could not repair OpenCV automatically." -ForegroundColor Red
        Write-Host "Close all ROBO/Python windows, then run SELF_REPAIR.bat once more." -ForegroundColor Yellow
        exit 1
    }
}

$checks=@("import torch","import ultralytics","import cv2","import PySide6","import mss")
$failed=@()
foreach($c in $checks){
    & $Py -c $c 2>$null
    if($LASTEXITCODE -ne 0){$failed += $c}
}
if($failed.Count -eq 0){
    Write-Host "Core components healthy." -ForegroundColor Green
    exit 0
}

Write-Host "Broken/missing components remain. Reinstalling application requirements once..." -ForegroundColor Yellow
if((Test-Path $Cache) -and (Get-ChildItem $Cache -Filter *.whl -ErrorAction SilentlyContinue)){
    & $Py -m pip install --force-reinstall --no-index --find-links $Cache -r (Join-Path $Root "requirements.txt")
} else {
    & $Py -m pip install --upgrade --force-reinstall -r (Join-Path $Root "requirements.txt")
}
if($LASTEXITCODE -ne 0){
    Write-Host "Repair could not finish automatically. Run ROBO_PORTABLE_SETUP.bat; Windows may need normal UAC/administrator approval." -ForegroundColor Red
    exit 1
}

if(-not (Test-PythonImport "import cv2, ultralytics, torch, PySide6, mss; print('ROBO CORE OK')")){
    Write-Host "ROBO repair finished package installation but verification still failed." -ForegroundColor Red
    exit 1
}
Write-Host "Repair completed. Re-run ROBO." -ForegroundColor Green
