$ErrorActionPreference="Continue"
$Root="C:\ROBO_VISION_AI"; $Py="$Root\.venv\Scripts\python.exe"
Write-Host "=== ROBO Vision AI Repair ===" -ForegroundColor Cyan
if(!(Test-Path $Py)){ Write-Host "Main venv missing. Re-running installer."; & "$Root\INSTALL.ps1"; exit $LASTEXITCODE }
& $Py -m pip check
if($LASTEXITCODE -ne 0){ & $Py -m pip install -r "$Root\requirements.txt" --upgrade }
& "$Root\DIAGNOSTICS.ps1"
