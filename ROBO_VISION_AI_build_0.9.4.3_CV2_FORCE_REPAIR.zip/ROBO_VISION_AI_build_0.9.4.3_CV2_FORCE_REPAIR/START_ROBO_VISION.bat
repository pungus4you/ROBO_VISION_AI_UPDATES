@echo off
setlocal
title ROBO Vision AI 0.9.3.4
cd /d "%~dp0"
set "ROBO_ROOT=%~dp0"
set "ROBO_PY=%~dp0.venv\Scripts\python.exe"
set "VIRTUAL_ENV=%~dp0.venv"
set "PATH=%~dp0.venv\Scripts;%PATH%"

if not exist "%ROBO_PY%" (
  echo ROBO Vision AI is not installed yet.
  echo Running installer first...
  call "%~dp0INSTALL.bat"
  if errorlevel 1 exit /b 1
)

echo [ROBO preflight] Python: %ROBO_PY%
"%ROBO_PY%" -c "import sys; print('[ROBO preflight] Executable:', sys.executable)"

"%ROBO_PY%" -c "import torch, ultralytics; print('[ROBO preflight] TORCH', torch.__version__); print('[ROBO preflight] CUDA', torch.cuda.is_available()); print('[ROBO preflight] ULTRALYTICS', ultralytics.__version__)"
if errorlevel 1 (
  echo.
  echo [ROBO self-repair] Torch/Ultralytics import failed in the active ROBO environment.
  echo [ROBO self-repair] Repairing CUDA PyTorch and computer-vision packages...
  where nvidia-smi >nul 2>&1
  if not errorlevel 1 (
    "%ROBO_PY%" -m pip install --upgrade torch torchvision --index-url https://download.pytorch.org/whl/cu126
  ) else (
    "%ROBO_PY%" -m pip install --upgrade torch torchvision
  )
  if errorlevel 1 goto :repair_failed
  "%ROBO_PY%" -m pip install --upgrade "ultralytics>=8.4.155"
  if errorlevel 1 goto :repair_failed
  "%ROBO_PY%" -c "import torch, ultralytics; print('[ROBO self-repair] TORCH', torch.__version__); print('[ROBO self-repair] CUDA', torch.cuda.is_available()); print('[ROBO self-repair] Environment repaired successfully')"
  if errorlevel 1 goto :repair_failed
)

"%ROBO_PY%" -m app.main
if errorlevel 1 (
  echo.
  echo Application stopped with an error.
  pause
)
exit /b %ERRORLEVEL%

:repair_failed
echo.
echo ROBO self-repair could not restore the Python environment.
echo Run INSTALL.bat again and keep this window open if it reports an error.
pause
exit /b 1
