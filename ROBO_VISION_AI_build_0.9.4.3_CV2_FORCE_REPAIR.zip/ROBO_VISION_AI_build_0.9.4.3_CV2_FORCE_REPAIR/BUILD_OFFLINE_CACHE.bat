@echo off
cd /d "%~dp0"
powershell.exe -NoProfile -File "%~dp0BUILD_OFFLINE_CACHE.ps1"
pause
