$Root="C:\ROBO_VISION_AI"
Write-Host "ROBO Vision AI Recovery" -ForegroundColor Cyan
Write-Host "1. Diagnostics`n2. Repair`n3. Reinstall core environment`n4. Exit"
$c=Read-Host "Choose"
switch($c){
 "1" { & "$Root\DIAGNOSTICS.ps1" }
 "2" { & "$Root\REPAIR.ps1" }
 "3" { if(Test-Path "$Root\.venv"){Rename-Item "$Root\.venv" ".venv_broken_$(Get-Date -Format yyyyMMddHHmmss)"}; & "$Root\INSTALL.ps1" }
 default { exit }
}
