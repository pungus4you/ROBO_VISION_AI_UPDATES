@echo off
title ROBO Vision AI Installer
cd /d "%~dp0"
echo ==========================================
echo        ROBO VISION AI INSTALLER
echo ==========================================
echo.
powershell.exe -NoLogo -NoProfile -File "%~dp0INSTALL.ps1"
set "ERR=%ERRORLEVEL%"
echo.
if not "%ERR%"=="0" (
  echo INSTALLER STOPPED WITH ERROR CODE %ERR%.
  echo Keep this window open and send the error text to ChatGPT.
) else (
  echo Installer finished successfully.
)
echo.
pause
exit /b %ERR%
