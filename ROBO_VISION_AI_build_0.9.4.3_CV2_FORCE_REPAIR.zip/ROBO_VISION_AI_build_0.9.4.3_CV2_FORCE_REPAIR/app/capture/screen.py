from __future__ import annotations
class ScreenCapture:
    def __init__(self): self.sct=None
    def available(self):
        try: import mss; return True
        except Exception: return False
    def grab(self,monitor=1):
        import mss, numpy as np
        if self.sct is None: self.sct=mss.mss()
        raw=self.sct.grab(self.sct.monitors[monitor])
        return np.array(raw)[:,:,:3]
