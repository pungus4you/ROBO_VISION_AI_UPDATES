from __future__ import annotations

def list_visible_windows():
    try:
        import win32gui, win32process
    except Exception:
        return []
    out=[]
    def cb(hwnd,_):
        try:
            if not win32gui.IsWindowVisible(hwnd): return
            title=win32gui.GetWindowText(hwnd).strip()
            if not title: return
            left, top, right, bottom = win32gui.GetWindowRect(hwnd)
            if right-left < 80 or bottom-top < 80: return
            _,pid=win32process.GetWindowThreadProcessId(hwnd)
            out.append({"title":title,"hwnd":int(hwnd),"pid":int(pid),"rect":[left,top,right,bottom]})
        except Exception:
            pass
    win32gui.EnumWindows(cb,None)
    return sorted(out,key=lambda x:x["title"].lower())

def grab_window(hwnd: int):
    import win32gui, mss, numpy as np
    left, top, right, bottom = win32gui.GetWindowRect(int(hwnd))
    region={"left":left,"top":top,"width":max(1,right-left),"height":max(1,bottom-top)}
    with mss.mss() as sct:
        raw=np.array(sct.grab(region))
    return raw[:,:,:3]
