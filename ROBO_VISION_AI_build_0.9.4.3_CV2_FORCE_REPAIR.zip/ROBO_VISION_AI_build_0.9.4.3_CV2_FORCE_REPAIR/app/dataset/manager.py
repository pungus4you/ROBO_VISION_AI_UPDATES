from pathlib import Path
import json, shutil, hashlib

IMAGE_EXT={".jpg",".jpeg",".png",".bmp",".webp"}
class DatasetManager:
    def __init__(self, project:Path): self.project=project; self.root=project/"datasets"
    def create(self,name:str)->Path:
        p=self.root/name
        if p.exists(): raise FileExistsError(name)
        for s in ["images/raw","images/train","images/val","images/test","labels/raw","labels/train","labels/val","labels/test"]: (p/s).mkdir(parents=True,exist_ok=True)
        (p/"dataset.json").write_text(json.dumps({"name":name,"classes":[]},indent=2))
        return p
    def import_images(self,dataset:Path, sources:list[Path])->int:
        dest=dataset/"images/raw"; n=0
        for src in sources:
            seq=src.rglob("*") if src.is_dir() else [src]
            for f in seq:
                if f.is_file() and f.suffix.lower() in IMAGE_EXT:
                    target=dest/f.name; i=1
                    while target.exists(): target=dest/f"{f.stem}_{i}{f.suffix}"; i+=1
                    shutil.copy2(f,target); n+=1
        return n
    def stats(self,dataset:Path)->dict:
        raw=[p for p in (dataset/"images"/"raw").glob("*") if p.is_file() and p.suffix.lower() in IMAGE_EXT]
        raw_labels=list((dataset/"labels"/"raw").glob("*.txt"))
        positive=0
        for p in raw_labels:
            try:
                if p.read_text(encoding="utf-8").strip(): positive+=1
            except Exception: pass
        split_copies=sum(1 for split in ("train","val","test") for p in (dataset/"images"/split).glob("*") if p.is_file() and p.suffix.lower() in IMAGE_EXT)
        review=0; confirmed_negative=0
        try:
            q=json.loads((dataset/"review_queue.json").read_text(encoding="utf-8")); review=len(q.get("items",[]))
        except Exception: pass
        try:
            vr=json.loads((dataset/"vlm_review.json").read_text(encoding="utf-8")); confirmed_negative=int(vr.get("summary",{}).get("confirmed_negative",0))
        except Exception: pass
        return {"images":len(raw),"labels":len(raw_labels),"positive_labeled":positive,"confirmed_negative":confirmed_negative,"needs_review":review,"split_copies":split_copies,"unannotated":max(0,len(raw)-len(raw_labels))}
