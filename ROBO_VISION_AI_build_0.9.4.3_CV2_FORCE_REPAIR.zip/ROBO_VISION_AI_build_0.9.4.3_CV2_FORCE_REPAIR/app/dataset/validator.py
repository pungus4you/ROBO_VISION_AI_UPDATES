from __future__ import annotations
from pathlib import Path
from PIL import Image

def validate_yolo_dataset(dataset:Path)->dict:
    issues=[]; images=0; corrupt=0; labels=0; bad_labels=0
    for p in (dataset/"images").rglob("*"):
        if p.suffix.lower() in {".jpg",".jpeg",".png",".bmp",".webp"}:
            images+=1
            try:
                with Image.open(p) as im: im.verify()
            except Exception as e:
                corrupt+=1; issues.append({"type":"corrupt_image","file":str(p),"error":str(e)})
    for p in (dataset/"labels").rglob("*.txt"):
        labels+=1
        for i,line in enumerate(p.read_text(errors="ignore").splitlines(),1):
            parts=line.split()
            ok=len(parts)==5
            if ok:
                try:
                    cls=int(parts[0]); vals=list(map(float,parts[1:])); ok=cls>=0 and all(0<=v<=1 for v in vals)
                except Exception: ok=False
            if not ok:
                bad_labels+=1; issues.append({"type":"invalid_label","file":str(p),"line":i,"content":line})
    yaml_ok=(dataset/"data.yaml").exists()
    if not yaml_ok: issues.append({"type":"missing_data_yaml","file":str(dataset/"data.yaml")})
    return {"ok":not issues,"images":images,"labels":labels,"corrupt_images":corrupt,"bad_labels":bad_labels,"yaml":yaml_ok,"issues":issues}
