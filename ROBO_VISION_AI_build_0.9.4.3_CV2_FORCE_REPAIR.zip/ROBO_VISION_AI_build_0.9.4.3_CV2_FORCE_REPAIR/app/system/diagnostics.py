from __future__ import annotations
import importlib.util, sys, shutil
from .hardware import detect_hardware

def run_diagnostics()->list[dict]:
    out=[]
    def add(name,ok,detail=""): out.append({"name":name,"ok":bool(ok),"detail":str(detail)})
    add("Python 3.11+",sys.version_info>=(3,11),sys.version.split()[0])
    for mod in ["psutil","PIL","numpy","cv2","mss","PySide6","ultralytics"]:
        add(mod,importlib.util.find_spec(mod) is not None,"installed" if importlib.util.find_spec(mod) else "missing")
    h=detect_hardware(); add("Hardware detection",True,h.to_dict())
    add("Ollama executable",shutil.which("ollama") is not None,shutil.which("ollama") or "not found")
    return out
