from __future__ import annotations
import subprocess, shutil
import psutil

def live_snapshot() -> dict:
    out = {
        "cpu_percent": round(psutil.cpu_percent(interval=None), 1),
        "ram_percent": round(psutil.virtual_memory().percent, 1),
        "gpu_util_percent": None,
        "vram_used_mb": None,
        "vram_total_mb": None,
        "gpu_temp_c": None,
    }
    exe = shutil.which("nvidia-smi")
    if not exe:
        return out
    try:
        p = subprocess.run(
            [exe, "--query-gpu=utilization.gpu,memory.used,memory.total,temperature.gpu", "--format=csv,noheader,nounits"],
            capture_output=True, text=True, timeout=3
        )
        if p.returncode == 0 and p.stdout.strip():
            vals = [x.strip() for x in p.stdout.strip().splitlines()[0].split(",")]
            if len(vals) >= 4:
                out.update({
                    "gpu_util_percent": float(vals[0]),
                    "vram_used_mb": int(float(vals[1])),
                    "vram_total_mb": int(float(vals[2])),
                    "gpu_temp_c": float(vals[3]),
                })
    except Exception:
        pass
    return out
