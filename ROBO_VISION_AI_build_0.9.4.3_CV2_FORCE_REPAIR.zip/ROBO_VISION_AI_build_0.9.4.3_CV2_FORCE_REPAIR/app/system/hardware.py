from __future__ import annotations
import platform, shutil, subprocess
from dataclasses import dataclass, asdict
import psutil

@dataclass
class HardwareProfile:
    os: str
    architecture: str
    cpu: str
    ram_gb: float
    disk_free_gb: float
    gpu: str = "Unknown"
    vram_mb: int|None = None
    cuda_available: bool = False
    accelerator: str = "CPU"
    profile: str = "CPU_STANDARD"
    def to_dict(self): return asdict(self)

def _nvidia():
    exe=shutil.which("nvidia-smi")
    if not exe: return None
    try:
        p=subprocess.run([exe,"--query-gpu=name,memory.total","--format=csv,noheader,nounits"],capture_output=True,text=True,timeout=5)
        if p.returncode==0 and p.stdout.strip():
            name,mem=[x.strip() for x in p.stdout.strip().splitlines()[0].split(",",1)]
            return name,int(float(mem))
    except Exception: pass
    return None

def detect_hardware(path: str|None=None) -> HardwareProfile:
    disk=psutil.disk_usage(path or ".")
    h=HardwareProfile(platform.platform(),platform.machine(),platform.processor() or "Unknown",round(psutil.virtual_memory().total/2**30,1),round(disk.free/2**30,1))
    nv=_nvidia()
    if nv:
        h.gpu,h.vram_mb=nv; h.accelerator="NVIDIA"; h.cuda_available=True
        if h.vram_mb>=10000: h.profile="NVIDIA_CUDA_HIGH"
        elif h.vram_mb>=6000: h.profile="NVIDIA_CUDA_MEDIUM"
        else: h.profile="NVIDIA_LOW_VRAM"
    elif h.ram_gb<8: h.profile="CPU_LOW_MEMORY"
    return h

def training_preset(h: HardwareProfile) -> dict:
    # YOLO26 is the preferred family in 0.3+. Keep conservative defaults for 10 GB cards.
    if h.profile=="NVIDIA_CUDA_HIGH": return {"model":"yolo26s.pt","imgsz":640,"batch":8,"workers":4,"device":0,"amp":True,"epochs":30,"heavy_model":"yolo26m.pt","small_target_imgsz":960,"small_target_batch":4}
    if h.profile=="NVIDIA_CUDA_MEDIUM": return {"model":"yolo26s.pt","imgsz":640,"batch":4,"workers":2,"device":0,"amp":True,"epochs":30,"heavy_model":"yolo26m.pt","small_target_imgsz":832,"small_target_batch":2}
    if h.profile=="NVIDIA_LOW_VRAM": return {"model":"yolo26n.pt","imgsz":512,"batch":2,"workers":2,"device":0,"amp":True,"epochs":25,"heavy_model":"yolo26s.pt","small_target_imgsz":768,"small_target_batch":2}
    return {"model":"yolo26n.pt","imgsz":512,"batch":2,"workers":1,"device":"cpu","amp":False,"epochs":20,"heavy_model":"yolo26s.pt","small_target_imgsz":640,"small_target_batch":1}
