from __future__ import annotations
from pathlib import Path
import sys

def environment_report(root: Path | None = None) -> dict:
    exe = Path(sys.executable).resolve()
    root = Path(root).resolve() if root else None
    expected = (root / '.venv' / 'Scripts' / 'python.exe').resolve() if root else None
    report = {
        'python_executable': str(exe),
        'expected_python': str(expected) if expected else None,
        'using_project_venv': bool(expected and exe == expected),
        'torch_ok': False,
        'torch_version': None,
        'cuda': False,
    }
    try:
        import torch
        report['torch_ok'] = True
        report['torch_version'] = torch.__version__
        report['cuda'] = bool(torch.cuda.is_available())
    except Exception as e:
        report['torch_error'] = f'{type(e).__name__}: {e}'
    return report
