from __future__ import annotations
from pathlib import Path
import json, re, tempfile
from app.ai.ollama import OllamaClient

IMAGE_EXT={".jpg",".jpeg",".png",".bmp",".webp"}

def parse_yes_no_json(text:str)->dict:
    """Parse a deliberately tiny JSON contract from a local VLM response."""
    raw=(text or "").strip()
    m=re.search(r"\{.*?\}",raw,re.S)
    data={}
    if m:
        try:data=json.loads(m.group(0))
        except Exception:data={}
    answer=str(data.get("answer",data.get("present",""))).strip().lower()
    if answer in {"true","1"}:answer="yes"
    if answer in {"false","0"}:answer="no"
    if answer not in {"yes","no"}:
        low=raw.lower()
        answer="yes" if re.search(r"\byes\b",low) else ("no" if re.search(r"\bno\b",low) else "unknown")
    try:conf=float(data.get("confidence",0.0))
    except Exception:conf=0.0
    if conf>1:conf/=100.0
    return {"answer":answer,"confidence":max(0.0,min(1.0,conf)),"raw":raw[:1000]}

def _xywhn_to_xyxy(box,w,h,pad=.08):
    xc,yc,bw,bh=box
    x1=(xc-bw/2)*w; y1=(yc-bh/2)*h; x2=(xc+bw/2)*w; y2=(yc+bh/2)*h
    px=(x2-x1)*pad; py=(y2-y1)*pad
    return (max(0,int(x1-px)),max(0,int(y1-py)),min(w,int(x2+px)),min(h,int(y2+py)))

def _write_boxes(label_path:Path, boxes:list[list[float]]):
    lines=[f"0 {b[0]:.6f} {b[1]:.6f} {b[2]:.6f} {b[3]:.6f}" for b in boxes]
    label_path.write_text("\n".join(lines),encoding="utf-8")

def _low_conf_candidates(img:Path,model,device,conf=.05,imgsz=1280):
    r=model.predict(str(img),conf=conf,device=device,imgsz=imgsz,verbose=False)[0]
    h,w=r.orig_shape; out=[]
    if r.boxes is not None:
        for b in r.boxes:
            if int(b.cls.item())!=0:continue
            x1,y1,x2,y2=[float(x) for x in b.xyxy[0].tolist()]
            out.append({"confidence":float(b.conf.item()),"xywhn":[((x1+x2)/2)/w,((y1+y2)/2)/h,(x2-x1)/w,(y2-y1)/h]})
    return out

def vlm_review_queue(dataset:Path, model_name:str="yolo26s.pt", device=0, target="person", vision_model:str|None=None,
                     accept_vlm_conf:float=.70, max_candidates:int=4, progress_cb=None):
    """Use a local Ollama vision model as a verifier for uncertain YOLO proposals.

    The VLM never invents coordinates. Coordinates always come from YOLO proposals;
    the VLM only accepts/rejects candidate crops. If no local vision model exists, the
    stage reports a clean skip and leaves the queue untouched.
    """
    import cv2
    dataset=Path(dataset); qpath=dataset/"review_queue.json"
    if not qpath.exists():
        return {"status":"skipped","reason":"review_queue.json not found","reviewed":0,"rescued_images":0,"rescued_boxes":0}
    queue=json.loads(qpath.read_text(encoding="utf-8"))
    items=list(queue.get("items",[]))
    client=OllamaClient()
    if not client.health():
        return {"status":"skipped","reason":"Ollama not running","reviewed":0,"rescued_images":0,"rescued_boxes":0,"still_needing_review":len(items)}
    vision_model=vision_model or client.best_vision_model()
    if not vision_model:
        return {"status":"skipped","reason":"No installed Ollama vision model detected","reviewed":0,"rescued_images":0,"rescued_boxes":0,"still_needing_review":len(items)}

    from ultralytics import YOLO
    yolo=YOLO(model_name)
    raw=dataset/"images"/"raw"; labels=dataset/"labels"/"raw"
    labels.mkdir(parents=True,exist_ok=True)
    remaining=[]; report=[]; rescued_images=0; rescued_boxes=0
    total=len(items)
    for idx,item in enumerate(items,1):
        img=raw/item.get("image","")
        if not img.exists():
            remaining.append(item); continue
        candidates=list(item.get("candidates") or [])
        # If the ordinary smart-review pass had no proposal, run a higher-resolution,
        # lower-threshold proposal pass. The VLM will still gate every proposal.
        if not candidates:
            try:candidates=_low_conf_candidates(img,yolo,device)[:max_candidates]
            except Exception:candidates=[]
        else:candidates=candidates[:max_candidates]

        frame=cv2.imread(str(img)); accepted=[]; checks=[]
        if frame is not None:
            h,w=frame.shape[:2]
            for ci,c in enumerate(candidates):
                box=c.get("xywhn")
                if not box or len(box)!=4:continue
                x1,y1,x2,y2=_xywhn_to_xyxy(box,w,h)
                if x2<=x1 or y2<=y1:continue
                crop=frame[y1:y2,x1:x2]
                if crop.size==0:continue
                with tempfile.NamedTemporaryFile(suffix=".jpg",delete=False) as tf:
                    crop_path=Path(tf.name)
                try:
                    cv2.imwrite(str(crop_path),crop)
                    prompt=(f"This is a candidate crop from a computer-vision dataset. Is the target '{target}' visibly present in this crop? "
                            "Reply ONLY as JSON: {\"answer\":\"yes\" or \"no\",\"confidence\":0.0 to 1.0}. "
                            "Judge only what is visibly present; do not guess identity.")
                    verdict=parse_yes_no_json(client.chat_with_images(vision_model,prompt,[crop_path],timeout=90))
                    checks.append({"candidate":ci,"yolo_confidence":round(float(c.get("confidence",0)),4),"verdict":verdict})
                    if verdict["answer"]=="yes" and verdict["confidence"]>=accept_vlm_conf:
                        accepted.append([float(v) for v in box])
                except Exception as e:
                    checks.append({"candidate":ci,"error":f"{type(e).__name__}: {e}"})
                finally:
                    try:crop_path.unlink(missing_ok=True)
                    except Exception:pass
        if accepted:
            _write_boxes(labels/f"{img.stem}.txt",accepted)
            rescued_images+=1; rescued_boxes+=len(accepted)
            status="rescued"
        else:
            # Whole-image VLM triage distinguishes likely negatives from unresolved positives.
            whole={"answer":"unknown","confidence":0.0}
            try:
                prompt=(f"Does this full image visibly contain at least one '{target}'? Reply ONLY as JSON: "
                        "{\"answer\":\"yes\" or \"no\",\"confidence\":0.0 to 1.0}.")
                whole=parse_yes_no_json(client.chat_with_images(vision_model,prompt,[img],timeout=90))
            except Exception as e:whole={"answer":"unknown","confidence":0.0,"error":str(e)}
            status="confirmed_negative" if whole.get("answer")=="no" and whole.get("confidence",0)>=.80 else "needs_review"
            if status!="confirmed_negative": remaining.append({**item,"vlm_status":status,"vlm_whole_image":whole})
        report.append({"image":img.name,"status":status,"candidate_checks":checks})
        if progress_cb:progress_cb(idx,max(1,total),f"Local vision review {idx}/{total}: {img.name}")

    result={"status":"complete","vision_model":vision_model,"reviewed":total,"rescued_images":rescued_images,
            "rescued_boxes":rescued_boxes,"still_needing_review":len(remaining),"confirmed_negative":sum(1 for x in report if x['status']=='confirmed_negative')}
    (dataset/"vlm_review.json").write_text(json.dumps({"summary":result,"items":report},indent=2),encoding="utf-8")
    queue["items"]=remaining
    queue["summary"]["still_needing_review"]=len(remaining)
    queue["summary"]["vlm_review"]=result
    qpath.write_text(json.dumps(queue,indent=2),encoding="utf-8")
    return result
