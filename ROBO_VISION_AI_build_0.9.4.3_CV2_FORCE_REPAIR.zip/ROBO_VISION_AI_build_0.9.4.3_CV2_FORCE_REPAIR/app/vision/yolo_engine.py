from __future__ import annotations
class YoloEngine:
    def __init__(self): self.model=None; self.model_path=None
    def available(self):
        try: import ultralytics; return True
        except Exception: return False
    def load(self,path:str):
        from ultralytics import YOLO
        self.model=YOLO(path); self.model_path=path; return True
    def predict(self,source,conf=.25,device=None):
        if self.model is None: raise RuntimeError("No model loaded")
        return self.model.predict(source=source,conf=conf,device=device,verbose=False)
