from __future__ import annotations
from pathlib import Path
import json

IMAGE_EXT={".jpg",".jpeg",".png",".bmp",".webp"}

def _iou(a,b):
    ax1,ay1,ax2,ay2=a; bx1,by1,bx2,by2=b
    ix1=max(ax1,bx1); iy1=max(ay1,by1); ix2=min(ax2,bx2); iy2=min(ay2,by2)
    iw=max(0.0,ix2-ix1); ih=max(0.0,iy2-iy1); inter=iw*ih
    aa=max(0.0,ax2-ax1)*max(0.0,ay2-ay1); ba=max(0.0,bx2-bx1)*max(0.0,by2-by1)
    den=aa+ba-inter
    return inter/den if den>0 else 0.0

def _read_yolo(path: Path):
    boxes=[]
    if not path.exists(): return boxes
    for line in path.read_text(encoding="utf-8").splitlines():
        p=line.strip().split()
        if len(p)<5: continue
        _,xc,yc,w,h=map(float,p[:5])
        boxes.append((xc-w/2,yc-h/2,xc+w/2,yc+h/2))
    return boxes

def build_annotation_review(dataset: Path, model_name: str="yolo26s.pt", device=0, low_conf: float=.12, accept_conf: float=.22, progress_cb=None):
    """Second-pass review of images with empty labels.

    High-confidence rescue detections are written to labels; uncertain detections are
    stored in review_queue.json instead of silently becoming training truth.
    """
    from ultralytics import YOLO
    dataset=Path(dataset); raw=dataset/"images"/"raw"; labels=dataset/"labels"/"raw"
    images=sorted([p for p in raw.iterdir() if p.is_file() and p.suffix.lower() in IMAGE_EXT])
    empties=[]
    for img in images:
        lab=labels/f"{img.stem}.txt"
        if (not lab.exists()) or (not lab.read_text(encoding="utf-8").strip()): empties.append(img)
    model=YOLO(model_name)
    queue=[]; rescued_images=0; rescued_boxes=0
    total=len(empties)
    for i,img in enumerate(empties,1):
        r=model.predict(str(img),conf=low_conf,device=device,verbose=False)[0]
        h,w=r.orig_shape; accepted=[]; uncertain=[]
        if r.boxes is not None:
            for b in r.boxes:
                if int(b.cls.item()) != 0: continue
                conf=float(b.conf.item())
                x1,y1,x2,y2=[float(x) for x in b.xyxy[0].tolist()]
                xc=((x1+x2)/2)/w; yc=((y1+y2)/2)/h; bw=(x2-x1)/w; bh=(y2-y1)/h
                item={"confidence":round(conf,4),"xywhn":[xc,yc,bw,bh]}
                if conf>=accept_conf: accepted.append(item)
                else: uncertain.append(item)
        if accepted:
            lines=[f"0 {x['xywhn'][0]:.6f} {x['xywhn'][1]:.6f} {x['xywhn'][2]:.6f} {x['xywhn'][3]:.6f}" for x in accepted]
            (labels/f"{img.stem}.txt").write_text("\n".join(lines),encoding="utf-8")
            rescued_images+=1; rescued_boxes+=len(accepted)
        if uncertain or not accepted:
            queue.append({"image":img.name,"status":"uncertain" if uncertain else "no_candidate","candidates":uncertain})
        if progress_cb: progress_cb(i,max(1,total),f"Reviewing empty labels {i}/{total}: {img.name}")
    result={"empty_images_checked":total,"rescued_images":rescued_images,"rescued_boxes":rescued_boxes,"still_needing_review":len(queue),"low_conf":low_conf,"accept_conf":accept_conf}
    (dataset/"review_queue.json").write_text(json.dumps({"summary":result,"items":queue},indent=2),encoding="utf-8")
    return result

def mine_hard_examples(project: Path, dataset: Path, model_path: Path, device=0, conf=.15, iou_threshold=.5, progress_cb=None, splits=("val","test"), output_name="hard_examples.json"):

    """Evaluate val/test against YOLO labels and write a hard-example queue."""
    from ultralytics import YOLO
    project=Path(project); dataset=Path(dataset); model=YOLO(str(model_path))
    items=[]; images=[]
    for split in splits:
        idir=dataset/"images"/split
        if idir.exists(): images += [(split,p) for p in idir.iterdir() if p.is_file() and p.suffix.lower() in IMAGE_EXT]
    total=len(images)
    for i,(split,img) in enumerate(images,1):
        gt=_read_yolo(dataset/"labels"/split/f"{img.stem}.txt")
        r=model.predict(str(img),conf=conf,device=device,verbose=False)[0]
        h,w=r.orig_shape; preds=[]
        if r.boxes is not None:
            for b in r.boxes:
                if int(b.cls.item()) != 0: continue
                x1,y1,x2,y2=[float(x) for x in b.xyxy[0].tolist()]
                preds.append(((x1/w,y1/h,x2/w,y2/h),float(b.conf.item())))
        matched_gt=set(); matched_pred=set()
        for pi,(pb,pc) in enumerate(preds):
            best=-1; best_iou=0
            for gi,gb in enumerate(gt):
                v=_iou(pb,gb)
                if v>best_iou: best_iou=v; best=gi
            if best>=0 and best_iou>=iou_threshold:
                matched_gt.add(best); matched_pred.add(pi)
        misses=len(gt)-len(matched_gt); fps=len(preds)-len(matched_pred)
        low=sum(1 for _,pc in preds if pc<.35)
        if misses or fps or low:
            items.append({"split":split,"image":img.name,"ground_truth":len(gt),"predictions":len(preds),"missed_targets":misses,"false_positives":fps,"low_confidence_predictions":low})
        if progress_cb: progress_cb(i,max(1,total),f"Mining hard examples {i}/{total}: {img.name}")
    out=project/"analysis"; out.mkdir(parents=True,exist_ok=True)
    payload={"images_checked":total,"hard_examples":len(items),"items":items}
    (out/output_name).write_text(json.dumps(payload,indent=2),encoding="utf-8")
    return payload
