from __future__ import annotations
from pathlib import Path
import json
import cv2
import numpy as np

IMAGE_EXT={".jpg",".jpeg",".png",".bmp",".webp"}

def detect_red_markers(frame, min_area=3, max_area=500):
    """Return compact saturated red/orange marker components in the gameplay area.

    0.8.2 tightens the old marker gate so large red HUD/text regions are less likely
    to become distant-enemy proposals.
    """
    hsv=cv2.cvtColor(frame,cv2.COLOR_BGR2HSV)
    m1=cv2.inRange(hsv,np.array([0,125,145],np.uint8),np.array([14,255,255],np.uint8))
    m2=cv2.inRange(hsv,np.array([168,125,145],np.uint8),np.array([179,255,255],np.uint8))
    mask=cv2.bitwise_or(m1,m2)
    mask=cv2.morphologyEx(mask,cv2.MORPH_OPEN,np.ones((2,2),np.uint8))
    n,_,stats,_=cv2.connectedComponentsWithStats(mask,8)
    out=[]; H,W=frame.shape[:2]
    for i in range(1,n):
        x,y,w,h,area=map(int,stats[i])
        cx=x+w/2; cy=y+h/2
        in_gameplay=(W*.20 <= cx <= W*.80 and H*.23 <= cy <= H*.78)
        compact=(w <= 32 and h <= 24 and max(w,h)/max(1,min(w,h)) <= 4.0)
        if min_area <= area <= max_area and compact and in_gameplay:
            out.append((x,y,x+w,y+h))
    return out

def marker_enemy_box(marker,w,h):
    x1,y1,x2,y2=marker; mw=max(2,x2-x1); mh=max(2,y2-y1); cx=(x1+x2)/2
    bw=max(18,mw*7.0); bh=max(28,mh*13.0)
    return (max(0,int(cx-bw/2)),max(0,int(y1-mh*1.5)),min(w,int(cx+bw/2)),min(h,int(y2+bh)))

def _xyxy_to_xywhn(box,w,h):
    x1,y1,x2,y2=box
    return [((x1+x2)/2)/w,((y1+y2)/2)/h,(x2-x1)/w,(y2-y1)/h]

def _xywhn_to_xyxy(box,w,h):
    xc,yc,bw,bh=box
    return ((xc-bw/2)*w,(yc-bh/2)*h,(xc+bw/2)*w,(yc+bh/2)*h)

def _iou(a,b):
    ax1,ay1,ax2,ay2=a; bx1,by1,bx2,by2=b
    ix1=max(ax1,bx1); iy1=max(ay1,by1); ix2=min(ax2,bx2); iy2=min(ay2,by2)
    inter=max(0,ix2-ix1)*max(0,iy2-iy1)
    den=max(0,ax2-ax1)*max(0,ay2-ay1)+max(0,bx2-bx1)*max(0,by2-by1)-inter
    return inter/den if den else 0.0

def _read_existing_label(path:Path):
    boxes=[]
    if not path.exists(): return boxes
    for line in path.read_text(encoding='utf-8').splitlines():
        p=line.strip().split()
        if len(p)>=5:
            try: boxes.append([float(p[1]),float(p[2]),float(p[3]),float(p[4])])
            except ValueError: pass
    return boxes

def _merge_boxes(existing,new_boxes,w,h,iou=.55):
    merged=list(existing)
    for box in new_boxes:
        px=_xywhn_to_xyxy(box,w,h)
        if all(_iou(px,_xywhn_to_xyxy(old,w,h)) < iou for old in merged):
            merged.append(box)
    return merged

def tile_person_candidates(frame,model,device=0,tile=640,overlap=.20,conf=.06):
    h,w=frame.shape[:2]; step=max(64,int(tile*(1-overlap))); preds=[]
    xs=list(range(0,max(1,w-tile+1),step)); ys=list(range(0,max(1,h-tile+1),step))
    if not xs or xs[-1] != max(0,w-tile): xs.append(max(0,w-tile))
    if not ys or ys[-1] != max(0,h-tile): ys.append(max(0,h-tile))
    for yy in sorted(set(ys)):
        for xx in sorted(set(xs)):
            crop=frame[yy:min(h,yy+tile),xx:min(w,xx+tile)]
            if crop.size==0: continue
            r=model.predict(crop,conf=conf,device=device,imgsz=tile,verbose=False)[0]
            if r.boxes is None: continue
            for b in r.boxes:
                if int(b.cls.item())!=0: continue
                x1,y1,x2,y2=[float(v) for v in b.xyxy[0].tolist()]
                preds.append({'confidence':float(b.conf.item()),'xyxy':(x1+xx,y1+yy,x2+xx,y2+yy)})
    keep=[]
    for p in sorted(preds,key=lambda z:z['confidence'],reverse=True):
        if all(_iou(p['xyxy'],q['xyxy'])<.55 for q in keep): keep.append(p)
    return keep

def small_target_review(dataset:Path,model_name='yolo26s.pt',device=0,progress_cb=None,accept_conf=.22):
    """Review unresolved images using tiled person proposals plus red-marker support.

    Existing labels are merged, never overwritten. Marker-only detections remain
    proposals for VLM/manual review and are not silently promoted.
    """
    from ultralytics import YOLO
    dataset=Path(dataset); raw=dataset/'images'/'raw'; labels=dataset/'labels'/'raw'; qpath=dataset/'review_queue.json'
    queue={'summary':{},'items':[]}
    if qpath.exists():
        try: queue=json.loads(qpath.read_text(encoding='utf-8'))
        except Exception: pass
    items=list(queue.get('items',[])); model=YOLO(model_name)
    remaining=[]; rescued_images=0; rescued_boxes=0; marker_only=0; total=len(items); merged_existing=0
    for i,item in enumerate(items,1):
        img=raw/item.get('image',''); frame=cv2.imread(str(img)) if img.exists() else None
        if frame is None:
            remaining.append(item); continue
        h,w=frame.shape[:2]; markers=detect_red_markers(frame); preds=tile_person_candidates(frame,model,device=device)
        accepted=[]; uncertain=[]
        for p in preds:
            x1,y1,x2,y2=p['xyxy']; c=p['confidence']; supported=False
            for m in markers:
                mx=(m[0]+m[2])/2; my=(m[1]+m[3])/2
                # Expected marker position: near the upper part of the person proposal.
                if x1-10 <= mx <= x2+10 and y1-22 <= my <= y1+(y2-y1)*.42:
                    supported=True; break
            box=_xyxy_to_xywhn((x1,y1,x2,y2),w,h)
            if c>=accept_conf or (c>=.08 and supported): accepted.append(box)
            else: uncertain.append({'confidence':round(c,4),'xywhn':box,'marker_supported':supported})
        for m in markers:
            prop=marker_enemy_box(m,w,h)
            if not any(_iou(prop,p['xyxy'])>.15 for p in preds):
                uncertain.append({'confidence':0.0,'xywhn':_xyxy_to_xywhn(prop,w,h),'marker_supported':True,'source':'red_marker'})
                marker_only+=1
        if accepted:
            lab=labels/f'{img.stem}.txt'; existing=_read_existing_label(lab)
            merged=_merge_boxes(existing,accepted,w,h)
            merged_existing += max(0,len(merged)-len(accepted))
            lab.write_text('\n'.join(f'0 {b[0]:.6f} {b[1]:.6f} {b[2]:.6f} {b[3]:.6f}' for b in merged),encoding='utf-8')
            rescued_images+=1; rescued_boxes+=max(0,len(merged)-len(existing))
        # Once a detector box is accepted, keep the image out of the blocking queue;
        # marker-only / low-confidence leftovers are recorded for audit but do not
        # force duplicate review of an already-rescued image.
        if uncertain and not accepted:
            remaining.append({'image':img.name,'status':'small_target_uncertain','candidates':uncertain[:8]})
        elif not accepted and not uncertain:
            remaining.append({'image':img.name,'status':'no_small_target_candidate','candidates':[]})
        if progress_cb: progress_cb(i,max(1,total),f'Small-target scan {i}/{total}: {img.name}')
    summary=dict(queue.get('summary') or {})
    result={'images_checked':total,'rescued_images':rescued_images,'rescued_boxes':rescued_boxes,'marker_only_proposals':marker_only,'still_needing_review':len(remaining),'tile_size':640,'accept_conf':accept_conf,'preserved_existing_labels':merged_existing}
    summary['small_target_review']=result; summary['still_needing_review']=len(remaining)
    qpath.write_text(json.dumps({'summary':summary,'items':remaining},indent=2),encoding='utf-8')
    (dataset/'small_target_review.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    return result
