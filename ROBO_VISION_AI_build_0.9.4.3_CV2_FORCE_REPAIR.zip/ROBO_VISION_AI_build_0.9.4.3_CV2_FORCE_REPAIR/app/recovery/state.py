from __future__ import annotations
from pathlib import Path
import json, shutil, time

class RecoveryManager:
    """Versioned state snapshots for settings/metadata. User projects/models are never erased here."""
    def __init__(self, root: Path):
        self.root=Path(root); self.backups=self.root/"backups"/"recovery"; self.backups.mkdir(parents=True,exist_ok=True)
        self.config=self.root/"config"; self.config.mkdir(parents=True,exist_ok=True)

    def snapshot(self, label="last_known_good") -> Path:
        stamp=time.strftime("%Y%m%d-%H%M%S")
        dst=self.backups/f"{label}-{stamp}"; dst.mkdir(parents=True,exist_ok=True)
        if self.config.exists(): shutil.copytree(self.config,dst/"config",dirs_exist_ok=True)
        manifest={"label":label,"created":stamp,"path":str(dst)}
        (dst/"snapshot.json").write_text(json.dumps(manifest,indent=2),encoding="utf-8")
        (self.backups/"LAST_KNOWN_GOOD.txt").write_text(str(dst),encoding="utf-8")
        return dst

    def restore_last_known_good(self) -> Path:
        marker=self.backups/"LAST_KNOWN_GOOD.txt"
        if not marker.exists(): raise RuntimeError("No Last Known Good snapshot exists yet.")
        src=Path(marker.read_text(encoding="utf-8").strip())
        if not src.exists(): raise RuntimeError("Last Known Good snapshot is missing.")
        snap_config=src/"config"
        if snap_config.exists():
            if self.config.exists(): shutil.rmtree(self.config)
            shutil.copytree(snap_config,self.config)
        return src

    def reset_settings(self):
        defaults={
            "autonomous_mode": True,
            "default_detector_model": "yolo26s.pt",
            "fallback_detector_model": "yolo26n.pt",
            "heavy_detector_model": "yolo26m.pt",
            "confidence": 0.25,
            "ask_only_when_blocked_or_permission_required": True
        }
        (self.config/"settings.json").write_text(json.dumps(defaults,indent=2),encoding="utf-8")
        return defaults
