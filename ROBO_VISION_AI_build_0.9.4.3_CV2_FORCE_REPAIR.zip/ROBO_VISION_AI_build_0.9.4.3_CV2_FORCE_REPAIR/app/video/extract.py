from __future__ import annotations
from pathlib import Path

def extract_frames(video: Path, output: Path, every_n_frames: int = 30, max_frames: int = 0) -> dict:
    import cv2
    video=Path(video); output=Path(output); output.mkdir(parents=True,exist_ok=True)
    cap=cv2.VideoCapture(str(video))
    if not cap.isOpened(): raise RuntimeError(f"Could not open video: {video}")
    total=0; saved=0
    while True:
        ok,frame=cap.read()
        if not ok: break
        if total % max(1,every_n_frames)==0:
            out=output/f"{video.stem}_{total:08d}.jpg"
            if cv2.imwrite(str(out),frame): saved+=1
            if max_frames and saved>=max_frames: break
        total+=1
    cap.release()
    return {"frames_read":total,"frames_saved":saved,"output":str(output)}
