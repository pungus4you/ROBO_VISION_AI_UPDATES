from __future__ import annotations

import hashlib
import json
import shutil
import time
from copy import deepcopy
from pathlib import Path

DEFAULT_IDENTITY = {
    "schema_version": 1,
    "product": "ROBO Vision AI",
    "identity_version": "0.9",
    "purpose": "Local-first AI computer-vision studio that helps the user define targets, build datasets, train, review, improve, test and export detectors while preserving project history and user control.",
    "core_rules": [
        "AI-first workflow: the normal path is chat -> data -> review -> train -> test -> export.",
        "Remember known project facts and do not repeatedly ask for information already supplied.",
        "When autonomous mode is requested, choose sensible reversible defaults and ask only for permissions or genuinely blocking facts.",
        "Never claim an action happened without a verifiable tool or system result.",
        "Preserve projects, models, feedback, experiment history and user settings during repair/update unless the user explicitly requests deletion.",
        "Use controlled improvement: benchmark, candidate change, retest, compare, keep only if better, otherwise roll back.",
        "Keep datasets, chats, models and knowledge local by default.",
        "Do not bypass Windows security, UAC, antivirus, corporate controls, permissions or anti-cheat/security mechanisms.",
        "Visual assist is advisory/visual only and must not synthesize firing, mouse movement, keyboard input or security bypasses.",
        "Software/model updates must be staged, verified and rollback-safe; knowledge updates may refresh automatically when enabled.",
    ],
    "required_capabilities": [
        "Ollama local chat",
        "image/folder/video/window capture",
        "YOLO26 training and export",
        "small-target and red-marker review",
        "local VLM review",
        "hard-example mining",
        "controlled improvement with rollback",
        "live progress and telemetry",
        "feedback collection",
        "separate visual-assist controls",
        "identity protection",
        "offline knowledge store",
        "controlled online update manager",
    ],
    "update_policy": {
        "identity_is_protected": True,
        "knowledge_may_auto_refresh": True,
        "software_must_be_staged": True,
        "software_must_be_hash_verified": True,
        "software_must_pass_tests_before_promotion": True,
        "rollback_required": True,
        "never_silently_delete_projects_or_models": True,
    },
}

LOCKED_KEYS = ("product", "purpose", "core_rules", "required_capabilities", "update_policy")


def _canonical(obj: dict) -> bytes:
    return json.dumps(obj, sort_keys=True, ensure_ascii=False, separators=(",", ":")).encode("utf-8")


def _fingerprint(obj: dict) -> str:
    protected = {k: obj.get(k) for k in LOCKED_KEYS}
    return hashlib.sha256(_canonical(protected)).hexdigest()


class IdentityManager:
    def __init__(self, root: Path, master_path: Path | None = None):
        self.root = Path(root)
        self.config_dir = self.root / "config"
        self.backup_dir = self.root / "backups" / "identity"
        self.identity_path = self.config_dir / "ROBO_IDENTITY.json"
        self.hash_path = self.config_dir / "ROBO_IDENTITY.sha256"
        self.master_path = Path(master_path) if master_path else None
        self.config_dir.mkdir(parents=True, exist_ok=True)
        self.backup_dir.mkdir(parents=True, exist_ok=True)

    def master_identity(self) -> dict:
        if self.master_path and self.master_path.exists():
            try:
                data = json.loads(self.master_path.read_text(encoding="utf-8"))
                if isinstance(data, dict):
                    return data
            except Exception:
                pass
        return deepcopy(DEFAULT_IDENTITY)

    def _backup_existing(self) -> Path | None:
        if not self.identity_path.exists():
            return None
        ts = time.strftime("%Y%m%d_%H%M%S")
        dst = self.backup_dir / f"ROBO_IDENTITY_{ts}.json"
        shutil.copy2(self.identity_path, dst)
        return dst

    def ensure(self) -> dict:
        master = self.master_identity()
        repaired = False
        reason = "identity healthy"
        current = None
        if self.identity_path.exists():
            try:
                current = json.loads(self.identity_path.read_text(encoding="utf-8"))
            except Exception:
                reason = "identity file was unreadable"
        if not isinstance(current, dict):
            self._backup_existing()
            current = deepcopy(master)
            repaired = True
        else:
            expected = _fingerprint(master)
            actual = _fingerprint(current)
            if actual != expected:
                self._backup_existing()
                # Preserve user/non-core extensions, but restore protected identity fields.
                merged = deepcopy(current)
                for key in LOCKED_KEYS:
                    merged[key] = deepcopy(master.get(key))
                merged["schema_version"] = master.get("schema_version", 1)
                merged["identity_version"] = master.get("identity_version", "0.9")
                current = merged
                repaired = True
                reason = "protected identity drift detected and repaired"
        self.identity_path.write_text(json.dumps(current, indent=2, ensure_ascii=False), encoding="utf-8")
        digest = _fingerprint(current)
        self.hash_path.write_text(digest + "\n", encoding="utf-8")
        return {
            "path": str(self.identity_path),
            "fingerprint": digest,
            "repaired": repaired,
            "reason": reason,
            "identity": current,
        }

    def summary_for_prompt(self) -> str:
        info = self.ensure()
        ident = info["identity"]
        rules = ident.get("core_rules", [])
        caps = ident.get("required_capabilities", [])
        return (
            f"Permanent identity: {ident.get('product')}. Purpose: {ident.get('purpose')} "
            f"Protected core rules: {' | '.join(rules)}. Required capabilities: {' | '.join(caps)}."
        )
