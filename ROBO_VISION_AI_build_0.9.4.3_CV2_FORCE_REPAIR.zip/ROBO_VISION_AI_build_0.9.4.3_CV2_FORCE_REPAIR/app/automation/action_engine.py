from __future__ import annotations
from pathlib import Path
import json
from app.training.pipeline import VisionPipeline, TrainingConfig
from app.system.hardware import detect_hardware, training_preset
from app.output.generator import generate_output_bundle
from app.vision.review import build_annotation_review, mine_hard_examples
from app.vision.vlm_review import vlm_review_queue
from app.vision.small_target import small_target_review
from app.improvement.controller import ControlledImprover

class ActionEngine:
    def __init__(self, project: Path, dataset: Path):
        self.project=Path(project); self.dataset=Path(dataset); self.pipeline=VisionPipeline(self.project,self.dataset)
    def _preset(self):
        h=detect_hardware(str(self.project)); return h,training_preset(h)
    def _target(self):
        try:return (json.loads((self.project/'project_brief.json').read_text(encoding='utf-8')).get('target_class') or 'person').lower()
        except Exception:return 'person'
    def _small_mode(self): return self._target() in {'enemy','soldier','person','human'}
    def auto_annotate(self, progress_cb=None):
        _,p=self._preset(); target=self._target()
        return self.pipeline.auto_annotate_person(model_name=p['model'],conf=.25,device=p['device'],progress_cb=progress_cb,target_name=target)
    def review_annotations(self, progress_cb=None):
        _,p=self._preset(); return build_annotation_review(self.dataset,model_name=p['model'],device=p['device'],progress_cb=progress_cb)
    def small_target_review(self, progress_cb=None):
        _,p=self._preset(); return small_target_review(self.dataset,model_name=p['model'],device=p['device'],progress_cb=progress_cb)
    def vlm_review_annotations(self, progress_cb=None):
        _,p=self._preset(); return vlm_review_queue(self.dataset,model_name=p['model'],device=p['device'],target=self._target(),progress_cb=progress_cb)
    def prepare_dataset(self, progress_cb=None): return self.pipeline.split(progress_cb=progress_cb)
    def train(self, quick=False, progress_cb=None):
        _,p=self._preset(); high=self._small_mode()
        cfg=TrainingConfig(model=p['model'],epochs=5 if quick else p['epochs'],imgsz=p.get('small_target_imgsz',p['imgsz']) if high else p['imgsz'],batch=p.get('small_target_batch',p['batch']) if high else p['batch'],workers=p['workers'],device=p['device'],amp=p['amp'])
        return self.pipeline.train(cfg,progress_cb=progress_cb)
    def mine_hard_examples(self, progress_cb=None):
        _,p=self._preset(); model=self.project/'models'/'best.pt'
        if not model.exists(): raise RuntimeError('best.pt does not exist yet. Train first.')
        return mine_hard_examples(self.project,self.dataset,model,device=p['device'],progress_cb=progress_cb)
    def improve_model(self, quick=False, progress_cb=None):
        _,p=self._preset(); imgsz=p.get('small_target_imgsz',640) if self._small_mode() else p['imgsz']; batch=p.get('small_target_batch',4) if self._small_mode() else min(4,p['batch'])
        return ControlledImprover(self.project,self.dataset,p['device'],imgsz=imgsz,batch=batch).run(epochs=3 if quick else 8,progress_cb=progress_cb,max_attempts=1 if quick else 2)
    def export(self):
        model=self.project/'models'/'best.pt'
        if not model.exists(): raise RuntimeError('best.pt does not exist yet. Train first.')
        return generate_output_bundle(self.project,model,far_target_mode=self._small_mode(),class_name=self._target())
