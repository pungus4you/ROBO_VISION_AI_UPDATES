from __future__ import annotations
import base64, json, urllib.request
from pathlib import Path

VISION_HINTS=("qwen3-vl","qwen2.5vl","qwen2-vl","gemma3","llava","minicpm-v","bakllava","moondream","vision")

class OllamaClient:
    def __init__(self,base="http://127.0.0.1:11434"): self.base=base.rstrip("/")
    def health(self)->bool:
        try:
            with urllib.request.urlopen(self.base+"/api/tags",timeout=2) as r: return r.status==200
        except Exception: return False
    def models(self)->list[str]:
        with urllib.request.urlopen(self.base+"/api/tags",timeout=5) as r:
            data=json.load(r)
        return [m.get("name","") for m in data.get("models",[])]
    def vision_models(self)->list[str]:
        return [m for m in self.models() if any(h in m.lower() for h in VISION_HINTS)]
    def best_vision_model(self)->str|None:
        models=self.vision_models()
        if not models:return None
        priority=("qwen3-vl","qwen2.5vl","qwen2-vl","gemma3","minicpm-v","llava","bakllava","moondream")
        for p in priority:
            for m in models:
                if p in m.lower(): return m
        return models[0]
    def chat(self,model:str,messages:list[dict],timeout=120)->str:
        payload=json.dumps({"model":model,"messages":messages,"stream":False}).encode()
        req=urllib.request.Request(self.base+"/api/chat",data=payload,headers={"Content-Type":"application/json"})
        with urllib.request.urlopen(req,timeout=timeout) as r: data=json.load(r)
        return data.get("message",{}).get("content","")
    def chat_with_images(self,model:str,prompt:str,images:list[str|Path],timeout=120)->str:
        encoded=[]
        for p in images:
            encoded.append(base64.b64encode(Path(p).read_bytes()).decode("ascii"))
        messages=[{"role":"user","content":prompt,"images":encoded}]
        return self.chat(model,messages,timeout=timeout)
