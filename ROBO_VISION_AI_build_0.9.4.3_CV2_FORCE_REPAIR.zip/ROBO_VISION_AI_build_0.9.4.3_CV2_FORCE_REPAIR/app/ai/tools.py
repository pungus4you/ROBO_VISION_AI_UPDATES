from __future__ import annotations
from dataclasses import dataclass
from typing import Callable,Any

@dataclass
class Tool:
    name:str; description:str; fn:Callable[...,Any]; destructive:bool=False

class ToolRegistry:
    def __init__(self): self._tools={}
    def register(self,name,description,fn,destructive=False): self._tools[name]=Tool(name,description,fn,destructive)
    def schema(self): return [{"name":t.name,"description":t.description,"destructive":t.destructive} for t in self._tools.values()]
    def call(self,name,**kwargs):
        if name not in self._tools: raise KeyError(name)
        return self._tools[name].fn(**kwargs)
