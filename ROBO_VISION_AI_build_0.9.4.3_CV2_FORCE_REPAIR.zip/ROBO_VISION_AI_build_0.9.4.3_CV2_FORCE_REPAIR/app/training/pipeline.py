from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import json, random, shutil

IMAGE_EXT={".jpg",".jpeg",".png",".bmp",".webp"}

@dataclass
class TrainingConfig:
    model: str = "yolo26s.pt"
    epochs: int = 30
    imgsz: int = 640
    batch: int = 8
    workers: int = 4
    device: str|int = 0
    amp: bool = True

class VisionPipeline:
    def __init__(self, project: Path, dataset: Path):
        self.project=Path(project); self.dataset=Path(dataset)
        self.raw=self.dataset/"images"/"raw"
        self.raw_labels=self.dataset/"labels"/"raw"
        self.raw_labels.mkdir(parents=True,exist_ok=True)

    def _images(self):
        return sorted([p for p in self.raw.iterdir() if p.is_file() and p.suffix.lower() in IMAGE_EXT])

    def auto_annotate_person(self, model_name="yolo26s.pt", conf=0.25, device=0, progress_cb=None, target_name="person"):
        from ultralytics import YOLO
        model=YOLO(model_name)
        images=self._images(); total=len(images)
        if total == 0: raise RuntimeError("No images are available to annotate.")
        labeled=0; boxes=0
        for i,img in enumerate(images,1):
            result=model.predict(source=str(img),conf=conf,device=device,verbose=False)[0]
            h,w=result.orig_shape; lines=[]
            if result.boxes is not None:
                for b in result.boxes:
                    if int(b.cls.item()) != 0: continue
                    x1,y1,x2,y2=[float(x) for x in b.xyxy[0].tolist()]
                    xc=((x1+x2)/2)/w; yc=((y1+y2)/2)/h; bw=(x2-x1)/w; bh=(y2-y1)/h
                    lines.append(f"0 {xc:.6f} {yc:.6f} {bw:.6f} {bh:.6f}")
            (self.raw_labels/f"{img.stem}.txt").write_text("\n".join(lines),encoding="utf-8")
            if lines: labeled+=1; boxes+=len(lines)
            if progress_cb: progress_cb(i,total,f"Auto-labeling {i}/{total}: {img.name}")
        self._write_classes([target_name])
        return {"images":total,"images_with_boxes":labeled,"boxes":boxes,"model":model_name,"class_name":target_name}

    def _write_classes(self, classes):
        meta=self.dataset/"dataset.json"; data={"name":self.dataset.name,"classes":classes}
        if meta.exists():
            try: data.update(json.loads(meta.read_text(encoding="utf-8")))
            except Exception: pass
            data["classes"]=classes
        meta.write_text(json.dumps(data,indent=2),encoding="utf-8")

    def split(self, train=.7, val=.2, test=.1, seed=42, classes=None, progress_cb=None):
        paired=[]
        for img in self._images():
            lab=self.raw_labels/f"{img.stem}.txt"
            if lab.exists(): paired.append((img,lab))
        if not paired: raise RuntimeError("No labeled images found. Auto-annotate or annotate first.")
        rnd=random.Random(seed); rnd.shuffle(paired)
        n=len(paired); n_train=max(1,int(n*train)); n_val=int(n*val)
        if n>=3 and n_val==0: n_val=1
        if n_train+n_val>n: n_val=max(0,n-n_train)
        buckets={"train":paired[:n_train],"val":paired[n_train:n_train+n_val],"test":paired[n_train+n_val:]}
        done=0
        for split,items in buckets.items():
            idir=self.dataset/"images"/split; ldir=self.dataset/"labels"/split
            idir.mkdir(parents=True,exist_ok=True); ldir.mkdir(parents=True,exist_ok=True)
            for p in idir.iterdir():
                if p.is_file(): p.unlink()
            for p in ldir.iterdir():
                if p.is_file(): p.unlink()
            for img,lab in items:
                shutil.copy2(img,idir/img.name); shutil.copy2(lab,ldir/lab.name); done+=1
                if progress_cb: progress_cb(done,n,f"Preparing dataset {done}/{n}")
        if classes is None:
            try: classes=json.loads((self.dataset/"dataset.json").read_text(encoding="utf-8")).get("classes") or ["person"]
            except Exception: classes=["person"]
        data_yaml=self.dataset/"data.yaml"
        yaml_text=(f"path: {self.dataset.as_posix()}\ntrain: images/train\nval: images/val\ntest: images/test\n"
                   f"names: {json.dumps({i:n for i,n in enumerate(classes)})}\n")
        data_yaml.write_text(yaml_text,encoding="utf-8")
        return {k:len(v) for k,v in buckets.items()} | {"data_yaml":str(data_yaml)}

    def train(self, cfg: TrainingConfig, progress_cb=None):
        from ultralytics import YOLO
        data=self.dataset/"data.yaml"
        if not data.exists(): raise RuntimeError("data.yaml missing. Split/prepare dataset first.")
        run_dir=self.project/"runs"; run_dir.mkdir(parents=True,exist_ok=True)
        model=YOLO(cfg.model)
        if progress_cb:
            def on_epoch_end(trainer):
                epoch=int(getattr(trainer,"epoch",0))+1
                progress_cb(epoch,cfg.epochs,f"Training epoch {epoch}/{cfg.epochs}")
            model.add_callback("on_train_epoch_end",on_epoch_end)
        train_args=dict(data=str(data),epochs=cfg.epochs,imgsz=cfg.imgsz,batch=cfg.batch,workers=cfg.workers,device=cfg.device,amp=cfg.amp,project=str(run_dir),name="latest",exist_ok=True)
        try:
            model.train(**train_args)
        except Exception as e:
            # Safe self-heal for the most common GPU training failure: VRAM exhaustion.
            text=f"{type(e).__name__}: {e}".lower()
            if ("out of memory" in text or "outofmemory" in text) and cfg.device != "cpu" and int(cfg.batch) > 1:
                try:
                    import torch
                    torch.cuda.empty_cache()
                except Exception:
                    pass
                retry_batch=max(1,int(cfg.batch)//2)
                if progress_cb: progress_cb(0,cfg.epochs,f"Self-heal: CUDA OOM detected. Retrying with batch {retry_batch} instead of {cfg.batch}")
                train_args["batch"]=retry_batch
                model=YOLO(cfg.model)
                if progress_cb:
                    def on_epoch_end_retry(trainer):
                        epoch=int(getattr(trainer,"epoch",0))+1
                        progress_cb(epoch,cfg.epochs,f"Training epoch {epoch}/{cfg.epochs} (recovery batch {retry_batch})")
                    model.add_callback("on_train_epoch_end",on_epoch_end_retry)
                model.train(**train_args)
            else:
                raise
        best=run_dir/"latest"/"weights"/"best.pt"
        if not best.exists(): raise RuntimeError(f"Training finished but best.pt not found at {best}")
        model_dir=self.project/"models"; model_dir.mkdir(exist_ok=True)
        final=model_dir/"best.pt"; shutil.copy2(best,final)
        if progress_cb: progress_cb(cfg.epochs,cfg.epochs,"Training complete")
        return {"best_pt":str(final),"run_dir":str(run_dir/"latest")}
