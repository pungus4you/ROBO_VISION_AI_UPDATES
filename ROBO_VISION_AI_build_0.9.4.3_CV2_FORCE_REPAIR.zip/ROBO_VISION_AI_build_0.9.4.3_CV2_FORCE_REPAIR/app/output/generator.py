from __future__ import annotations
from pathlib import Path
import json, shutil

SCREEN_SCRIPT = r'''from pathlib import Path
import cv2, json, time
import numpy as np
from mss import mss
from ultralytics import YOLO

HERE=Path(__file__).resolve().parent
PROJECT=HERE.parent
CFG=json.loads((HERE/'config.json').read_text(encoding='utf-8'))
model=YOLO(str(HERE/'best.pt'))
CONFIDENCE=float(CFG.get('confidence',0.32))
LOW_CONF=float(CFG.get('low_confidence',0.06))
MARKER_SUPPORTED_CONF=float(CFG.get('marker_supported_confidence',0.09))
MARKER_PERSIST=int(CFG.get('marker_persistence_frames',3))
IMGSZ=int(CFG.get('imgsz',960))
FAR=bool(CFG.get('far_target_mode',True))
CLASS_NAME=CFG.get('class_name','enemy').upper()
FEEDBACK_ROOT=PROJECT/'feedback'
(FEEDBACK_ROOT/'missed').mkdir(parents=True,exist_ok=True)
(FEEDBACK_ROOT/'wrong_box').mkdir(parents=True,exist_ok=True)

feedback_mode=None
current_frame=None
current_boxes=[]
marker_streaks={}

def red_markers(frame):
    hsv=cv2.cvtColor(frame,cv2.COLOR_BGR2HSV)
    mask=cv2.bitwise_or(
        cv2.inRange(hsv,np.array([0,125,145],np.uint8),np.array([14,255,255],np.uint8)),
        cv2.inRange(hsv,np.array([168,125,145],np.uint8),np.array([179,255,255],np.uint8)))
    mask=cv2.morphologyEx(mask,cv2.MORPH_OPEN,np.ones((2,2),np.uint8))
    n,_,stats,_=cv2.connectedComponentsWithStats(mask,8); out=[]
    H,W=frame.shape[:2]
    for i in range(1,n):
        x,y,w,h,a=map(int,stats[i]); cx=x+w/2; cy=y+h/2
        compact=(w<=32 and h<=24 and max(w,h)/max(1,min(w,h))<=4.0)
        in_gameplay=(W*.20<=cx<=W*.80 and H*.23<=cy<=H*.78)
        if 3<=a<=500 and compact and in_gameplay: out.append((x,y,x+w,y+h))
    return out

def marker_box(m,W,H):
    x1,y1,x2,y2=m; mw=max(2,x2-x1); mh=max(2,y2-y1); cx=(x1+x2)/2
    bw=max(18,mw*7); bh=max(28,mh*13)
    return max(0,int(cx-bw/2)),max(0,int(y1-mh*1.5)),min(W,int(cx+bw/2)),min(H,int(y2+bh))

def marker_supports_box(m,b):
    mx=(m[0]+m[2])/2; my=(m[1]+m[3])/2
    x1,y1,x2,y2=b
    return x1-10<=mx<=x2+10 and y1-22<=my<=y1+(y2-y1)*.42

def update_marker_streaks(markers):
    global marker_streaks
    seen=set()
    for m in markers:
        cx=(m[0]+m[2])/2; cy=(m[1]+m[3])/2
        key=(int(round(cx/16.0)),int(round(cy/16.0))); seen.add(key)
        marker_streaks[key]=min(MARKER_PERSIST+2,marker_streaks.get(key,0)+1)
    for key in list(marker_streaks):
        if key not in seen:
            marker_streaks[key]-=1
            if marker_streaks[key]<=0: marker_streaks.pop(key,None)

def marker_is_persistent(m,required=None):
    cx=(m[0]+m[2])/2; cy=(m[1]+m[3])/2
    key=(int(round(cx/16.0)),int(round(cy/16.0)))
    req=MARKER_PERSIST if required is None else int(required)
    return marker_streaks.get(key,0)>=req

def save_feedback(kind,x,y,box=None):
    global current_frame
    if current_frame is None: return
    root=FEEDBACK_ROOT/kind; stamp=time.strftime('%Y%m%d_%H%M%S')+f'_{int(time.time()*1000)%1000:03d}'
    full=root/f'{stamp}_frame.jpg'; cv2.imwrite(str(full),current_frame)
    H,W=current_frame.shape[:2]
    if box:
        x1,y1,x2,y2=map(int,box)
    else:
        half=140; x1=max(0,x-half); y1=max(0,y-half); x2=min(W,x+half); y2=min(H,y+half)
    crop=current_frame[y1:y2,x1:x2]
    if crop.size: cv2.imwrite(str(root/f'{stamp}_crop.jpg'),crop)
    meta={'kind':kind,'frame':full.name,'click':[int(x),int(y)],'box':[int(x1),int(y1),int(x2),int(y2)],'class_name':CLASS_NAME,'timestamp':stamp}
    (root/f'{stamp}.json').write_text(json.dumps(meta,indent=2),encoding='utf-8')
    print(f'[ROBO feedback] Saved {kind}: {root/f"{stamp}.json"}',flush=True)

def on_mouse(event,x,y,flags,param):
    global feedback_mode
    if event!=cv2.EVENT_LBUTTONDOWN or not feedback_mode: return
    if feedback_mode=='missed':
        save_feedback('missed',x,y)
    elif feedback_mode=='wrong_box':
        chosen=None
        for b in current_boxes:
            x1,y1,x2,y2=b['xyxy']
            if x1<=x<=x2 and y1<=y<=y2: chosen=b['xyxy']; break
        if chosen is None and current_boxes:
            chosen=min(current_boxes,key=lambda b: abs((b['xyxy'][0]+b['xyxy'][2])/2-x)+abs((b['xyxy'][1]+b['xyxy'][3])/2-y))['xyxy']
        save_feedback('wrong_box',x,y,chosen)
    feedback_mode=None

WIN='ROBO Vision AI - Small Target Live Detection'
CONTROL_WIN='ROBO Assist Controls'
ASSIST_FILE=HERE/'assist_settings.json'

def _nothing(v): pass

def _load_assist():
    base={'mode_auto':1,'strength':70,'assist_box':55,'manual_conf':32,'marker_boost':20,'center_bias':70}
    try:
        if ASSIST_FILE.exists(): base.update(json.loads(ASSIST_FILE.read_text(encoding='utf-8')))
    except Exception: pass
    return base

def _save_assist(values):
    try: ASSIST_FILE.write_text(json.dumps(values,indent=2),encoding='utf-8')
    except Exception: pass

def _assist_values():
    return {
        'mode_auto':cv2.getTrackbarPos('Mode 0=MAN 1=AUTO',CONTROL_WIN),
        'strength':cv2.getTrackbarPos('Strength',CONTROL_WIN),
        'assist_box':max(20,cv2.getTrackbarPos('Assist Box %',CONTROL_WIN)),
        'manual_conf':max(5,cv2.getTrackbarPos('Manual Conf %',CONTROL_WIN)),
        'marker_boost':cv2.getTrackbarPos('Marker Boost',CONTROL_WIN),
        'center_bias':cv2.getTrackbarPos('Center Bias',CONTROL_WIN),
    }

def _effective_settings(v):
    strength=max(0,min(100,v['strength']))
    if v['mode_auto']:
        conf=max(0.10,min(0.55,0.50-(strength/100.0)*0.38))
        marker_conf=max(0.04,min(conf,conf-(0.03+0.10*strength/100.0)))
        persist=max(2,5-int(round(3*strength/100.0)))
    else:
        conf=max(0.05,min(0.80,v['manual_conf']/100.0))
        marker_conf=max(0.03,min(conf,conf-(v['marker_boost']/100.0)*0.20))
        persist=MARKER_PERSIST
    return conf,marker_conf,persist

def _assist_rect(W,H,pct):
    scale=max(.20,min(1.0,pct/100.0))
    bw=int(W*scale); bh=int(H*scale)
    cx=W//2; cy=H//2
    return cx-bw//2,cy-bh//2,cx+bw//2,cy+bh//2

def _inside(cx,cy,r): return r[0]<=cx<=r[2] and r[1]<=cy<=r[3]

cv2.namedWindow(WIN,cv2.WINDOW_NORMAL)
cv2.setMouseCallback(WIN,on_mouse)
cv2.namedWindow(CONTROL_WIN,cv2.WINDOW_NORMAL)
settings=_load_assist()
cv2.createTrackbar('Mode 0=MAN 1=AUTO',CONTROL_WIN,int(settings['mode_auto']),1,_nothing)
cv2.createTrackbar('Strength',CONTROL_WIN,int(settings['strength']),100,_nothing)
cv2.createTrackbar('Assist Box %',CONTROL_WIN,int(settings['assist_box']),100,_nothing)
cv2.createTrackbar('Manual Conf %',CONTROL_WIN,int(settings['manual_conf']),80,_nothing)
cv2.createTrackbar('Marker Boost',CONTROL_WIN,int(settings['marker_boost']),100,_nothing)
cv2.createTrackbar('Center Bias',CONTROL_WIN,int(settings['center_bias']),100,_nothing)

with mss() as sct:
    monitor=sct.monitors[1]
    print('ROBO Vision AI 0.8.2 detector started.',flush=True)
    print('Separate ROBO Assist Controls window is active. It changes visual target emphasis only; it does not move the mouse or fire.',flush=True)
    print('Q=quit | M=mark a MISSED enemy then left-click it | X=mark a WRONG box then left-click it',flush=True)
    while True:
        frame=np.array(sct.grab(monitor)); frame=cv2.cvtColor(frame,cv2.COLOR_BGRA2BGR)
        current_frame=frame.copy(); H,W=frame.shape[:2]
        av=_assist_values(); effective_conf,effective_marker_conf,effective_persist=_effective_settings(av)
        assist_rect=_assist_rect(W,H,av['assist_box'])
        markers=red_markers(frame) if FAR else []; update_marker_streaks(markers)
        r=model.predict(frame,conf=min(LOW_CONF,effective_conf),device=0,imgsz=IMGSZ,verbose=False)[0]
        drawn=[]
        if r.boxes is not None:
            for b in r.boxes:
                if int(b.cls.item())!=0: continue
                conf=float(b.conf.item()); x1,y1,x2,y2=[int(v) for v in b.xyxy[0].tolist()]
                supported=any(marker_supports_box(m,(x1,y1,x2,y2)) for m in markers)
                if conf>=effective_conf or (supported and conf>=effective_marker_conf):
                    drawn.append({'xyxy':(x1,y1,x2,y2),'confidence':conf,'source':'model+marker' if supported and conf<effective_conf else 'model'})
        if FAR:
            for m in markers:
                if not marker_is_persistent(m,effective_persist): continue
                prop=marker_box(m,W,H)
                px1,py1,px2,py2=prop
                if any(max(0,min(px2,b['xyxy'][2])-max(px1,b['xyxy'][0]))*max(0,min(py2,b['xyxy'][3])-max(py1,b['xyxy'][1]))>0 for b in drawn):
                    continue
                drawn.append({'xyxy':prop,'confidence':0.0,'source':'persistent_marker'})
        # Visual assist selection: highlight one detected target inside the adjustable center box.
        # This never controls mouse/keyboard input.
        ax1,ay1,ax2,ay2=assist_rect; center=(W/2,H/2); selected=None; best_score=None
        for b in drawn:
            x1,y1,x2,y2=b['xyxy']; cx=(x1+x2)/2; cy=(y1+y2)/2
            if not _inside(cx,cy,assist_rect): continue
            dist=((cx-center[0])**2+(cy-center[1])**2)**0.5/max(1,(W**2+H**2)**0.5)
            conf=b['confidence'] if b['confidence']>0 else effective_marker_conf
            bias=av['center_bias']/100.0
            score=(1-bias)*conf + bias*(1-dist)
            if best_score is None or score>best_score: best_score=score; selected=b
        view=frame.copy(); current_boxes=drawn
        cv2.rectangle(view,(ax1,ay1),(ax2,ay2),(255,255,255),1)
        for b in drawn:
            x1,y1,x2,y2=b['xyxy']; src=b['source']; conf=b['confidence']; is_sel=(b is selected)
            if src=='persistent_marker': label=f'{CLASS_NAME} marker'; thickness=1
            else: label=f'{CLASS_NAME} {conf:.2f}'; thickness=2
            if is_sel: label='ASSIST '+label; thickness=3
            cv2.rectangle(view,(x1,y1),(x2,y2),(0,255,0),thickness)
            cv2.putText(view,label,(x1,max(16,y1-4)),cv2.FONT_HERSHEY_SIMPLEX,.45,(0,255,0),1,cv2.LINE_AA)
        mode='AUTO' if av['mode_auto'] else 'MANUAL'
        mode_text='NORMAL'
        if feedback_mode=='missed': mode_text='FEEDBACK: CLICK MISSED ENEMY'
        elif feedback_mode=='wrong_box': mode_text='FEEDBACK: CLICK WRONG BOX'
        cv2.putText(view,f'{mode_text} | Assist {mode} strength {av["strength"]}% box {av["assist_box"]}% | Q quit | M missed | X wrong box',(16,28),cv2.FONT_HERSHEY_SIMPLEX,.55,(255,255,255),2,cv2.LINE_AA)
        cv2.imshow(WIN,view)
        key=cv2.waitKey(1)&0xFF
        if key in (ord('q'),ord('Q')): break
        if key in (ord('m'),ord('M')):
            feedback_mode='missed'; print('[ROBO feedback] Click the missed enemy.',flush=True)
        elif key in (ord('x'),ord('X')):
            feedback_mode='wrong_box'; print('[ROBO feedback] Click the wrong box.',flush=True)
    _save_assist(_assist_values())
cv2.destroyAllWindows()
print('[ROBO detector] CLOSED. Feedback, if any, is saved under the project feedback folder.',flush=True)
'''

BOOTSTRAP_PS1 = r'''$ErrorActionPreference = "Stop"
$Here = Split-Path -Parent $MyInvocation.MyCommand.Path
$Detector = Join-Path $Here "{script_name}"
function Test-Python($Exe) {{ try {{ & $Exe -c "import ultralytics, cv2, mss, numpy" *> $null; return ($LASTEXITCODE -eq 0) }} catch {{ return $false }} }}
$candidates=@(); if ($env:ROBO_VISION_PYTHON) {{ $candidates += $env:ROBO_VISION_PYTHON }}
$candidates += (Get-ChildItem "C:\ROBO_VISION_AI\ROBO_VISION_AI_build_*\.venv\Scripts\python.exe" -ErrorAction SilentlyContinue | Sort-Object FullName -Descending | ForEach-Object FullName)
$candidates += @("python.exe","py.exe")
foreach ($py in $candidates) {{ if (Test-Python $py) {{ Write-Host "Using Python: $py"; & $py $Detector; exit $LASTEXITCODE }} }}
Write-Host "Compatible Python not found. Attempting dependency repair with Python 3.11..."
$pycmd=Get-Command py.exe -ErrorAction SilentlyContinue
if ($pycmd) {{ & py -3.11 -m pip install -r (Join-Path $Here "requirements.txt"); if ($LASTEXITCODE -eq 0) {{ & py -3.11 $Detector; exit $LASTEXITCODE }} }}
Write-Host "Automatic repair could not finish. Run ROBO Vision AI Repair and retry."; exit 1
'''

def generate_output_bundle(project:Path,model_path:Path,confidence:float=.32,far_target_mode:bool=True,class_name:str='enemy')->dict:
    project=Path(project); out=project/'output'; out.mkdir(parents=True,exist_ok=True)
    bundled=out/'best.pt'; shutil.copy2(model_path,bundled)
    script=out/f'{project.name}_detector.py'; script.write_text(SCREEN_SCRIPT,encoding='utf-8')
    cfg={
        'model':'best.pt','confidence':confidence,'low_confidence':0.06,
        'marker_supported_confidence':0.09,'marker_persistence_frames':3,
        'input':'screen','close_key':'q','far_target_mode':far_target_mode,
        'imgsz':960 if far_target_mode else 640,'class_name':class_name,
        'feedback_keys':{'missed':'M then left-click','wrong_box':'X then left-click'},
        'visual_assist':{'separate_controls_window':True,'mode':'auto','strength':70,'assist_box_percent':55,'input_control':False}
    }
    (out/'config.json').write_text(json.dumps(cfg,indent=2),encoding='utf-8')
    (out/'requirements.txt').write_text('ultralytics\nopencv-python\nmss\nnumpy\n',encoding='utf-8')
    ps1=out/'RUN_DETECTOR.ps1'; ps1.write_text(BOOTSTRAP_PS1.format(script_name=script.name),encoding='utf-8')
    run=out/'RUN.bat'; run.write_text('@echo off\r\npowershell -NoProfile -File "%~dp0RUN_DETECTOR.ps1"\r\necho.\r\necho ROBO detector session finished.\r\npause\r\n',encoding='utf-8')
    (out/'README.txt').write_text(
        'Double-click RUN.bat. Press Q to close.\n'
        'Small-target mode uses 960px inference, model+marker fusion and a temporally confirmed marker fallback.\n'
        'Feedback: press M then left-click a missed enemy; press X then left-click a wrong box.\n'
        'Feedback is saved under the project\\feedback folder for the next improvement cycle.\n'
        'A separate ROBO Assist Controls window provides Auto/Manual visual assist strength, center-box size, confidence, marker boost and center bias.\n'
        'Visual assist only highlights detections inside the guide box; it does not move the mouse, press keys or fire.\n'
        'Edit config.json to tune confidence, marker_supported_confidence, marker_persistence_frames or imgsz.\n',encoding='utf-8')
    return {'output_dir':str(out),'best_pt':str(bundled),'script':str(script),'run_bat':str(run),'runner_ps1':str(ps1),'far_target_mode':far_target_mode,'imgsz':cfg['imgsz'],'feedback_dir':str(project/'feedback')}
