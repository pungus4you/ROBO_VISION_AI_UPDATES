from __future__ import annotations

import json
import re
from pathlib import Path

WORD_RE = re.compile(r"[A-Za-z0-9_\-]{3,}")


class KnowledgeStore:
    def __init__(self, root: Path):
        self.root = Path(root)
        self.docs_dir = self.root / "knowledge" / "documents"
        self.index_path = self.root / "knowledge" / "index.json"
        self.docs_dir.mkdir(parents=True, exist_ok=True)

    def _entries(self) -> list[dict]:
        if not self.index_path.exists():
            return []
        try:
            data = json.loads(self.index_path.read_text(encoding="utf-8"))
            return data if isinstance(data, list) else []
        except Exception:
            return []

    def save_index(self, entries: list[dict]) -> None:
        self.index_path.parent.mkdir(parents=True, exist_ok=True)
        self.index_path.write_text(json.dumps(entries, indent=2, ensure_ascii=False), encoding="utf-8")

    def add_document(self, *, source_id: str, title: str, url: str, text: str, fetched_at: str, sha256: str) -> dict:
        safe = re.sub(r"[^A-Za-z0-9_.-]+", "_", source_id).strip("_") or "source"
        path = self.docs_dir / f"{safe}.txt"
        path.write_text(text, encoding="utf-8", errors="ignore")
        entries = [x for x in self._entries() if x.get("source_id") != source_id]
        item = {
            "source_id": source_id,
            "title": title,
            "url": url,
            "path": str(path),
            "fetched_at": fetched_at,
            "sha256": sha256,
            "chars": len(text),
        }
        entries.append(item)
        self.save_index(entries)
        return item

    def search(self, query: str, limit: int = 3, max_chars_each: int = 1400) -> list[dict]:
        terms = {w.lower() for w in WORD_RE.findall(query)}
        if not terms:
            return []
        scored = []
        for entry in self._entries():
            try:
                p = Path(entry["path"])
                if not p.exists():
                    continue
                text = p.read_text(encoding="utf-8", errors="ignore")
            except Exception:
                continue
            low = text.lower()
            score = sum(low.count(t) for t in terms)
            if score <= 0:
                continue
            # Return a compact region around the first useful hit.
            positions = [low.find(t) for t in terms if low.find(t) >= 0]
            pos = min(positions) if positions else 0
            start = max(0, pos - 300)
            snippet = text[start:start + max_chars_each].strip()
            scored.append((score, {**entry, "snippet": snippet}))
        scored.sort(key=lambda x: x[0], reverse=True)
        return [x[1] for x in scored[:limit]]

    def prompt_context(self, query: str, limit: int = 3) -> str:
        hits = self.search(query, limit=limit)
        if not hits:
            return ""
        parts = ["Local refreshed knowledge (may be newer than the model; use only when relevant):"]
        for h in hits:
            parts.append(f"SOURCE: {h.get('title')} | fetched {h.get('fetched_at')} | {h.get('url')}\n{h.get('snippet')}")
        return "\n\n".join(parts)
