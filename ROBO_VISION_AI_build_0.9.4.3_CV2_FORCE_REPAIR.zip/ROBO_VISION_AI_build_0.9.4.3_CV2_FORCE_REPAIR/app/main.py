import sys
from PySide6.QtWidgets import QApplication
from PySide6.QtCore import QTimer
from app.core.paths import ensure_layout
from app.ui.main_window import MainWindow
from app.update.manager import CURRENT_VERSION

def _mark_healthy(paths):
    try:
        d=paths["root"]/"updates"/"health"
        d.mkdir(parents=True,exist_ok=True)
        (d/f"{CURRENT_VERSION}.ok").write_text("healthy\n",encoding="utf-8")
    except Exception:
        pass

def main():
    paths=ensure_layout()
    app=QApplication(sys.argv)
    w=MainWindow(); w.show()
    QTimer.singleShot(1500, lambda: _mark_healthy(paths))
    return app.exec()
if __name__=="__main__": raise SystemExit(main())
