from __future__ import annotations
from pathlib import Path

TRUSTED_MANIFEST_URL = "https://raw.githubusercontent.com/pungus4you/ROBO_VISION_AI_UPDATES/main/manifest.json"

def install_strategy(online: bool, cache_dir: Path, has_winget: bool, has_python: bool) -> list[str]:
    steps=[]
    cache=Path(cache_dir)
    if has_python: steps.append("use_existing_python")
    else:
        if has_winget and online: steps.append("install_python_winget")
        if (cache/"python-3.11-amd64.exe").exists(): steps.append("install_python_cached_official")
        if not steps: steps.append("request_supported_python_install")
    if any(cache.glob("*.whl")): steps.append("install_dependencies_offline_cache")
    if online: steps.append("install_dependencies_online_fallback")
    steps += ["verify_core_imports","run_project_tests","preserve_user_data"]
    return steps

def protected_data_names() -> tuple[str,...]:
    return ("projects","models","config","knowledge","updates","logs")
