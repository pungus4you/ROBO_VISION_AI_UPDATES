from __future__ import annotations
from pathlib import Path
import json, shutil, time
from app.improvement.experiments import ExperimentDB

IMAGE_EXT={'.jpg','.jpeg','.png','.bmp','.webp'}

def metric_dict(metrics):
    box=getattr(metrics,'box',metrics)
    def g(name,default=0.0):
        try:return float(getattr(box,name))
        except Exception:return float(default)
    return {'map50_95':g('map'),'map50':g('map50'),'precision':g('mp'),'recall':g('mr')}

def score(m):
    return m.get('map50_95',0.0)+0.15*m.get('recall',0.0)+0.05*m.get('precision',0.0)

def candidate_is_better(base,cand,min_gain=0.002):
    return score(cand) >= score(base)+min_gain and cand.get('map50_95',0) >= base.get('map50_95',0)-0.002

def _read_labels(p:Path):
    try:return [x for x in p.read_text(encoding='utf-8').splitlines() if x.strip()]
    except Exception:return []

def build_candidate_dataset(dataset:Path, out:Path, hard_train:list[dict], copies:int=1):
    dataset=Path(dataset); out=Path(out)
    if out.exists(): shutil.rmtree(out)
    shutil.copytree(dataset,out)
    train_i=out/'images'/'train'; train_l=out/'labels'/'train'
    names={x.get('image') for x in hard_train if x.get('split')=='train'}
    added=0
    for name in names:
        src_i=dataset/'images'/'train'/name; src_l=dataset/'labels'/'train'/f'{Path(name).stem}.txt'
        if not src_i.exists() or not src_l.exists(): continue
        for n in range(copies):
            stem=f'{src_i.stem}__hard{n+1}'
            shutil.copy2(src_i,train_i/f'{stem}{src_i.suffix}')
            shutil.copy2(src_l,train_l/f'{stem}.txt'); added+=1
    # Rewrite yaml path to candidate dataset.
    data=out/'data.yaml'
    txt=data.read_text(encoding='utf-8') if data.exists() else ''
    lines=[]
    for line in txt.splitlines():
        lines.append(f'path: {out.as_posix()}' if line.startswith('path:') else line)
    data.write_text('\n'.join(lines)+'\n',encoding='utf-8')
    return {'dataset':str(out),'oversampled_train_images':added}

class ControlledImprover:
    def __init__(self, project:Path, dataset:Path, device=0, imgsz=640, batch=4):
        self.project=Path(project); self.dataset=Path(dataset); self.device=device; self.imgsz=int(imgsz); self.batch=int(batch)
        self.root=self.project/'improvement'; self.root.mkdir(parents=True,exist_ok=True)
        self.db=ExperimentDB(self.root/'experiments.sqlite3')

    def _eval(self, model_path:Path):
        from ultralytics import YOLO
        model=YOLO(str(model_path))
        m=model.val(data=str(self.dataset/'data.yaml'),split='val',device=self.device,verbose=False,plots=False,workers=0)
        return metric_dict(m)

    def _mine_train(self, model_path:Path, conf=.15):
        from app.vision.review import mine_hard_examples
        return mine_hard_examples(self.project,self.dataset,model_path,device=self.device,conf=conf,splits=('train',),output_name='hard_train.json')

    def run(self, epochs=8, progress_cb=None, max_attempts=2):
        from ultralytics import YOLO
        best=self.project/'models'/'best.pt'
        if not best.exists(): raise RuntimeError('best.pt does not exist yet. Train first.')
        stamp=time.strftime('%Y%m%d_%H%M%S')
        history=self.project/'models'/'history'; history.mkdir(parents=True,exist_ok=True)
        baseline_copy=history/f'best_before_improvement_{stamp}.pt'; shutil.copy2(best,baseline_copy)
        baseline=self._eval(best)
        train_hard=self._mine_train(best)
        attempts=[]; accepted=False; final_metrics=baseline; selected=str(best)
        for attempt in range(1,max_attempts+1):
            if progress_cb: progress_cb(attempt-1,max_attempts,f'Improvement attempt {attempt}/{max_attempts}: preparing hard-example dataset')
            candidate_ds=self.root/f'candidate_dataset_{stamp}_{attempt}'
            build_candidate_dataset(self.dataset,candidate_ds,train_hard.get('items',[]),copies=attempt)
            model=YOLO(str(best))
            run_name=f'improvement_{stamp}_{attempt}'
            args=dict(data=str(candidate_ds/'data.yaml'),epochs=max(3,int(epochs)),imgsz=self.imgsz,batch=self.batch,workers=0,device=self.device,amp=True,
                      project=str(self.project/'runs'),name=run_name,exist_ok=True,
                      mosaic=0.8 if attempt==1 else 0.5,close_mosaic=max(1,int(epochs)//3),fliplr=0.5,translate=0.12,scale=0.45)
            if progress_cb:
                def cb(trainer,a=attempt):
                    e=int(getattr(trainer,'epoch',0))+1; progress_cb(e,max(1,int(epochs)),f'Improvement attempt {a}: epoch {e}/{epochs}')
                model.add_callback('on_train_epoch_end',cb)
            model.train(**args)
            cand=self.project/'runs'/run_name/'weights'/'best.pt'
            if not cand.exists(): raise RuntimeError(f'Candidate training did not produce {cand}')
            
            if progress_cb: progress_cb(max(1,int(epochs)),max(1,int(epochs)),f'Improvement attempt {attempt}: validating candidate (Windows-safe workers=0)')
            cm=self._eval(cand)
            if progress_cb: progress_cb(max(1,int(epochs)),max(1,int(epochs)),f'Improvement attempt {attempt}: validation finished, comparing metrics')
            ok=candidate_is_better(baseline,cm)
            rec={'attempt':attempt,'baseline':baseline,'candidate':cm,'accepted':ok,'candidate_path':str(cand)}; attempts.append(rec)
            self.db.add(run_name,'hard-example oversampling + bounded augmentation',baseline,cm,ok)
            if ok:
                shutil.copy2(cand,best); final_metrics=cm; selected=str(best); accepted=True; break
            rejected=self.project/'models'/'rejected'; rejected.mkdir(parents=True,exist_ok=True)
            shutil.copy2(cand,rejected/f'{run_name}.pt')
        result={'accepted':accepted,'status':'Improved' if accepted else 'Rolled back / kept baseline','baseline_metrics':baseline,'final_metrics':final_metrics,
                'baseline_backup':str(baseline_copy),'selected_model':selected,'attempts':attempts,'hard_train_examples':train_hard.get('hard_examples',0)}
        if progress_cb: progress_cb(max_attempts,max_attempts,'Finalizing improvement decision and rollback state')
        (self.root/'last_improvement.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
        if progress_cb: progress_cb(max_attempts,max_attempts,result['status'])
        return result
