from pathlib import Path
import sqlite3, json, datetime
class ExperimentDB:
    def __init__(self,path:Path):
        path.parent.mkdir(parents=True,exist_ok=True); self.db=sqlite3.connect(path)
        self.db.execute("CREATE TABLE IF NOT EXISTS experiments(id INTEGER PRIMARY KEY, name TEXT, reason TEXT, baseline TEXT, candidate TEXT, accepted INTEGER, created TEXT)")
        self.db.commit()
    def add(self,name,reason,baseline,candidate,accepted):
        self.db.execute("INSERT INTO experiments(name,reason,baseline,candidate,accepted,created) VALUES(?,?,?,?,?,?)",(name,reason,json.dumps(baseline),json.dumps(candidate),int(accepted),datetime.datetime.now().isoformat(timespec='seconds'))); self.db.commit()
    def list(self): return list(self.db.execute("SELECT id,name,reason,accepted,created FROM experiments ORDER BY id DESC"))
