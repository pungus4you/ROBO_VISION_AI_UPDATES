from __future__ import annotations
from pathlib import Path
import json, shutil, datetime

class ProjectManager:
    def __init__(self, projects_root: Path): self.root=projects_root; self.root.mkdir(parents=True,exist_ok=True)
    def create(self,name:str,description:str="") -> Path:
        safe="".join(c for c in name.strip() if c.isalnum() or c in "-_ ").strip().replace(" ","_")
        if not safe: raise ValueError("Invalid project name")
        p=self.root/safe
        if p.exists(): raise FileExistsError(safe)
        for d in ["datasets","annotations","models","runs","evaluations","config","history"]: (p/d).mkdir(parents=True,exist_ok=True)
        meta={"name":name,"description":description,"created":datetime.datetime.now().isoformat(timespec="seconds"),"classes":[]}
        (p/"project.json").write_text(json.dumps(meta,indent=2),encoding="utf-8")
        return p
    def list(self): return sorted([p for p in self.root.iterdir() if p.is_dir() and (p/"project.json").exists()])
    def delete(self,name:str):
        p=self.root/name
        if not (p/"project.json").exists(): raise FileNotFoundError(name)
        shutil.rmtree(p)
