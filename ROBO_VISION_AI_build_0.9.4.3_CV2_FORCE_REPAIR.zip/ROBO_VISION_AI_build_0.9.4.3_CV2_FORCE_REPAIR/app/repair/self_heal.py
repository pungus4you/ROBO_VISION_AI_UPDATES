from __future__ import annotations
from dataclasses import dataclass, asdict
from pathlib import Path
import json, sys, subprocess, time, shutil

@dataclass
class RepairReport:
    signature: str
    cause: str
    action: str
    success: bool
    detail: str = ""
    def to_dict(self): return asdict(self)

SAFE_PACKAGE_MAP = {
    "ultralytics": "ultralytics>=8.4.155",
    "cv2": "opencv-python>=4.9",
    "mss": "mss>=9",
    "numpy": "numpy>=1.26,<3",
    "PIL": "pillow>=10",
    "psutil": "psutil>=5.9",
}

def classify_error(text: str) -> tuple[str,str]:
    t = (text or "").lower()
    if "cuda out of memory" in t or "outofmemoryerror" in t:
        return "cuda_oom", "GPU VRAM was exhausted during the operation."
    if "modulenotfounderror" in t or "no module named" in t:
        return "missing_python_module", "A required Python module is missing from the active environment."
    if "best.pt" in t and ("not found" in t or "does not exist" in t):
        return "missing_best_pt", "Training/export did not produce or locate best.pt."
    if "permissionerror" in t or "access is denied" in t:
        return "permission", "Windows denied file or folder access."
    if "no space left" in t or "disk full" in t:
        return "disk_full", "The target disk does not have enough free space."
    return "unknown", "The failure does not match a verified automatic repair recipe yet."

def safe_repair(error_text: str, log_dir: Path | None = None) -> RepairReport:
    sig, cause = classify_error(error_text)
    action = "No automatic change made."
    success = False
    detail = ""
    if sig == "missing_python_module":
        missing = None
        low = error_text.lower()
        if "'torch'" in low or '"torch"' in low or "named torch" in low:
            action = "Repair PyTorch inside the exact Python environment running ROBO Vision AI."
            try:
                cmd = [sys.executable, "-m", "pip", "install", "--upgrade", "torch", "torchvision"]
                if shutil.which("nvidia-smi"):
                    cmd += ["--index-url", "https://download.pytorch.org/whl/cu126"]
                p = subprocess.run(cmd, capture_output=True, text=True, timeout=1800)
                success = p.returncode == 0
                detail = (p.stdout + "\n" + p.stderr)[-4000:]
                if success:
                    q = subprocess.run([sys.executable, "-c", "import torch; print(torch.__version__); print(torch.cuda.is_available())"], capture_output=True, text=True, timeout=60)
                    success = q.returncode == 0
                    detail += "\nVERIFY:\n" + q.stdout + q.stderr
            except Exception as e:
                detail = f"{type(e).__name__}: {e}"
            report = RepairReport(sig, cause, action, success, detail)
            if log_dir:
                log_dir = Path(log_dir); log_dir.mkdir(parents=True, exist_ok=True)
                payload = report.to_dict() | {"time": time.strftime("%Y-%m-%d %H:%M:%S")}
                (log_dir / "last_repair_report.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")
            return report
        for mod in SAFE_PACKAGE_MAP:
            if f"'{mod.lower()}'" in low or f'"{mod.lower()}"' in low or f"named {mod.lower()}" in low:
                missing = mod; break
        if missing:
            pkg = SAFE_PACKAGE_MAP[missing]
            action = f"Install verified dependency {pkg} into the current ROBO environment."
            try:
                p = subprocess.run([sys.executable, "-m", "pip", "install", pkg], capture_output=True, text=True, timeout=600)
                success = p.returncode == 0
                detail = (p.stdout + "\n" + p.stderr)[-4000:]
            except Exception as e:
                detail = f"{type(e).__name__}: {e}"
    elif sig == "cuda_oom":
        action = "Retry training with a smaller batch size/model preset."
        success = True  # action engine can safely perform this retry itself
        detail = "No packages changed."
    report = RepairReport(sig, cause, action, success, detail)
    if log_dir:
        log_dir = Path(log_dir); log_dir.mkdir(parents=True, exist_ok=True)
        payload = report.to_dict() | {"time": time.strftime("%Y-%m-%d %H:%M:%S")}
        (log_dir / "last_repair_report.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")
    return report
