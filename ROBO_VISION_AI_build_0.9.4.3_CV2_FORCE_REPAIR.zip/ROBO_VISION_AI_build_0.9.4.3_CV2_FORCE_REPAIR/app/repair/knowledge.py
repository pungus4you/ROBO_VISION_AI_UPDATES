from pathlib import Path
import json, datetime
class RepairKnowledge:
    def __init__(self,path:Path): self.path=path; self.path.parent.mkdir(parents=True,exist_ok=True); self.data=self._load()
    def _load(self):
        try:return json.loads(self.path.read_text())
        except Exception:return {"repairs":[]}
    def record(self,signature,cause,fix,success,verification=""):
        self.data["repairs"].append({"signature":signature,"cause":cause,"fix":fix,"success":bool(success),"verification":verification,"time":datetime.datetime.now().isoformat(timespec="seconds")})
        self.path.write_text(json.dumps(self.data,indent=2))
    def proven(self,signature):
        return [r for r in reversed(self.data["repairs"]) if r["signature"]==signature and r["success"]]
