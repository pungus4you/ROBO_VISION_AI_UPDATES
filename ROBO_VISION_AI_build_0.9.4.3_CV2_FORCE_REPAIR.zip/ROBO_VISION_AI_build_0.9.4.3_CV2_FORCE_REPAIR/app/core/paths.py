from pathlib import Path
import os

def app_home() -> Path:
    base=os.environ.get("ROBO_VISION_HOME")
    if base: return Path(base)
    if os.name=="nt": return Path(r"C:\ROBO_VISION_AI")
    return Path.home()/"ROBO_VISION_AI"

def ensure_layout(root: Path|None=None) -> dict[str,Path]:
    root=root or app_home()
    names=["projects","models","ai_models","runs","exports","knowledge","logs","config","tests","backups","recordings","screenshots"]
    out={"root":root}
    root.mkdir(parents=True,exist_ok=True)
    for n in names:
        p=root/n; p.mkdir(parents=True,exist_ok=True); out[n]=p
    return out
