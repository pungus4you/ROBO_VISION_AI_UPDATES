$ErrorActionPreference = "Stop"
$Root = $PSScriptRoot
$LogDir = Join-Path $Root "logs"
$CacheDir = Join-Path $Root "offline_cache"
New-Item -ItemType Directory -Force -Path $LogDir | Out-Null
$Log = Join-Path $LogDir "installer.log"
Start-Transcript -Path $Log -Append | Out-Null

Write-Host "==========================================" -ForegroundColor Cyan
Write-Host " ROBO VISION AI 0.9.4.3 PORTABLE SETUP" -ForegroundColor Cyan
Write-Host "==========================================" -ForegroundColor Cyan
Write-Host "Install folder: $Root"
Write-Host "Strategy: offline cache -> normal commands -> supported Windows fallback methods"

function Run-Step($Name, [scriptblock]$Block) {
    Write-Host "`n[$Name]" -ForegroundColor Yellow
    try { $global:LASTEXITCODE=0; & $Block; if ($LASTEXITCODE -and $LASTEXITCODE -ne 0) { throw "Command exited with code $LASTEXITCODE" }; Write-Host "PASS: $Name" -ForegroundColor Green }
    catch { Write-Host "FAILED: $Name" -ForegroundColor Red; Write-Host $_.Exception.Message -ForegroundColor Red; throw }
}
function Test-Internet {
    try { $r=Invoke-WebRequest -Uri "https://raw.githubusercontent.com/pungus4you/ROBO_VISION_AI_UPDATES/main/manifest.json" -Method Head -TimeoutSec 8 -UseBasicParsing; return $true } catch { return $false }
}
function Find-Python311 {
    $candidates=@(
        @{Exe="py";Args=@("-3.11")},
        @{Exe="python";Args=@()},
        @{Exe="python3";Args=@()}
    )
    foreach($c in $candidates){
        try { $o=& $c.Exe @($c.Args) --version 2>&1; if($LASTEXITCODE -eq 0 -and "$o" -match "Python 3\.(11|12)"){ return @{Exe=$c.Exe;Args=@($c.Args);Version="$o"} } } catch {}
    }
    return $null
}
function Install-PythonSupported {
    if (Get-Command winget -ErrorAction SilentlyContinue) {
        Write-Host "Trying winget for Python 3.11..."
        & winget install -e --id Python.Python.3.11 --accept-source-agreements --accept-package-agreements --silent
        if($LASTEXITCODE -eq 0){ return $true }
        Write-Host "winget did not succeed; trying the next supported method." -ForegroundColor Yellow
    }
    if(Test-Path (Join-Path $CacheDir "python-3.11-amd64.exe")){
        Write-Host "Trying cached official Python installer..."
        $exe=Join-Path $CacheDir "python-3.11-amd64.exe"
        $p=Start-Process -FilePath $exe -ArgumentList "/quiet InstallAllUsers=0 PrependPath=1 Include_test=0" -Wait -PassThru
        if($p.ExitCode -eq 0){ return $true }
    }
    return $false
}
function Pip-Install([string[]]$PipArgs) {
    if(Test-Path $CacheDir){
        $wheels=Get-ChildItem $CacheDir -Filter *.whl -ErrorAction SilentlyContinue
        if($wheels){
            Write-Host "Trying offline package cache first..."
            & $script:Py -m pip install --no-index --find-links $CacheDir @PipArgs
            if($LASTEXITCODE -eq 0){ return $true }
            Write-Host "Offline cache was incomplete; trying online source if available." -ForegroundColor Yellow
        }
    }
    if($script:Online){ & $script:Py -m pip install @PipArgs; return ($LASTEXITCODE -eq 0) }
    return $false
}

Run-Step "System and hardware check" {
    Write-Host ("Windows: " + [System.Environment]::OSVersion.VersionString)
    Write-Host ("64-bit OS: " + [Environment]::Is64BitOperatingSystem)
    $drive=Get-PSDrive -Name ([IO.Path]::GetPathRoot($Root).Substring(0,1)); Write-Host ("Free disk GB: "+[math]::Round($drive.Free/1GB,1))
    $script:Online=Test-Internet; Write-Host ("Internet available: "+$script:Online)
    $script:HasNvidia=[bool](Get-Command nvidia-smi -ErrorAction SilentlyContinue)
    if($script:HasNvidia){ & nvidia-smi --query-gpu=name,driver_version,memory.total --format=csv,noheader } else { Write-Host "No NVIDIA driver detected; CPU mode remains available." }
}

Run-Step "Find or install Python" {
    $found=Find-Python311
    if(-not $found){
        Write-Host "Python 3.11/3.12 not found. Trying supported installation fallbacks..."
        if(-not (Install-PythonSupported)){ throw "Python is missing. No supported automatic method succeeded. If Windows policy blocked installation, approve the normal UAC/installer prompt or provide the offline cache." }
        Start-Sleep -Seconds 2; $found=Find-Python311
    }
    if(-not $found){ throw "Python installation completed but Python is not yet discoverable. Restart Windows and run setup again." }
    $script:PyExe=$found.Exe; $script:PyPrefix=$found.Args; Write-Host ("Using "+$found.Version)
}

$Venv=Join-Path $Root ".venv"; $script:Py=Join-Path $Venv "Scripts\python.exe"
Run-Step "Create or repair isolated environment" {
    if(Test-Path $script:Py){
        try { & $script:Py -c "import sys; print(sys.version)" | Out-Null; if($LASTEXITCODE -ne 0){ throw "bad venv" } }
        catch { Rename-Item $Venv ($Venv+".broken_"+(Get-Date -Format yyyyMMddHHmmss)) -ErrorAction SilentlyContinue }
    }
    if(-not (Test-Path $script:Py)){ & $script:PyExe @($script:PyPrefix) -m venv $Venv; if($LASTEXITCODE -ne 0){ throw "Could not create virtual environment." } }
}

Run-Step "Installer tools" {
    if(-not (Pip-Install @("--upgrade","pip","setuptools","wheel"))){ throw "Could not install pip/setuptools/wheel from offline cache or internet." }
}

if($script:HasNvidia){
    Run-Step "NVIDIA CUDA PyTorch" {
        $ok=$false
        if(Test-Path $CacheDir){
            & $script:Py -m pip install --no-index --find-links $CacheDir torch torchvision
            if($LASTEXITCODE -eq 0){ $ok=$true }
        }
        if(-not $ok -and $script:Online){
            & $script:Py -m pip install --upgrade torch torchvision --index-url https://download.pytorch.org/whl/cu126
            if($LASTEXITCODE -eq 0){ $ok=$true }
        }
        if(-not $ok){ throw "CUDA PyTorch could not be installed. Build/copy the offline cache or connect to the internet." }
    }
}

Run-Step "Application dependencies" {
    $req=Join-Path $Root "requirements.txt"
    $ok=$false
    if(Test-Path $CacheDir){ & $script:Py -m pip install --no-index --find-links $CacheDir -r $req; if($LASTEXITCODE -eq 0){$ok=$true} }
    if(-not $ok -and $script:Online){ & $script:Py -m pip install -r $req; if($LASTEXITCODE -eq 0){$ok=$true} }
    if(-not $ok){ throw "Dependencies could not be installed from offline cache or internet." }
}

Run-Step "Verify and self-repair core imports" {
    & $script:Py -c "import PySide6, cv2, mss, psutil, numpy, PIL, ultralytics, torch; print('CORE IMPORTS OK'); print('TORCH',torch.__version__); print('CUDA',torch.cuda.is_available())"
    if($LASTEXITCODE -ne 0){
        Write-Host "Verification failed. Running component repair once..." -ForegroundColor Yellow
        Write-Host "Repairing OpenCV cleanly before reinstalling the remaining requirements..." -ForegroundColor Yellow
        & $script:Py -m pip uninstall -y opencv-python opencv-python-headless opencv-contrib-python opencv-contrib-python-headless 2>$null | Out-Host
        $site=& $script:Py -c "import site; print(site.getsitepackages()[0])"
        if($LASTEXITCODE -eq 0 -and $site){ $cv2dir=Join-Path $site.Trim() "cv2"; if(Test-Path $cv2dir){ Remove-Item -Recurse -Force $cv2dir -ErrorAction SilentlyContinue } }
        if(Test-Path $CacheDir){
            & $script:Py -m pip install --force-reinstall --no-index --find-links $CacheDir opencv-python
            & $script:Py -m pip install --force-reinstall --no-index --find-links $CacheDir -r (Join-Path $Root "requirements.txt")
        } elseif($script:Online){
            & $script:Py -m pip install --no-cache-dir --force-reinstall "opencv-python>=4.9"
            & $script:Py -m pip install --upgrade --force-reinstall -r (Join-Path $Root "requirements.txt")
        }
        & $script:Py -c "import PySide6, cv2, mss, psutil, numpy, PIL, ultralytics, torch; print('CORE IMPORTS OK AFTER REPAIR'); print('CV2',cv2.__version__)"
        if($LASTEXITCODE -ne 0){ throw "Core verification failed after one safe repair attempt." }
    }
}

Run-Step "Project tests" {
    $TestTemp=Join-Path $Root ".pytest_tmp"; if(Test-Path $TestTemp){Remove-Item -Recurse -Force $TestTemp -ErrorAction SilentlyContinue}; New-Item -ItemType Directory -Force -Path $TestTemp|Out-Null
    Push-Location $Root; try { $env:TEMP=$TestTemp; $env:TMP=$TestTemp; & $script:Py -m pytest -q --basetemp (Join-Path $TestTemp "run") -o "cache_dir=$Root\.pytest_cache" } finally { Pop-Location }
}

Write-Host "`n==========================================" -ForegroundColor Green
Write-Host " PORTABLE INSTALL / REPAIR COMPLETE" -ForegroundColor Green
Write-Host "==========================================" -ForegroundColor Green
Write-Host "Start with START_ROBO_VISION.bat"
Write-Host "For another PC: copy this folder. Online setup works automatically; offline setup uses offline_cache when present."
Write-Host "Installer log: $Log"
Stop-Transcript | Out-Null
