# ROBO Vision AI — Master Requirements

This file is the persistent source of truth for the project. New builds must preserve working features from earlier builds unless a replacement is explicitly better and verified.

## Product goal
ROBO Vision AI is a local-first, AI-first computer-vision studio. The normal user experience is chat-driven rather than menu-driven:

**Chat with AI → give images/video/game-window captures → dataset → auto-annotation → validation → training → testing/improvement → final `best.pt` + ready-to-use `.py`.**

## AI-first behavior
- AI chat is the main workflow.
- Remember confirmed project goal, target classes and instructions.
- Never repeatedly ask for information already known.
- When the user says "do everything", "you decide", "don't ask", or equivalent, enable autonomous mode.
- In autonomous mode, choose sensible defaults and continue.
- Ask only when permission is required, a genuinely blocking fact is missing, or before an irreversible destructive action.
- Never pretend an operation completed unless a tool/result confirms it.
- Use structured application state rather than guessing from screenshots when state is already known.

## Inputs
- Upload individual images.
- Upload image folders.
- Upload video and extract frames.
- Capture full screen / monitor / window / region.
- Select a game/application window.
- Later: configurable controller/keyboard capture triggers.

## Dataset workflow
- Create project and dataset automatically.
- Create/manage classes.
- YOLO-format labels and `data.yaml`.
- Auto-annotation.
- Editable annotations.
- Dataset validation and safe auto-fix.
- Duplicate/corrupt image checks.
- Train/validation/test split.
- Augmentation presets.
- Hard-example mining and active-learning workflow.

## Training and models
- Use current supported Ultralytics YOLO family.
- Include YOLO26n, YOLO26s and YOLO26m choices.
- Hardware-adaptive defaults. RTX 3080 10 GB should normally start with YOLO26s, with YOLO26m available for heavier training.
- CUDA acceleration where available; CPU/other fallback where required.
- Training history, metrics and comparisons.
- Analyze false positives/negatives, class confusion, under/overfitting and weak conditions.
- Controlled bounded model-improvement experiments.

## Final output
Every completed project should be able to produce a portable output folder containing at least:
- `best.pt`
- ready-to-use detector `.py`
- `requirements.txt`
- `config.json`
- `RUN.bat`
- short `README.txt`

The user should later be able to ask the AI to update/regenerate the output script.

## Local AI
- Primary local runtime: Ollama.
- Support provider adapters for other local compatible runtimes later.
- Local chat should work offline after models are installed.
- Add a suitable local vision-language model option for screenshot/image understanding.
- Local AI should have structured tools, not rely only on free-form text.

## Tool/action layer
The AI should be able to invoke real tools for project creation, imports, frame extraction, annotation, dataset validation, splitting, training, model loading/testing/export and diagnostics.

## Self-repair / self-healing
- Detect errors and record full error/exit code/traceback.
- Diagnose likely root cause.
- Use known repair recipes where possible.
- Snapshot before important changes.
- Apply safe repair.
- Verify repair by rerunning targeted tests and original operation.
- Roll back if worse.
- Keep repair history and machine-specific known fixes.
- Recovery system must not depend entirely on the potentially broken main Python/AI environment.

## Reset / restore
Provide three levels:
1. Reset Settings — restore default configuration.
2. Restore Last Known Good — restore verified app/config state.
3. Factory Repair/Reset — rebuild app environment from packaged baseline while preserving user projects/models by default.

## Self-extension
When the user requests a new feature, the AI should be able to prepare a controlled extension:
- understand request
- create versioned change
- install dependency if needed
- test
- keep only if verified
- roll back if broken
Do not perform uncontrolled self-rewriting.

## Portable software / other PCs
Final software is kept as a versioned folder suitable for cloud backup and later installation on another PC.
Target final artifacts include:
- `ROBO_VISION_AI_SETUP.exe`
- `ROBO_VISION_RECOVERY.exe`
- optional offline installer/cache package
- version manifest and checksums
- master requirements file
- project export/import

Fresh-PC installer should detect hardware/software, install missing prerequisites, choose compatible acceleration, diagnose/retry common failures, resume interrupted installs, and use offline cache where possible. It must not bypass Windows security/UAC/administrator/corporate controls; it should request required approval.

## Installation robustness
Handle missing/broken Python, pip, VC++ runtime, PyTorch/CUDA mismatch, missing DLLs, package conflicts, bad downloads, Ollama problems, file permissions, disk shortage, locked files and partial prior installs. Prefer known-good dependency combinations and verification after every stage.

## Privacy/offline
Projects, images, labels, models, chat history, repair history and experiment data remain local by default. Core CV workflow should work offline after prerequisites/models are present.

## Development rule
A feature is not complete because a button or placeholder exists. It counts only when its important path works and has a test or verifiable result.


## Live progress / transparency
- Show real progress sourced from actual pipeline callbacks, never invented percentages.
- Show current stage, image counts, dataset preparation and training epoch progress.
- Keep visible failure status and captured error text.
- Extend later with ETA, GPU/VRAM/temperature and repair activity.

## Runtime input behavior
- Exported detector must not assume a webcam by default.
- Support Screen, Game/App Window, Webcam, Video and Image input modes.
- Screen/Game Window is the normal default for this workflow.
- Export runner should discover a working ROBO Vision Python environment and attempt safe dependency repair if required.

## Smart annotation review / hard-example mining
- After first-pass auto-annotation, inspect images with empty labels using a lower-threshold second pass.
- Never silently promote uncertain detections into training truth; keep an explicit review queue.
- Recover only detections that cross the configured rescue threshold.
- After training, mine validation/test cases with misses, false positives or weak confidence and store them as hard examples for later improvement.

## Rich live progress
- Show elapsed time and an ETA estimate based on actual completed work.
- Show GPU utilization, VRAM usage, GPU temperature, CPU and RAM while work is running when telemetry is available.
- Keep pipeline stages visible: annotate → smart review → dataset prep → train → hard-example analysis → export.

## Self-heal rules
- Capture the exact action error before attempting a repair.
- Automatic dependency repair is allow-listed, not arbitrary package installation.
- CUDA out-of-memory during training should first retry with a smaller batch and verify the result.
- Unknown failures must be reported and logged rather than pretending they were repaired.


## Controlled model improvement / rollback
- Preserve a timestamped baseline model before every improvement experiment.
- Mine difficult TRAIN examples separately from validation/test examples so improvement does not contaminate evaluation.
- Build candidate training data in an isolated folder and keep original dataset splits intact.
- Run bounded candidate training with targeted augmentation/hard-example oversampling.
- Compare baseline and candidate on unchanged validation data using mAP50-95, mAP50, precision and recall.
- Replace active best.pt only when the candidate passes the improvement rule; otherwise retain baseline and archive rejected candidate.
- Record every experiment and its accepted/rejected state.
- Surface hard examples and the latest comparison in Improvement Lab.

## Local vision-language smart review
- Insert a local VLM review stage before dataset splitting/training.
- Use installed Ollama vision models automatically when available; do not require cloud APIs.
- The VLM may verify uncertain candidate crops and triage full images, but must not invent bounding-box coordinates.
- Candidate coordinates must come from a detector/proposal stage and only become training truth after explicit confidence rules.
- If Ollama or a vision model is unavailable, report a visible skipped state and continue safely with the existing review queue.
- Persist `vlm_review.json` and update `review_queue.json` so every promoted/remaining item is auditable.
- Prefer higher-resolution/low-threshold detector proposals for previously empty images, then gate them with the local VLM.


## Windows reliability hotfix 0.7.1
- Controlled improvement validation must use Windows-safe dataloader settings (`workers=0`) to prevent post-validation hangs.
- Progress must explicitly show candidate validation, metric comparison, and finalization.

## 0.8 Small-target enemy mode
- Far-away game targets must not depend only on full-frame PERSON detection at 640px.
- When the target is ENEMY/PERSON/SOLDIER, the hardware-aware preset may use higher-resolution training (RTX 3080 default: 960px, batch 4, CUDA/AMP).
- Before VLM review, run overlapping tile inference on unresolved images so small targets occupy more pixels.
- Detect small saturated red/orange enemy head markers as an additional cue.
- Marker-supported low-confidence person boxes may be rescued; marker-only boxes remain proposals for VLM review rather than becoming silent ground truth.
- Exported runtime uses higher-resolution inference plus a red-marker fallback overlay for distant marked enemies.
- UI dataset statistics must distinguish source images from train/val/test copies and show positive labels, confirmed negatives, remaining review items, and split copies.
- Controlled improvement remains rollback-safe and uses Windows-safe workers=0 for candidate training/validation.

### Python environment integrity (0.8.1)
- Every launch must use the Python executable inside the current build's `.venv`.
- Before opening the GUI, verify PyTorch, CUDA availability, and Ultralytics in that same interpreter.
- A missing PyTorch module must trigger a bounded CUDA-aware repair in the current ROBO environment, followed by import verification.
- Never silently fall back to a different global Python installation for training.


## 0.8.2 Feedback refinement / false-positive control
- The terminal must mirror application-level stage transitions and print an unmistakable final completion banner after model comparison and export.
- Runtime red-marker fallback must not box every red component immediately. Use stricter compact-marker filtering, model+marker fusion for low-confidence detections, and temporal confirmation before marker-only fallback.
- Provide live mistake collection: `M` then click records a missed target; `X` then click records a wrong box. Save the frame, crop and JSON metadata locally under the project feedback folder.
- Feedback collection must never silently change the active model during gameplay; it is evidence for a later controlled improvement cycle.
- Small-target review must preserve and merge existing accepted labels rather than overwriting them when a later review stage finds more boxes.
- False-positive reduction must not remove the working 960px small-target path or the rollback-safe controlled-improvement system.


### 0.8.2 Separate visual-assist controls
- The exported detector must open a separate `ROBO Assist Controls` window alongside the detection view.
- Provide Auto/Manual mode, Assist Strength, Assist Box %, Manual Confidence, Marker Boost, and Center Bias controls.
- The center assist box is a visual guide: detections inside it may be highlighted as the current assist target.
- Strength may tune detector/marker sensitivity in Auto mode; Manual mode exposes the thresholds directly.
- Persist the last control values locally and restore them on the next run.
- Visual assist must not synthesize mouse movement, keyboard input, trigger/fire actions, or bypass security/anti-cheat mechanisms.

## 0.9 Protected identity + controlled update manager
- ROBO must preserve a durable identity/purpose record across model, dependency, knowledge and software updates.
- Ship a build master identity (`ROBO_IDENTITY_MASTER.json`) and maintain the live protected identity at `config/ROBO_IDENTITY.json`.
- On startup, verify protected identity fields with a deterministic fingerprint. If protected identity drifts or becomes unreadable, back up the old copy and restore only the protected core fields while preserving non-core/user extensions.
- The protected identity includes the product purpose, core behavioral rules, required capabilities and update policy. Normal software/model updates must not silently remove these requirements.
- Provide three update modes: **Automatic**, **Notify Me**, and **Offline Only**.
- Offline Only must perform no network checks and must continue using already-downloaded local knowledge.
- Automatic mode may refresh approved knowledge sources when the configured refresh interval expires and internet is available.
- Approved knowledge sources must be auditable in `config/knowledge_sources.json`; downloaded content must be stored locally with source URL, timestamp and SHA256 metadata.
- Local AI chat should retrieve relevant snippets from the refreshed local knowledge store so fresh information remains usable later without internet.
- Knowledge refresh is separate from base-model retraining. Updating knowledge must not require retraining the local LLM.
- Software/model self-update must never blindly replace the running build. A trusted manifest must identify version, package URL and SHA256; packages are downloaded to staging, hash-verified and kept isolated until validation/promotion.
- Future automatic promotion must follow: backup -> stage -> verify -> test -> compare/health-check -> promote on success -> rollback on failure.
- If no trusted ROBO software manifest is configured, automatic mode still refreshes approved knowledge but reports software update feed as not configured rather than inventing an update.
- Update operations must not bypass UAC, Windows permissions, antivirus, corporate policy or security/anti-cheat controls.
- Every update action must leave an auditable local result/state file and must not delete projects/models by default.


## 0.9.1 UI visibility requirement
Identity, memory, update status, and access to Update Center must be visibly discoverable from the main AI Studio screen. New major features are not considered complete when they exist only in backend code/configuration. The main navigation must remain visible and the running build/version must be obvious.


## Trusted software update channel (0.9.2)
- Software updates must come from a configured trusted HTTPS manifest (file:// allowed only for local testing).
- Manifest requires version, package URL, and SHA256; package must match SHA256 exactly.
- Reject unsafe ZIP paths and incomplete packages.
- Stage and test candidates before activation.
- Never overwrite the currently running known-good build. Install candidate as a separate versioned build and keep the previous build for rollback.
- Preserve protected ROBO identity, projects, datasets, trained models, feedback, knowledge and master requirements across updates.
- Automatic mode may check/stage/test when a trusted channel is configured, but activation requires restarting into the prepared build.


## Trusted feed bootstrap (0.9.3)
- ROBO must be able to generate its own static trusted feed folder from a versioned ZIP, including SHA256 and manifest.json.
- The generated manifest uses a relative package URL so the same feed works locally and after upload to a static HTTPS host.
- Local file:// feed testing must be one-click and must not overwrite the current working build.
- The feed publisher must not fabricate a hosted URL. Internet auto-update becomes active only after the user/account owner publishes the generated files to a real HTTPS host and configures that manifest URL.


## Manifest robustness hotfix (0.9.3.4)
- Trusted manifests must accept normal UTF-8 and UTF-8-with-BOM JSON.
- Test Candidate must never treat an empty path as the current directory.
- Prepare Activation must require a real tested candidate directory.
- Update failures must explain the required previous step instead of raising a Windows permission error.


## Trusted update cycle test release (0.9.3.4)
- This release exists as a real newer candidate for validating the trusted updater from 0.9.3.1.
- The updater must report 0.9.3.4 as available when the trusted feed points to this package.
- Downloaded candidates must be SHA256 verified, safely extracted, tested, and prepared in a separate build folder before activation.
- The current working build must remain untouched for rollback.
- Identity, projects, models, knowledge and user configuration remain outside the replaceable build.


## Windows candidate-test temp isolation (0.9.3.4)
- Candidate update tests must never depend on pytest's default user Temp directory.
- The updater must create a version-specific pytest temp root under `C:\ROBO_VISION_AI\updates\staging`.
- Candidate tests must set TMP/TEMP and `--basetemp` to that ROBO-owned location.
- A Windows permission failure while cleaning `%LOCALAPPDATA%\Temp\pytest-of-...\pytest-current` must not falsely reject an otherwise passing candidate.

## Bootstrap candidate-test compatibility (0.9.3.4)
- Candidate packages MUST be testable by older working ROBO updaters before the candidate's own updater code can run.
- The candidate test configuration MUST set a project-local pytest `--basetemp` so Windows pytest cleanup does not depend on `%TEMP%\\pytest-of-user\\pytest-current`.
- This bootstrap safeguard is part of the candidate package itself, not only the updater implementation.


## 0.9.4.0 Portable Bootstrap & Self-Repair requirements
- Fresh-PC setup must detect hardware and Python availability.
- Prefer offline cache when available; use trusted online sources as fallback.
- When one supported Windows command/method fails, try another supported route instead of immediately giving up.
- Never bypass Windows security controls, UAC, antivirus, execution policy, or organization policy.
- Ask the user only when explicit permission is required or no safe supported fallback remains.
- Verify installed components and perform one bounded repair attempt before reporting failure.
- Preserve projects, trained models, chats/config, protected identity, knowledge, and update state across software replacement.
- Permanent trusted update feed: https://raw.githubusercontent.com/pungus4you/ROBO_VISION_AI_UPDATES/main/manifest.json
- Same or older versions must never be staged/tested/activated over the running build.
- Future packaging target remains ROBO_VISION_AI_SETUP.exe + ROBO_VISION_RECOVERY.exe.
