$ErrorActionPreference="Continue"
$Root=$PSScriptRoot; $Py=Join-Path $Root ".venv\Scripts\python.exe"; $Cache=Join-Path $Root "offline_cache"
Write-Host "ROBO SELF-REPAIR 0.9.4.0" -ForegroundColor Cyan
if(-not (Test-Path $Py)){ Write-Host "Environment missing. Running portable setup..."; & (Join-Path $Root "ROBO_PORTABLE_SETUP.ps1"); exit $LASTEXITCODE }
$checks=@("import torch","import ultralytics","import cv2","import PySide6","import mss")
$failed=@(); foreach($c in $checks){ & $Py -c $c 2>$null; if($LASTEXITCODE -ne 0){$failed += $c} }
if($failed.Count -eq 0){ Write-Host "Core components healthy." -ForegroundColor Green; exit 0 }
Write-Host "Broken/missing components detected. Reinstalling application requirements once..." -ForegroundColor Yellow
if((Test-Path $Cache) -and (Get-ChildItem $Cache -Filter *.whl -ErrorAction SilentlyContinue)){ & $Py -m pip install --force-reinstall --no-index --find-links $Cache -r (Join-Path $Root "requirements.txt") }
else { & $Py -m pip install --upgrade --force-reinstall -r (Join-Path $Root "requirements.txt") }
if($LASTEXITCODE -ne 0){ Write-Host "Repair could not finish automatically. Run ROBO_PORTABLE_SETUP.bat; Windows may need UAC/administrator approval." -ForegroundColor Red; exit 1 }
Write-Host "Repair completed. Re-run ROBO." -ForegroundColor Green
