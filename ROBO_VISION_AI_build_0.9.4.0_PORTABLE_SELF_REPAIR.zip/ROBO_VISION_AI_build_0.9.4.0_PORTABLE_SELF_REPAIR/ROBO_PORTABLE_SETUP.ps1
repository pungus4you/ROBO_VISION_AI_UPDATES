$ErrorActionPreference="Continue"
$Here=$PSScriptRoot
Write-Host "ROBO Vision AI Portable Bootstrap 0.9.4.0" -ForegroundColor Cyan
Write-Host "This bootstrap uses supported Windows methods only and never disables security controls."
$install=Join-Path $Here "INSTALL.ps1"
if(-not (Test-Path $install)){ throw "INSTALL.ps1 is missing." }
$methods=@()
if(Get-Command powershell.exe -ErrorAction SilentlyContinue){$methods += "powershell"}
if(Get-Command pwsh.exe -ErrorAction SilentlyContinue){$methods += "pwsh"}
foreach($m in $methods){
  try{
    Write-Host "Trying installer with $m..."
    if($m -eq "powershell"){ & powershell.exe -NoProfile -File $install } else { & pwsh.exe -NoProfile -File $install }
    if($LASTEXITCODE -eq 0){ exit 0 }
  } catch { Write-Host "Method $m failed: $($_.Exception.Message)" -ForegroundColor Yellow }
}
Write-Host "Automatic supported methods did not complete. Windows may require an administrator/UAC approval or organization policy may block installation." -ForegroundColor Red
exit 1
